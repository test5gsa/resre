#!/bin/bash

TIMESTAMP=$(date +%d%m%Y%H%M%S)

ENV_FILE=kxi-terraform.env

CONFIG_FILE=config/config.json

if [ -f ${ENV_FILE} ]
then
  gum confirm "${ENV_FILE} configuration file already exists. Do you want to take a backup?"
  if [[ $? == 1 ]]
  then
    echo "Removing ${ENV_FILE}"
    rm ${ENV_FILE}
  else
    echo "Renaming to ${ENV_FILE}.backup-${TIMESTAMP}".
    mv ${ENV_FILE} ${ENV_FILE}.backup-${TIMESTAMP}
  fi
fi

echo ""
echo "Select Cloud Provider"
CSP=$(gum choose AWS Azure GCP)
case $CSP in
  AWS)
    cloud=aws
    regions=$(jq -r '.config' ${CONFIG_FILE} | jq '.[] | select(.name=="aws")' | jq -r '.regions')
    jq -r '.config' ${CONFIG_FILE} | jq '.[] | select(.name=="aws")' > ${cloud}.json
    echo ""
    echo "Set AWS Access Key ID"
    while true; do
        AWS_KEY_ID=$(gum input --password --placeholder "Enter AWS Access Key ID")
        if [[ -n "$AWS_KEY_ID" ]]; then
            break
        else
            echo "AWS Access Key ID is required. Please enter a value."
        fi
    done
    echo ""
    echo "Set AWS Secret Access Key"
    while true; do
        AWS_SECRET_KEY=$(gum input  --password --placeholder "Enter AWS Secret Access Key")
        if [[ -n "$AWS_SECRET_KEY" ]]; then
            break
        else
            echo "AWS Secret Access Key is required. Please enter a value."
        fi
    done

    export AWS_ACCESS_KEY_ID="$AWS_KEY_ID"
    export AWS_SECRET_ACCESS_KEY="$AWS_SECRET_KEY"

    echo ""
    echo "Authenticating AWS Credentials..."

    echo ""
    if aws sts get-caller-identity > /dev/null 2>&1; then
        echo "AWS credentials are valid."
    else
        echo "AWS credentials are invalid. Please check your access key and secret key."
        exit
    fi

    unset AWS_ACCESS_KEY_ID
    unset AWS_SECRET_ACCESS_KEY
    ;;
  Azure)
    cloud=azure
    regions=$(jq -r '.config' ${CONFIG_FILE} | jq '.[] | select(.name=="azure")' | jq -r '.regions')
    jq -r '.config' ${CONFIG_FILE} | jq '.[] | select(.name=="azure")' > ${cloud}.json
    echo ""
    echo "Set Azure Client ID"
    while true; do
        AZURE_CLIENT_ID=$(gum input --placeholder "Enter Azure Client ID")
        if [[ -n "$AZURE_CLIENT_ID" ]]; then
            break
        else
            echo "Azure Client ID is required. Please enter a value."
        fi
    done
    echo ""
    echo "Set Azure Client Secret"
    while true; do
        AZURE_CLIENT_SECRET=$(gum input --password --placeholder "Enter Azure Client Secret")
        if [[ -n "$AZURE_CLIENT_SECRET" ]]; then
            break
        else
            echo "Azure Client Secret is required. Please enter a value."
        fi
    done
    echo ""
    echo "Set Azure Subscription ID"
    while true; do
        AZURE_SUBSCRIPTION_ID=$(gum input --placeholder "Enter Azure Subscription ID")
        if [[ -n "$AZURE_SUBSCRIPTION_ID" ]]; then
            break
        else
            echo "Azure Subscription ID is required. Please enter a value."
        fi
    done
    echo ""
    echo "Set Azure Tenant ID"
    while true; do
        AZURE_TENANT_ID=$(gum input --placeholder "Enter Azure Tenant ID")
        if [[ -n "$AZURE_TENANT_ID" ]]; then
            break
        else
            echo "Azure Tenant ID is required. Please enter a value."
        fi
    done
    echo "Authenticating with Azure..."
    if az login --service-principal \
        --username "$AZURE_CLIENT_ID" \
        --password "$AZURE_CLIENT_SECRET" \
        --tenant "$AZURE_TENANT_ID" > /dev/null 2>&1; then
        echo "Azure credentials are valid."
    else
        echo "Azure credentials are invalid. Please check your keys."
        exit
    fi
    ;;
  GCP)
    cloud=gcp
    regions=$(jq -r '.config' ${CONFIG_FILE} | jq '.[] | select(.name=="gcp")' | jq -r '.regions')
    jq -r '.config' ${CONFIG_FILE} | jq '.[] | select(.name=="gcp")' > ${cloud}.json
    echo ""
    echo "Set GCP Project"
    while true; do
        GCP_PROJECT=$(gum input --placeholder "Enter GCP Project")
        if [[ -n "$GCP_PROJECT" ]]; then
            break
        else
            echo ""
            echo "GCP Project is required. Please enter a value."
        fi
    done
    echo ""
    echo "Set GCP Credentials JSON filename (should exist on the current directory)"
    while true
    do
      GCP_JSON_FILE=$(gum input)

      if [ -z "$GCP_JSON_FILE" ]
      then
        echo ""
        echo "Filename cannot be empty. Please enter a valid filename."
        continue
      fi

      if [ ! -f ${GCP_JSON_FILE} ]
      then
        echo "${GCP_JSON_FILE} doesn't exist on current directory. Please set the correct filename"
      else
        break
      fi
    done
    echo ""
    echo "Authenticating with GCP..."
    if gcloud auth activate-service-account --key-file="$GCP_JSON_FILE" --project="$GCP_PROJECT" > /dev/null 2>&1; then
        echo ""
        echo "GCP credentials are valid."
    else
        echo ""
        echo "GCP credentials are invalid. Please check your keys."
        exit
    fi
    ;;
  *)
    echo ""
    echo "Invalid Cloud Provider"
    exit 1
    ;;
  esac

echo ""
echo "Select Region"
REGION=$(gum choose --height=50 $regions)

echo ""
echo "Select Architecture Profile"
PROFILE=$(gum choose HA Performance Cost-Optimised)
PROFILE_NAME=$PROFILE
case $PROFILE in
  HA)
    profile=ha
    reducted_azs=false
    jq -r '.profile' ${cloud}.json | jq '.[] | select(.name=="ha")' > ${cloud}-${profile}.json
    ;;
  Performance)
    profile=perf
    reducted_azs=true
    jq -r '.profile' ${cloud}.json | jq '.[] | select(.name=="perf")' > ${cloud}-${profile}.json
    ;;
  Cost-Optimised)
    profile=cost
    reducted_azs=true
    jq -r '.profile' ${cloud}.json | jq '.[] | select(.name=="cost")' > ${cloud}-${profile}.json
    ;;
  *)
    echo "Invalid Architecture Profile"
    exit 1
    ;;
  esac


if [[ "${cloud}" == "aws" ]]; then
  echo "Are you using an existing VPC or wish to create one?"
  VPC=$(gum choose "New VPC" "Existing VPC")

  # Default value — in case no existing VPC is used (this is as we can't pass through a blank variable for a list
  PRIVATE_SUBNET_IDS="[]"

  if [[ "${VPC}" == "Existing VPC" ]]; then
    EXISTING_VPC=true
    PRIVATE_ONLY=false
    echo ""

    # Ask if the existing VPC is private-only or has public resources
    echo "Does your existing VPC have public subnets, NAT Gateway, and Bastion Host?"
    EXISTING_VPC_TYPE=$(gum choose "Yes (Standard VPC with public resources)" "No (Private-only VPC, no internet)")

    if [[ "${EXISTING_VPC_TYPE}" == "No (Private-only VPC, no internet)" ]]; then
      PRIVATE_ONLY=true
    fi

    echo ""
    # Gather the existing VPC ID
    echo "Please enter the vpc id of the existing vpc: "
    VPC_ID=$(gum input --placeholder "vpc-0490ed4841d8f58cf")
    echo ""

    # Gather existing private subnet id's
    echo "Please enter private subnet IDs (comma-separated, no quotes):"
    RAW_SUBNET_IDS=$(gum input \
      --placeholder "subnet-07884998863f2d554, subnet-0e7903b8757f1025")

    # Trim spaces and convert to array format
    IFS=',' read -ra SUBNET_ARRAY <<< "$RAW_SUBNET_IDS"

    formatted_subnets=()
    for subnet in "${SUBNET_ARRAY[@]}"; do
      # Trim leading and trailing whitespace
      subnet="${subnet#"${subnet%%[![:space:]]*}"}"
      subnet="${subnet%"${subnet##*[![:space:]]}"}"
      formatted_subnets+=("\"$subnet\"")
    done

    PRIVATE_SUBNET_IDS="[${formatted_subnets[*]}]"
    # Fix spaces: replace space with comma
    PRIVATE_SUBNET_IDS="${PRIVATE_SUBNET_IDS// /, }"

    # Only ask for public resources if NOT private-only
    if [[ "$PRIVATE_ONLY" != "true" ]]; then
      echo ""
      # Gather the NACL allocated to the public subnets
      echo "Please enter the Network ACL that is allocated to the public subnets in the existing VPC: "
      PUBLIC_NETWORK_ACL_ID=$(gum input --placeholder "acl-0c0a778b0b58d53f5")
      echo ""

      # Gather the bastion hosts security group id
      echo "Please enter the security group ID which is attached to the bastion host you are deploying from: "
      BASTION_HOST_SG_ID=$(gum input --placeholder "sg-077098aea8747407e")
    fi

  else
    EXISTING_VPC=false
    echo ""
    echo "Select VPC type:"
    VPC_TYPE=$(gum choose "Standard VPC (with Internet Gateway, NAT Gateway, Bastion Host)" "Private-Only VPC (no internet, no bastion, private subnets only)")

    if [[ "${VPC_TYPE}" == "Private-Only VPC (no internet, no bastion, private subnets only)" ]]; then
      PRIVATE_ONLY=true
    else
      PRIVATE_ONLY=false
    fi
  fi
fi

if [[ "${cloud}" == "azure" ]]; then
  echo "Are you using an existing Virtual Network or wish to create one?"
  VPC=$(gum choose "New Virtual Network" "Existing Virtual Network")

  # Default value in case no existing Virtual Network is used (this is as we can't pass through a blank variable for a list
  PRIVATE_SUBNET_NAMES="[]"

  if [[ "${VPC}" == "Existing Virtual Network" ]]; then
    EXISTING_VPC=true
    echo ""
    # Gather the existing VNET NAME
    echo "Please enter the vnet name of the existing virtual network: "
    VNET_NAME=$(gum input --placeholder "vnet-abcd")
    echo ""

    # Gather existing subnet name
    echo "Please enter subnet name:"
    RAW_SUBNET_IDS=$(gum input \
      --placeholder "vnet-abcd-subnet")

    # Trim spaces and convert to array format
    IFS=',' read -ra SUBNET_ARRAY <<< "$RAW_SUBNET_IDS"

    formatted_subnets=()
    for subnet in "${SUBNET_ARRAY[@]}"; do
      # Trim leading and trailing whitespace
      subnet="${subnet#"${subnet%%[![:space:]]*}"}"
      subnet="${subnet%"${subnet##*[![:space:]]}"}"
      formatted_subnets+=("\"$subnet\"")
    done

    PRIVATE_SUBNET_NAMES="[${formatted_subnets[*]}]"
    # Fix spaces: replace space with comma
    PRIVATE_SUBNET_NAMES="${PRIVATE_SUBNET_NAMES// /, }"

    echo ""

    # Gather the resource group where the above are created
    echo "Please enter the azure resource group name where the Virtual Network,Subnet and Network Security Group are created: "
    EXISTING_VNET_RESOURCE_GROUP_NAME=$(gum input --placeholder "tfscripts-vpc-resource-group")

  else
    EXISTING_VPC=false
  fi
fi

if [[ "${cloud}" == "gcp" ]]; then
  echo "Are you using an existing VPC or wish to create one?"
  VPC=$(gum choose "New VPC" "Existing VPC")

  if [[ "${VPC}" == "Existing VPC" ]]; then
    EXISTING_VPC=true
    echo ""

    echo "Please enter the name of the existing VPC network:"
    NETWORK_NAME=$(gum input --placeholder "gcp-kx-network")

    echo "Please enter the name of the subnet to use:"
    SUBNET_NAME=$(gum input --placeholder "gcp-kx-subnet")

    echo "Please enter the name of the pods IP range:"
    PODS_RANGE_NAME=$(gum input --placeholder "gcp-kx-ip-range-pods")

    echo "Please enter the name of the services IP range:"
    SVC_RANGE_NAME=$(gum input --placeholder "gcp-kx-ip-range-svc")

    echo "Please enter the internal IP of the bastion host:"
    BASTION_HOST_INTERNAL_IP=$(gum input --placeholder "10.0.50.2")

  else
    EXISTING_VPC=false
  fi
fi


# Function to get value from config file and default to "" if not available
get_json_value() {
  local file="$1"
  local key="$2"
  jq -r --arg key "$key" '.[$key] // ""' "$file"
}

JSON_FILE="${cloud}-${profile}.json"

# Set variables for selected profile
DEFAULT_POOL_NODE_TYPE=$(get_json_value "$JSON_FILE" "default_node_type")
DEFAULT_POOL_MIN_COUNT=$(get_json_value "$JSON_FILE" "default_pool_min_count")
DEFAULT_POOL_MAX_COUNT=$(get_json_value "$JSON_FILE" "default_pool_max_count")
DEFAULT_DISK_TYPE=$(get_json_value "$JSON_FILE" "disk_type")
ROOK_CEPH_POOL_NODE_TYPE=$(get_json_value "$JSON_FILE" "rook_ceph_node_type")
ROOK_CEPH_POOL_STORAGE_TYPE=$(get_json_value "$JSON_FILE" "rook_ceph_storage_type")

# Set rook-ceph storage types available
aws_rook_ceph_storage_types=("gp3" "io2")
azure_rook_ceph_storage_types=("managed" "premium2-disk")
gcp_rook_ceph_storage_types=("standard-rwo" "pd-ssd")

echo ""
if [[ "${profile}" !=  "cost" ]]
then
  case $cloud in
    aws)
      echo "$PROFILE_NAME uses rook-ceph storage type of gp3 by default. Press **Enter** to use this or select another storage type:"
      ROOK_CEPH_POOL_STORAGE_TYPE=$(gum choose --height=2 --selected="gp3" "${aws_rook_ceph_storage_types[@]}")
      ;;
    azure)
      echo "$PROFILE_NAME uses rook-ceph storage type of managed by default. Press **Enter** to use this or select another storage type:"
      ROOK_CEPH_POOL_STORAGE_TYPE=$(gum choose --height=2 --selected="managed" "${azure_rook_ceph_storage_types[@]}")
      ;;
    gcp)
      echo "$PROFILE_NAME uses rook-ceph storage type of standard-rwo by default. Press **Enter** to use this or select another storage type:"
      ROOK_CEPH_POOL_STORAGE_TYPE=$(gum choose --height=2 --selected="standard-rwo" "${gcp_rook_ceph_storage_types[@]}")
      ;;
  esac
fi

echo ""
if [[ "${profile}" ==  "cost" ]]
then
  case $cloud in
    aws)
      echo "$PROFILE_NAME uses rook-ceph storage type of gp3. If you wish to change this please refer to the docs."
      ;;
    azure)
      echo "$PROFILE_NAME uses rook-ceph storage type of managed. If you wish to change this please refer to the docs."
      ;;
    gcp)
      echo "$PROFILE_NAME uses rook-ceph storage type of standard-rwo. If you wish to change this please refer to the docs."
      ;;
  esac
fi

echo ""
echo "Set how much capacity you require for rook-ceph, press Enter to use the default of 100Gi"
echo "Please note this is will be the usable storage with replication"
while true; do
  ROOK_CEPH_POOL_STORAGE_SIZE=$(gum input --placeholder "Enter rook-ceph disk space (default: 100)")

  # Set default if empty
  ROOK_CEPH_POOL_STORAGE_SIZE=${ROOK_CEPH_POOL_STORAGE_SIZE:-100}

  # Validate
  if [[ "$ROOK_CEPH_POOL_STORAGE_SIZE" =~ ^[0-9]+$ ]]; then
    ROOK_CEPH_POOL_STORAGE_SIZE="${ROOK_CEPH_POOL_STORAGE_SIZE}Gi"
    echo "You selected: ${ROOK_CEPH_POOL_STORAGE_SIZE}"
    break
  else
    echo "Invalid input. Please enter a number."
  fi
done

echo ""
echo "Set environment name (Up to 8 character, can only contain lowercase letters and numbers)"
while true
do
  ENV=$(gum input --char-limit=8)
  if [[ ! $ENV =~ ^[a-z0-9]+$ ]]
  then
    echo "[$ENV] is not valid. Please update the variable."
  else
    break
  fi
done

if [[ "$EXISTING_VPC" != "true" && "$PRIVATE_ONLY" != "true" ]]; then
  echo ""
  echo "Set Network CIDR that will be allowed VPN access as well as SSH access to the bastion host"
  echo "For convenience, this is pre-populated with your public IP address (using command: curl -s ipinfo.io/ip)."
  echo "To specify multiple CIDRs, use a comma-separated list (for example, 192.1.1.1/32,192.1.1.2/32). Do not include quotation marks around the input."
  echo "For unrestricted access, set to 0.0.0.0/0. Ensure your network team allows such access."
  while true
  do
    LOCAL_IP=$(curl -s ipinfo.io/ip)
    BASTION_CIDRS=$(gum input --char-limit=100 --value="$LOCAL_IP/32")
    INVALID_CIDR=false
    DUPLICATE_CIDR=false

    IFS=',' read -ra CIDR_ARRAY <<< "$BASTION_CIDRS"

    seen_cidrs=()

    for CIDR in "${CIDR_ARRAY[@]}"; do
      CIDR=$(echo "$CIDR" | xargs)

      for seen in "${seen_cidrs[@]}"; do
        if [[ "$CIDR" == "$seen" ]]; then
          echo "[$CIDR] is a duplicate. Please update the variable."
          DUPLICATE_CIDR=true
          break
        fi
      done

      if [[ "$DUPLICATE_CIDR" == false ]]; then
        seen_cidrs+=("$CIDR")
      fi

      # Validate CIDR format
      if [[ ! $CIDR =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}/([0-9]|[12][0-9]|3[012])$ ]]; then
        echo "[$CIDR] is not a valid CIDR. Please update the variable."
        INVALID_CIDR=true
      fi
    done

    if [[ $INVALID_CIDR == false && $DUPLICATE_CIDR == false ]]; then
      formatted_cidrs=()
      for cidr in "${seen_cidrs[@]}"; do
        formatted_cidrs+=("\"$cidr\"")
      done
      BASTION_CIDRS="[${formatted_cidrs[*]}]"
      # Fix spaces: replace space with comma
      BASTION_CIDRS="${BASTION_CIDRS// /, }"
      break
    fi
  done
else
  # Deploying on existing VPC/VNET or Private-Only VPC
  LOCAL_IP=$(curl -s ipinfo.io/ip)
  BASTION_CIDRS=[\"${LOCAL_IP}/32\"]
fi

echo ""
echo "Set Network CIDR that will be allowed HTTPS access"
echo "For convenience, this is pre-populated with your public IP address (using command: curl -s ipinfo.io/ip)."
echo "To specify multiple CIDRs, use a comma-separated list (for example, 192.1.1.1/32,192.1.1.2/32). Do not include quotation marks around the input."
echo "For unrestricted access, set to 0.0.0.0/0. Ensure your network team allows such access."
while true
do
  LOCAL_IP=$(curl -s ipinfo.io/ip)
  HTTPS_CIDRS=$(gum input --char-limit=100 --value="$LOCAL_IP/32")
  INVALID_CIDR=false
  DUPLICATE_CIDR=false

  IFS=',' read -ra CIDR_ARRAY <<< "$HTTPS_CIDRS"

  seen_cidrs=()

  for CIDR in "${CIDR_ARRAY[@]}"; do
    CIDR=$(echo "$CIDR" | xargs)

    for seen in "${seen_cidrs[@]}"; do
      if [[ "$CIDR" == "$seen" ]]; then
        echo "[$CIDR] is a duplicate. Please update the variable."
        DUPLICATE_CIDR=true
        break
      fi
    done

    if [[ "$DUPLICATE_CIDR" == false ]]; then
      seen_cidrs+=("$CIDR")
    fi

    # Validate CIDR format
    if [[ ! $CIDR =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}/([0-9]|[12][0-9]|3[012])$ ]]; then
      echo "[$CIDR] is not a valid CIDR. Please update the variable."
      INVALID_CIDR=true
    fi
  done

  if [[ $INVALID_CIDR == false && $DUPLICATE_CIDR == false ]]; then
    formatted_cidrs=()
    for cidr in "${seen_cidrs[@]}"; do
      formatted_cidrs+=("\"$cidr\"")
    done
    HTTPS_CIDRS="[${formatted_cidrs[*]}]"
    # Fix spaces: replace space with comma
    HTTPS_CIDRS="${HTTPS_CIDRS// /, }"
    break
  fi
done

echo ""
echo "Choose method for managing SSL certificates"
echo "----------------------------------------------"
echo "Existing Certificates: Requires the SSL certificate to be stored on a Kubernetes Secret on the same namespace where Insights is deployed."
echo "Cert-Manager HTTP Validation: Issues Let's Encrypt Certificates; fully automated but requires unrestricted HTTP access to the cluster."


VALIDATION_METHOD=$(gum choose --selected="Existing Certificates" "Existing Certificates" "Cert-Manager HTTP Validation" )
if [[ "${VALIDATION_METHOD}" == "Cert-Manager HTTP Validation" ]]
then
    ENABLE_HTTP_VALIDATION="true"
else
    ENABLE_HTTP_VALIDATION="false"
fi

    cat <<EOF >"${ENV_FILE}"
# #### KX Insights cluster deployment configuration - $CSP #####
#
# This file can be customised as needed based on the environment requirements.

# Cloud Provider to use, do not make any changes.
CLOUD=$cloud

# Environment name, can be customized as needed. Can only contain lowercase letters and numbers.
ENV=$ENV

# Credentials used for the cluster deployment.

# AWS
AWS_ACCESS_KEY_ID=$AWS_KEY_ID
AWS_SECRET_ACCESS_KEY=$AWS_SECRET_KEY

# Azure
ARM_CLIENT_ID=$AZURE_CLIENT_ID
ARM_CLIENT_SECRET=$AZURE_CLIENT_SECRET
ARM_SUBSCRIPTION_ID=$AZURE_SUBSCRIPTION_ID
ARM_TENANT_ID=$AZURE_TENANT_ID

# GCP
PROJECT=$GCP_PROJECT
GOOGLE_APPLICATION_CREDENTIALS=/terraform/$GCP_JSON_FILE

# Region used for the cluster deployment.
REGION=$REGION

# Architecture Profile
PROFILE=$profile

# Configuration for the selected profile
TF_VAR_enable_rook_ceph_node_pool=false
TF_VAR_default_node_type=$DEFAULT_POOL_NODE_TYPE
TF_VAR_disk_type=$DEFAULT_DISK_TYPE
#TF_VAR_rook_ceph_pool_node_type=$ROOK_CEPH_POOL_NODE_TYPE
#TF_VAR_rook_ceph_pool_local_ssd_count=$GCP_LOCAL_SSD_COUNT
TF_VAR_rook_ceph_storage_type=$ROOK_CEPH_POOL_STORAGE_TYPE
TF_VAR_rook_ceph_storage_size=$ROOK_CEPH_POOL_STORAGE_SIZE
#TF_VAR_rook_ceph_pool_min_count=$ROOK_CEPH_POOL_MIN_COUNT
#TF_VAR_rook_ceph_pool_max_count=$ROOK_CEPH_POOL_MAX_COUNT
TF_VAR_desired_node_count=$DEFAULT_POOL_MIN_COUNT
TF_VAR_default_node_count=$DEFAULT_POOL_MIN_COUNT
TF_VAR_min_node_count=$DEFAULT_POOL_MIN_COUNT
TF_VAR_max_node_count=$DEFAULT_POOL_MAX_COUNT
TF_VAR_reduced_azs=${reducted_azs}

# List of IPs or Subnets that will be allowed VPN access as well as SSH access
# to the bastion host for troubleshooting VPN issues.
TF_VAR_bastion_whitelist_ips=$BASTION_CIDRS

# List of IPs or Subnets that will be allowed HTTPS access
TF_VAR_insights_whitelist_ips=$HTTPS_CIDRS

# Enable HTTP validation. By default this is disabled to allow only pre-existing certificates
TF_VAR_letsencrypt_enable_http_validation=$ENABLE_HTTP_VALIDATION

###### Advanced Configuration  ######

## Common ##

# Enable/Disable rook-ceph deployment, disabling this will not disable nodepool generation.
TF_VAR_enable_rook_ceph=true

# Deploy rook-ceph cluster with helm chart
TF_VAR_enable_rook_ceph_helm=true

# Enables forwarding of container metrics to Cloud-Native monitoring tools
TF_VAR_enable_metrics=false

# Enables forwarding of container logs to Cloud-Native monitoring tools
TF_VAR_enable_logging=false

# Email address for Let's Encrypt account registration and notifications
TF_VAR_letsencrypt_account=root@emaildomain.com

# Enable/Disable cert-manager and ingress-nginx
TF_VAR_enable_cert_manager=true
TF_VAR_enable_ingress_nginx=true

## AWS ##

# Control which components should be deployed
TF_VAR_enable_cluster_autoscaler=true
TF_VAR_enable_ebs_csi_driver=true
TF_VAR_enable_efs_csi_driver=true

## Azure ##

# Control which components should be deployed
TF_VAR_enable_sharedfiles_storage_class=true

## GCP ##

# Control which components should be deployed
TF_VAR_enable_filestore_csi_driver=true
TF_VAR_enable_sharedfiles_storage_class=true

# Variables if using existing vpc/vnet

TF_VAR_existing_vpc=$EXISTING_VPC
TF_VAR_private_only=$PRIVATE_ONLY
TF_VAR_vpc_id=$VPC_ID
TF_VAR_existing_vnet=$EXISTING_VPC
TF_VAR_vnet_name=$VNET_NAME
TF_VAR_private_subnets_ids=$PRIVATE_SUBNET_IDS
TF_VAR_private_subnets_names=$PRIVATE_SUBNET_NAMES
TF_VAR_public_network_acl_id=$PUBLIC_NETWORK_ACL_ID
TF_VAR_bastion_host_sg_id=$BASTION_HOST_SG_ID
TF_VAR_existing_vnet_resource_group=$EXISTING_VNET_RESOURCE_GROUP_NAME
TF_VAR_network_name=$NETWORK_NAME
TF_VAR_subnet_name=$SUBNET_NAME
TF_VAR_pods_range_name=$PODS_RANGE_NAME
TF_VAR_svc_range_name=$SVC_RANGE_NAME
TF_VAR_bastion_host_internal_ip=$BASTION_HOST_INTERNAL_IP

######################################################################

# Backend for terraform state, will be populated automatically
EOF

# Append terraform backend variables
case $CSP in
  AWS)
    echo "KX_STATE_BUCKET_NAME=$KX_STATE_BUCKET_NAME" >> ${ENV_FILE}
    ;;
  Azure)
    echo "KX_STATE_RESOURCE_GROUP_NAME=$KX_STATE_RESOURCE_GROUP_NAME" >> ${ENV_FILE}
    echo "KX_STATE_RESOURCE_GROUP_NAME=$KX_STATE_RESOURCE_GROUP_NAME" >> ${ENV_FILE}
    echo "KX_STATE_BUCKET_NAME=$KX_STATE_BUCKET_NAME" >> ${ENV_FILE}
    ;;
  GCP)
    echo "KX_STATE_BUCKET_NAME=$KX_STATE_BUCKET_NAME" >> ${ENV_FILE}
    ;;
  *)
    echo "Invalid Cloud Provider"
    exit 1
    ;;
  esac

# Cleanup
rm ${cloud}.json ${cloud}-${profile}.json

echo ""
echo "Configuration has been generated on ${ENV_FILE}. You can now deploy the cluster by running ./scripts/deploy-cluster.sh"
