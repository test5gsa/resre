#!/bin/bash

################################################################################
# List VPC Resources Helper Script
# Helps discover existing VPCs and subnets for use with create-vpc-infrastructure.sh
################################################################################

# Color codes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

REGION="${1:-us-west-1}"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}AWS VPC Resources Discovery${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "Region: ${GREEN}${REGION}${NC}"
echo ""

# List VPCs
echo -e "${YELLOW}Available VPCs:${NC}"
echo ""
aws ec2 describe-vpcs \
  --region ${REGION} \
  --query 'Vpcs[*].[VpcId,CidrBlock,Tags[?Key==`Name`].Value|[0]]' \
  --output table

echo ""
read -p "Enter VPC ID to view subnets (or press Enter to skip): " VPC_ID

if [ -z "$VPC_ID" ]; then
    echo -e "${BLUE}Exiting.${NC}"
    exit 0
fi

echo ""
echo -e "${YELLOW}Subnets in VPC ${VPC_ID}:${NC}"
echo ""

# Get subnets
SUBNETS=$(aws ec2 describe-subnets \
  --region ${REGION} \
  --filters "Name=vpc-id,Values=${VPC_ID}" \
  --query 'Subnets[*].[SubnetId,AvailabilityZone,CidrBlock,Tags[?Key==`Name`].Value|[0],MapPublicIpOnLaunch]' \
  --output text)

# Display with color coding
echo -e "${BLUE}Subnet ID${NC}          ${BLUE}AZ${NC}            ${BLUE}CIDR${NC}              ${BLUE}Name${NC}                    ${BLUE}Type${NC}"
echo "--------------------------------------------------------------------------------"

while IFS=$'\t' read -r subnet_id az cidr name public; do
    if [ "$public" = "True" ]; then
        type="${YELLOW}Public${NC}"
    else
        type="${GREEN}Private${NC}"
    fi
    printf "%-18s %-13s %-17s %-25s %b\n" "$subnet_id" "$az" "$cidr" "$name" "$type"
done <<< "$SUBNETS"

echo ""
echo -e "${YELLOW}Private Subnets Only (comma-separated for script):${NC}"
PRIVATE_SUBNETS=$(aws ec2 describe-subnets \
  --region ${REGION} \
  --filters "Name=vpc-id,Values=${VPC_ID}" "Name=map-public-ip-on-launch,Values=false" \
  --query 'Subnets[*].SubnetId' \
  --output text | tr '\t' ',')

echo -e "${GREEN}${PRIVATE_SUBNETS}${NC}"
echo ""

echo -e "${YELLOW}Command to create VPC Endpoints:${NC}"
echo ""
echo -e "${GREEN}./scripts/create-vpc-infrastructure.sh ${REGION} my-cluster ${VPC_ID} \"${PRIVATE_SUBNETS}\"${NC}"
echo ""

# Show route tables
echo -e "${YELLOW}Route Tables for these subnets:${NC}"
echo ""
aws ec2 describe-route-tables \
  --region ${REGION} \
  --filters "Name=vpc-id,Values=${VPC_ID}" \
  --query 'RouteTables[*].[RouteTableId,Associations[0].SubnetId,Tags[?Key==`Name`].Value|[0]]' \
  --output table

echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Resource Discovery Complete${NC}"
echo -e "${BLUE}========================================${NC}"
