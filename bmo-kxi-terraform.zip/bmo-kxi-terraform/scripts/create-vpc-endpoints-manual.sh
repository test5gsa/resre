#!/usr/bin/env bash

################################################################################
# AWS CLI Script: Create VPC Endpoints for Private EKS
################################################################################
#
# This script creates all necessary VPC Endpoints for EKS to work without
# NAT Gateway in an existing VPC.
#
# Use this when you have an existing VPC and want to manually create endpoints
# instead of using Terraform.
#
################################################################################

# Ensure we're running with bash
if [ -z "$BASH_VERSION" ]; then
    echo "Error: This script requires bash. Please run with bash instead of sh."
    exit 1
fi

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${BLUE}ℹ ${NC}$1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

################################################################################
# CONFIGURATION - FILL IN YOUR VALUES
################################################################################

# Required parameters
VPC_ID="${VPC_ID:-}"
PRIVATE_SUBNET_IDS="${PRIVATE_SUBNET_IDS:-}"  # Space-separated list: "subnet-aaa subnet-bbb subnet-ccc"
CLUSTER_NAME="${CLUSTER_NAME:-}"
REGION="${AWS_REGION:-us-west-2}"

# Optional - will auto-discover if not set
PRIVATE_RT_IDS="${PRIVATE_RT_IDS:-}"          # Space-separated list: "rtb-xxx rtb-yyy" (optional, auto-discovered)

# Optional parameters
ENABLE_SSM="${ENABLE_SSM:-true}"              # Enable SSM for remote access
ENABLE_EFS="${ENABLE_EFS:-true}"              # Enable EFS endpoint
CREATE_SECURITY_GROUP="${CREATE_SECURITY_GROUP:-true}"  # Create new SG or use existing

################################################################################
# VALIDATION
################################################################################

print_info "Validating configuration..."

if [ -z "$VPC_ID" ]; then
    print_error "VPC_ID not set!"
    echo ""
    echo "Usage:"
    echo "  export VPC_ID=vpc-xxxxx"
    echo "  export PRIVATE_SUBNET_IDS='subnet-aaa subnet-bbb subnet-ccc'"
    echo "  export CLUSTER_NAME=my-cluster"
    echo "  export REGION=us-west-2"
    echo "  ./create-vpc-endpoints-manual.sh"
    echo ""
    echo "Optional:"
    echo "  export PRIVATE_RT_IDS='rtb-xxx rtb-yyy'  # Auto-discovered if not set"
    echo "  export ENABLE_SSM=true                    # Enable SSM endpoints (default: true)"
    echo "  export ENABLE_EFS=true                    # Enable EFS endpoint (default: true)"
    exit 1
fi

if [ -z "$PRIVATE_SUBNET_IDS" ]; then
    print_error "PRIVATE_SUBNET_IDS not set!"
    exit 1
fi

if [ -z "$CLUSTER_NAME" ]; then
    print_error "CLUSTER_NAME not set!"
    exit 1
fi

# PRIVATE_RT_IDS is now optional - will auto-discover all route tables in VPC
if [ -z "$PRIVATE_RT_IDS" ]; then
    print_warning "PRIVATE_RT_IDS not set - will auto-discover all route tables in VPC"
fi

print_success "Configuration validated"

################################################################################
# GET VPC INFORMATION
################################################################################

print_info "Getting VPC information..."

VPC_CIDR=$(aws ec2 describe-vpcs \
    --vpc-ids $VPC_ID \
    --query 'Vpcs[0].CidrBlock' \
    --output text \
    --region $REGION)

if [ -z "$VPC_CIDR" ] || [ "$VPC_CIDR" = "None" ]; then
    print_error "Failed to get VPC CIDR block"
    exit 1
fi

print_success "VPC CIDR: $VPC_CIDR"

# Discover ALL route tables in the VPC (not just the ones provided)
print_info "Discovering all route tables in VPC..."

ALL_ROUTE_TABLE_IDS=$(aws ec2 describe-route-tables \
    --region ${REGION} \
    --filters "Name=vpc-id,Values=${VPC_ID}" \
    --query 'RouteTables[].RouteTableId' \
    --output text)

ROUTE_TABLE_COUNT=$(echo ${ALL_ROUTE_TABLE_IDS} | wc -w | tr -d ' ')

print_success "Found ${ROUTE_TABLE_COUNT} route tables in VPC"
for rt_id in ${ALL_ROUTE_TABLE_IDS}; do
    echo "   - ${rt_id}"
done

# If user provided specific route tables, show warning if they differ
if [ -n "$PRIVATE_RT_IDS" ]; then
    print_warning "You provided specific route tables: $PRIVATE_RT_IDS"
    print_warning "However, S3 Gateway Endpoint will be associated with ALL ${ROUTE_TABLE_COUNT} route tables for consistency"
fi

################################################################################
# CREATE SECURITY GROUP FOR VPC ENDPOINTS
################################################################################

if [ "$CREATE_SECURITY_GROUP" = "true" ]; then
    print_info "Creating Security Group for VPC Endpoints..."

    # Check if SG already exists
    EXISTING_SG=$(aws ec2 describe-security-groups \
        --filters "Name=group-name,Values=${CLUSTER_NAME}-vpc-endpoints-sg" \
                  "Name=vpc-id,Values=$VPC_ID" \
        --query 'SecurityGroups[0].GroupId' \
        --output text \
        --region $REGION 2>/dev/null || echo "None")

    if [ "$EXISTING_SG" != "None" ] && [ ! -z "$EXISTING_SG" ]; then
        SG_ID=$EXISTING_SG
        print_warning "Security Group already exists: $SG_ID"
    else
        SG_ID=$(aws ec2 create-security-group \
            --group-name "${CLUSTER_NAME}-vpc-endpoints-sg" \
            --description "Security group for VPC Endpoints - Allow HTTPS from VPC" \
            --vpc-id $VPC_ID \
            --query 'GroupId' \
            --output text \
            --region $REGION)

        print_success "Security Group created: $SG_ID"

        # Add HTTPS ingress rule
        aws ec2 authorize-security-group-ingress \
            --group-id $SG_ID \
            --protocol tcp \
            --port 443 \
            --cidr $VPC_CIDR \
            --region $REGION 2>/dev/null || true

        print_success "HTTPS ingress rule added (source: $VPC_CIDR)"

        # Add egress rule (allow all)
        aws ec2 authorize-security-group-egress \
            --group-id $SG_ID \
            --protocol -1 \
            --cidr 0.0.0.0/0 \
            --region $REGION 2>/dev/null || true

        print_success "Egress rule added (allow all)"

        # Tag the security group
        aws ec2 create-tags \
            --resources $SG_ID \
            --tags "Key=Name,Value=${CLUSTER_NAME}-vpc-endpoints-sg" \
                   "Key=Cluster,Value=${CLUSTER_NAME}" \
            --region $REGION

        print_success "Security Group tagged"
    fi
else
    print_warning "Using existing Security Group (CREATE_SECURITY_GROUP=false)"
    print_warning "Make sure your SG allows HTTPS (443) from VPC CIDR: $VPC_CIDR"
fi

################################################################################
# CREATE VPC ENDPOINTS
################################################################################

echo ""
print_info "Creating VPC Endpoints..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Function to create Interface VPC Endpoint
create_interface_endpoint() {
    local service_name=$1
    local endpoint_name=$2
    local description=$3

    echo ""
    print_info "Creating endpoint: $endpoint_name ($service_name)"
    echo "   Purpose: $description"

    # Check if endpoint already exists
    existing=$(aws ec2 describe-vpc-endpoints \
        --filters "Name=vpc-id,Values=$VPC_ID" \
                  "Name=service-name,Values=com.amazonaws.${REGION}.${service_name}" \
        --query 'VpcEndpoints[0].VpcEndpointId' \
        --output text \
        --region $REGION 2>/dev/null || echo "None")

    if [ "$existing" != "None" ] && [ ! -z "$existing" ]; then
        print_warning "Endpoint already exists: $existing"
        return
    fi

    endpoint_id=$(aws ec2 create-vpc-endpoint \
        --vpc-id $VPC_ID \
        --vpc-endpoint-type Interface \
        --service-name com.amazonaws.${REGION}.${service_name} \
        --subnet-ids $PRIVATE_SUBNET_IDS \
        --security-group-ids $SG_ID \
        --private-dns-enabled \
        --tag-specifications "ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=${CLUSTER_NAME}-${endpoint_name}},{Key=Cluster,Value=${CLUSTER_NAME}}]" \
        --query 'VpcEndpoint.VpcEndpointId' \
        --output text \
        --region $REGION 2>&1)

    if [[ $endpoint_id == vpce-* ]]; then
        print_success "Created: $endpoint_id"
    else
        print_error "Failed to create endpoint: $endpoint_id"
    fi
}

# Function to create Gateway VPC Endpoint
create_gateway_endpoint() {
    local service_name=$1
    local endpoint_name=$2
    local description=$3

    echo ""
    print_info "Creating endpoint: $endpoint_name ($service_name)"
    echo "   Purpose: $description"
    echo "   Associating with ${ROUTE_TABLE_COUNT} route tables"

    # Check if endpoint already exists
    existing=$(aws ec2 describe-vpc-endpoints \
        --filters "Name=vpc-id,Values=$VPC_ID" \
                  "Name=service-name,Values=com.amazonaws.${REGION}.${service_name}" \
        --query 'VpcEndpoints[0].VpcEndpointId' \
        --output text \
        --region $REGION 2>/dev/null || echo "None")

    if [ "$existing" != "None" ] && [ ! -z "$existing" ]; then
        print_warning "Endpoint already exists: $existing"
        print_info "Checking if all route tables are associated..."

        # Get current route tables
        CURRENT_RTS=$(aws ec2 describe-vpc-endpoints \
            --vpc-endpoint-ids ${existing} \
            --region ${REGION} \
            --query 'VpcEndpoints[0].RouteTableIds[]' \
            --output text)

        # Find missing route tables
        MISSING_RTS=""
        for rt_id in ${ALL_ROUTE_TABLE_IDS}; do
            if ! echo "${CURRENT_RTS}" | grep -q "${rt_id}"; then
                MISSING_RTS="${MISSING_RTS} ${rt_id}"
            fi
        done

        if [ -n "$MISSING_RTS" ]; then
            print_info "Adding missing route tables:${MISSING_RTS}"
            aws ec2 modify-vpc-endpoint \
                --vpc-endpoint-id ${existing} \
                --add-route-table-ids ${MISSING_RTS} \
                --region ${REGION}
            print_success "Route tables added to existing endpoint"
        else
            print_success "All route tables already associated"
        fi
        return
    fi

    # Create new endpoint with ALL route tables
    endpoint_id=$(aws ec2 create-vpc-endpoint \
        --vpc-id $VPC_ID \
        --vpc-endpoint-type Gateway \
        --service-name com.amazonaws.${REGION}.${service_name} \
        --route-table-ids ${ALL_ROUTE_TABLE_IDS} \
        --tag-specifications "ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=${CLUSTER_NAME}-${endpoint_name}},{Key=Cluster,Value=${CLUSTER_NAME}}]" \
        --query 'VpcEndpoint.VpcEndpointId' \
        --output text \
        --region $REGION 2>&1)

    if [[ $endpoint_id == vpce-* ]]; then
        print_success "Created: $endpoint_id (associated with ${ROUTE_TABLE_COUNT} route tables)"
    else
        print_error "Failed to create endpoint: $endpoint_id"
    fi
}

################################################################################
# ESSENTIAL ENDPOINTS (Always created)
################################################################################

echo ""
print_info "━━━ ESSENTIAL ENDPOINTS (Required for EKS) ━━━"

create_gateway_endpoint "s3" "s3" "ECR image layers, bootstrap scripts"
create_interface_endpoint "ecr.api" "ecr-api" "Docker authentication to ECR"
create_interface_endpoint "ecr.dkr" "ecr-dkr" "Pulling Docker images from ECR"
create_interface_endpoint "ec2" "ec2" "Node registration and instance metadata"
create_interface_endpoint "sts" "sts" "IAM authentication and IRSA"

################################################################################
# RECOMMENDED ENDPOINTS (For full functionality)
################################################################################

echo ""
print_info "━━━ RECOMMENDED ENDPOINTS (For logging, LB, autoscaling) ━━━"

create_interface_endpoint "logs" "logs" "CloudWatch Logs for control plane and pods"
create_interface_endpoint "elasticloadbalancing" "elb" "AWS Load Balancer Controller"
create_interface_endpoint "autoscaling" "autoscaling" "Cluster Autoscaler"
create_interface_endpoint "eks" "eks" "EKS API for kubectl operations"

################################################################################
# OPTIONAL ENDPOINTS
################################################################################

if [ "$ENABLE_EFS" = "true" ]; then
    echo ""
    print_info "━━━ OPTIONAL: EFS Endpoint ━━━"
    create_interface_endpoint "elasticfilesystem" "efs" "EFS CSI Driver"
fi

if [ "$ENABLE_SSM" = "true" ]; then
    echo ""
    print_info "━━━ OPTIONAL: SSM Endpoints (For Session Manager access) ━━━"
    create_interface_endpoint "ssm" "ssm" "AWS Systems Manager"
    create_interface_endpoint "ssmmessages" "ssmmessages" "Session Manager messaging"
    create_interface_endpoint "ec2messages" "ec2messages" "Session Manager EC2 messaging"
fi

################################################################################
# WAIT FOR ENDPOINTS TO BECOME AVAILABLE
################################################################################

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_info "Waiting for VPC Endpoints to become available..."
echo "This may take 2-3 minutes..."
echo ""

sleep 10

for i in {1..24}; do
    pending=$(aws ec2 describe-vpc-endpoints \
        --filters "Name=vpc-id,Values=$VPC_ID" \
        --query 'VpcEndpoints[?State==`pending`].VpcEndpointId' \
        --output text \
        --region $REGION | wc -w)

    if [ "$pending" -eq 0 ]; then
        print_success "All VPC Endpoints are available!"
        break
    fi

    echo -ne "   ⏳ Waiting... ($pending endpoints pending) [$(($i * 5))s / 120s]\r"
    sleep 5

    if [ $i -eq 24 ]; then
        print_warning "Some endpoints are still pending after 2 minutes"
        print_warning "They will continue provisioning in the background"
    fi
done

echo ""

################################################################################
# DISPLAY SUMMARY
################################################################################

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_success "VPC Endpoints Creation Complete!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Count endpoints
total_endpoints=$(aws ec2 describe-vpc-endpoints \
    --filters "Name=vpc-id,Values=$VPC_ID" \
    --query 'length(VpcEndpoints)' \
    --output text \
    --region $REGION)

echo "Summary:"
echo "  VPC ID:              $VPC_ID"
echo "  Region:              $REGION"
echo "  Cluster Name:        $CLUSTER_NAME"
echo "  Security Group:      $SG_ID"
echo "  Total Endpoints:     $total_endpoints"
echo ""

# Display all endpoints
print_info "VPC Endpoints Status:"
echo ""
aws ec2 describe-vpc-endpoints \
    --filters "Name=vpc-id,Values=$VPC_ID" \
    --query 'VpcEndpoints[*].[ServiceName,State,VpcEndpointId]' \
    --output table \
    --region $REGION

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_info "Next Steps:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "1. Verify all endpoints are in 'available' state:"
echo "   aws ec2 describe-vpc-endpoints --filters \"Name=vpc-id,Values=$VPC_ID\" --region $REGION"
echo ""
echo "2. If you have an existing EKS node group with issues, DELETE and RECREATE it:"
echo "   aws eks delete-nodegroup --cluster-name $CLUSTER_NAME --nodegroup-name default --region $REGION"
echo "   (wait for deletion to complete)"
echo "   aws eks create-nodegroup ..."
echo ""
echo "3. Or if using Terraform:"
echo "   terraform taint 'module.eks.aws_eks_node_group.this[\"default\"]'"
echo "   terraform apply"
echo ""
echo "4. Nodes should now successfully join the cluster!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_info "Cost Estimate:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Calculate interface endpoints (exclude S3 which is Gateway/free)
interface_count=$(($total_endpoints - 1))
subnets_count=$(echo $PRIVATE_SUBNET_IDS | wc -w)
monthly_cost=$(echo "$interface_count * $subnets_count * 0.01 * 730" | bc)

echo "  Interface Endpoints: $interface_count"
echo "  Subnets (AZs):       $subnets_count"
echo "  Estimated Cost:      ~\$${monthly_cost}/month"
echo "  (Gateway S3 endpoint is FREE)"
echo ""

################################################################################
# TROUBLESHOOTING INFORMATION
################################################################################

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_info "Troubleshooting:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "If nodes still fail to join:"
echo ""
echo "1. Check Private DNS is enabled:"
echo "   aws ec2 describe-vpc-endpoints --vpc-endpoint-ids <vpce-id> \\"
echo "     --query 'VpcEndpoints[0].PrivateDnsEnabled' --region $REGION"
echo "   (Should return: true)"
echo ""
echo "2. Check Security Group rules:"
echo "   aws ec2 describe-security-groups --group-ids $SG_ID --region $REGION"
echo "   (Should allow TCP 443 from $VPC_CIDR)"
echo ""
echo "3. Check subnet tags:"
echo "   aws ec2 describe-subnets --subnet-ids $PRIVATE_SUBNET_IDS --region $REGION"
echo "   (Should have: kubernetes.io/cluster/$CLUSTER_NAME=owned)"
echo ""
echo "4. View CloudWatch Logs for node issues:"
echo "   aws logs tail /aws/eks/$CLUSTER_NAME/cluster --follow --region $REGION"
echo ""

print_success "Script completed successfully!"
