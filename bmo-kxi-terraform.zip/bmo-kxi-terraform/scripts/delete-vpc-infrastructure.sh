#!/usr/bin/env bash

################################################################################
# AWS VPC Infrastructure Deletion Script
# Deletes: VPC Endpoints, EC2 Instance Connect Endpoints, Subnets,
#          Route Tables, Security Groups, Internet Gateway, VPC
################################################################################

# Ensure we're running with bash
if [ -z "$BASH_VERSION" ]; then
    echo "Error: This script requires bash. Please run with bash instead of sh."
    exit 1
fi

set -euo pipefail

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Parse arguments - accept both orders for backward compatibility
if [ -z "$1" ]; then
    echo -e "${RED}Usage: $0 <REGION> <VPC_ID>${NC}"
    echo -e "${RED}   or: $0 <VPC_ID> <REGION>${NC}"
    echo -e ""
    echo -e "Examples:"
    echo -e "  $0 us-west-1 vpc-0123456789abcdef"
    echo -e "  $0 vpc-0123456789abcdef us-west-1"
    exit 1
fi

# Detect which parameter is which
if [[ "$1" =~ ^vpc- ]]; then
    # Old format: VPC_ID REGION
    VPC_ID="$1"
    REGION="${2:-us-west-1}"
elif [[ "$2" =~ ^vpc- ]]; then
    # New format: REGION VPC_ID
    REGION="$1"
    VPC_ID="$2"
else
    echo -e "${RED}Error: Could not detect VPC ID. Must start with 'vpc-'${NC}"
    echo -e "${RED}Usage: $0 <REGION> <VPC_ID>${NC}"
    exit 1
fi

echo -e "${RED}========================================${NC}"
echo -e "${RED}AWS VPC Infrastructure Deletion${NC}"
echo -e "${RED}========================================${NC}"
echo ""
echo -e "VPC ID: ${RED}${VPC_ID}${NC}"
echo -e "Region: ${RED}${REGION}${NC}"
echo ""
echo -e "${YELLOW}WARNING: This will delete ALL resources in this VPC!${NC}"
echo -e "${YELLOW}This action cannot be undone.${NC}"
echo ""
read -p "Are you sure you want to continue? (type 'yes' to confirm): " CONFIRM

if [ "$CONFIRM" != "yes" ]; then
    echo -e "${BLUE}Deletion cancelled.${NC}"
    exit 0
fi

echo ""

# Delete EC2 Instance Connect Endpoints
echo -e "${YELLOW}[1/8] Deleting EC2 Instance Connect Endpoints...${NC}"
EC2_IC_ENDPOINTS=$(aws ec2 describe-instance-connect-endpoints \
    --region ${REGION} \
    --filters "Name=vpc-id,Values=${VPC_ID}" \
    --query 'InstanceConnectEndpoints[].InstanceConnectEndpointId' \
    --output text)

if [ -n "$EC2_IC_ENDPOINTS" ]; then
    for ENDPOINT_ID in $EC2_IC_ENDPOINTS; do
        echo -e "${BLUE}Deleting EC2 Instance Connect Endpoint: ${ENDPOINT_ID}${NC}"
        aws ec2 delete-instance-connect-endpoint \
            --instance-connect-endpoint-id ${ENDPOINT_ID} \
            --region ${REGION} || true
        echo -e "${GREEN}✓ Deleted: ${ENDPOINT_ID}${NC}"
    done
else
    echo -e "${BLUE}No EC2 Instance Connect Endpoints found${NC}"
fi
echo ""

# Delete VPC Endpoints
echo -e "${YELLOW}[2/8] Deleting VPC Endpoints...${NC}"
VPC_ENDPOINTS=$(aws ec2 describe-vpc-endpoints \
    --region ${REGION} \
    --filters "Name=vpc-id,Values=${VPC_ID}" \
    --query 'VpcEndpoints[].VpcEndpointId' \
    --output text)

if [ -n "$VPC_ENDPOINTS" ]; then
    for ENDPOINT_ID in $VPC_ENDPOINTS; do
        echo -e "${BLUE}Deleting VPC Endpoint: ${ENDPOINT_ID}${NC}"
        aws ec2 delete-vpc-endpoints \
            --vpc-endpoint-ids ${ENDPOINT_ID} \
            --region ${REGION} || true
        echo -e "${GREEN}✓ Deleted: ${ENDPOINT_ID}${NC}"
    done

    echo -e "${BLUE}Waiting for VPC Endpoints to be deleted...${NC}"
    sleep 30
else
    echo -e "${BLUE}No VPC Endpoints found${NC}"
fi
echo ""

# Delete NAT Gateways (if any)
echo -e "${YELLOW}[3/8] Deleting NAT Gateways...${NC}"
NAT_GATEWAYS=$(aws ec2 describe-nat-gateways \
    --region ${REGION} \
    --filter "Name=vpc-id,Values=${VPC_ID}" "Name=state,Values=available" \
    --query 'NatGateways[].NatGatewayId' \
    --output text)

if [ -n "$NAT_GATEWAYS" ]; then
    for NAT_ID in $NAT_GATEWAYS; do
        echo -e "${BLUE}Deleting NAT Gateway: ${NAT_ID}${NC}"
        aws ec2 delete-nat-gateway \
            --nat-gateway-id ${NAT_ID} \
            --region ${REGION}
        echo -e "${GREEN}✓ Deleted: ${NAT_ID}${NC}"
    done

    echo -e "${BLUE}Waiting for NAT Gateways to be deleted...${NC}"
    sleep 60
else
    echo -e "${BLUE}No NAT Gateways found${NC}"
fi
echo ""

# Release Elastic IPs
echo -e "${YELLOW}[4/8] Releasing Elastic IPs...${NC}"
EIPS=$(aws ec2 describe-addresses \
    --region ${REGION} \
    --filters "Name=domain,Values=vpc" \
    --query 'Addresses[?NetworkInterfaceId==null].AllocationId' \
    --output text)

if [ -n "$EIPS" ]; then
    for ALLOC_ID in $EIPS; do
        echo -e "${BLUE}Releasing EIP: ${ALLOC_ID}${NC}"
        aws ec2 release-address \
            --allocation-id ${ALLOC_ID} \
            --region ${REGION} || true
        echo -e "${GREEN}✓ Released: ${ALLOC_ID}${NC}"
    done
else
    echo -e "${BLUE}No Elastic IPs to release${NC}"
fi
echo ""

# Detach and delete Internet Gateway
echo -e "${YELLOW}[5/8] Deleting Internet Gateway...${NC}"
IGW_ID=$(aws ec2 describe-internet-gateways \
    --region ${REGION} \
    --filters "Name=attachment.vpc-id,Values=${VPC_ID}" \
    --query 'InternetGateways[0].InternetGatewayId' \
    --output text)

if [ "$IGW_ID" != "None" ] && [ -n "$IGW_ID" ]; then
    echo -e "${BLUE}Detaching Internet Gateway: ${IGW_ID}${NC}"
    aws ec2 detach-internet-gateway \
        --internet-gateway-id ${IGW_ID} \
        --vpc-id ${VPC_ID} \
        --region ${REGION} || true

    echo -e "${BLUE}Deleting Internet Gateway: ${IGW_ID}${NC}"
    aws ec2 delete-internet-gateway \
        --internet-gateway-id ${IGW_ID} \
        --region ${REGION} || true
    echo -e "${GREEN}✓ Deleted: ${IGW_ID}${NC}"
else
    echo -e "${BLUE}No Internet Gateway found${NC}"
fi
echo ""

# Delete Subnets
echo -e "${YELLOW}[6/8] Deleting Subnets...${NC}"
SUBNETS=$(aws ec2 describe-subnets \
    --region ${REGION} \
    --filters "Name=vpc-id,Values=${VPC_ID}" \
    --query 'Subnets[].SubnetId' \
    --output text)

if [ -n "$SUBNETS" ]; then
    for SUBNET_ID in $SUBNETS; do
        echo -e "${BLUE}Deleting Subnet: ${SUBNET_ID}${NC}"
        aws ec2 delete-subnet \
            --subnet-id ${SUBNET_ID} \
            --region ${REGION} || true
        echo -e "${GREEN}✓ Deleted: ${SUBNET_ID}${NC}"
    done
else
    echo -e "${BLUE}No Subnets found${NC}"
fi
echo ""

# Delete Route Tables (except main)
echo -e "${YELLOW}[7/8] Deleting Route Tables...${NC}"
ROUTE_TABLES=$(aws ec2 describe-route-tables \
    --region ${REGION} \
    --filters "Name=vpc-id,Values=${VPC_ID}" \
    --query 'RouteTables[?Associations[0].Main!=`true`].RouteTableId' \
    --output text)

if [ -n "$ROUTE_TABLES" ]; then
    for RT_ID in $ROUTE_TABLES; do
        echo -e "${BLUE}Deleting Route Table: ${RT_ID}${NC}"
        aws ec2 delete-route-table \
            --route-table-id ${RT_ID} \
            --region ${REGION} || true
        echo -e "${GREEN}✓ Deleted: ${RT_ID}${NC}"
    done
else
    echo -e "${BLUE}No custom Route Tables found${NC}"
fi
echo ""

# Delete Security Groups (except default)
echo -e "${YELLOW}[8/8] Deleting Security Groups...${NC}"
SECURITY_GROUPS=$(aws ec2 describe-security-groups \
    --region ${REGION} \
    --filters "Name=vpc-id,Values=${VPC_ID}" \
    --query 'SecurityGroups[?GroupName!=`default`].GroupId' \
    --output text)

if [ -n "$SECURITY_GROUPS" ]; then
    # First, remove all rules to avoid dependency issues
    for SG_ID in $SECURITY_GROUPS; do
        echo -e "${BLUE}Removing rules from Security Group: ${SG_ID}${NC}"

        # Remove ingress rules
        aws ec2 describe-security-groups \
            --group-ids ${SG_ID} \
            --region ${REGION} \
            --query 'SecurityGroups[0].IpPermissions' \
            --output json > /tmp/sg-ingress-${SG_ID}.json

        if [ -s /tmp/sg-ingress-${SG_ID}.json ] && [ "$(cat /tmp/sg-ingress-${SG_ID}.json)" != "[]" ]; then
            aws ec2 revoke-security-group-ingress \
                --group-id ${SG_ID} \
                --ip-permissions file:///tmp/sg-ingress-${SG_ID}.json \
                --region ${REGION} 2>/dev/null || true
        fi

        # Remove egress rules
        aws ec2 describe-security-groups \
            --group-ids ${SG_ID} \
            --region ${REGION} \
            --query 'SecurityGroups[0].IpPermissionsEgress' \
            --output json > /tmp/sg-egress-${SG_ID}.json

        if [ -s /tmp/sg-egress-${SG_ID}.json ] && [ "$(cat /tmp/sg-egress-${SG_ID}.json)" != "[]" ]; then
            aws ec2 revoke-security-group-egress \
                --group-id ${SG_ID} \
                --ip-permissions file:///tmp/sg-egress-${SG_ID}.json \
                --region ${REGION} 2>/dev/null || true
        fi
    done

    # Now delete the security groups
    for SG_ID in $SECURITY_GROUPS; do
        echo -e "${BLUE}Deleting Security Group: ${SG_ID}${NC}"
        aws ec2 delete-security-group \
            --group-id ${SG_ID} \
            --region ${REGION} || true
        echo -e "${GREEN}✓ Deleted: ${SG_ID}${NC}"
    done
else
    echo -e "${BLUE}No custom Security Groups found${NC}"
fi
echo ""

# Delete VPC
echo -e "${YELLOW}Deleting VPC...${NC}"
aws ec2 delete-vpc \
    --vpc-id ${VPC_ID} \
    --region ${REGION}
echo -e "${GREEN}✓ VPC Deleted: ${VPC_ID}${NC}"
echo ""

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}VPC Infrastructure Deleted Successfully!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
