#!/usr/bin/env bash

################################################################################
# AWS VPC Infrastructure Creation Script
# Creates: VPC, Subnets, Route Tables, VPC Endpoints, Security Groups
# For: Private EKS clusters without NAT Gateway
#
# Usage:
#   # Create new VPC
#   ./create-vpc-infrastructure.sh <REGION> <CLUSTER_NAME>
#
#   # Use existing VPC (only create endpoints)
#   ./create-vpc-infrastructure.sh <REGION> <CLUSTER_NAME> <VPC_ID> <SUBNET_IDS>
#
# Example with existing VPC:
#   ./create-vpc-infrastructure.sh us-west-1 my-cluster vpc-xxx "subnet-aaa,subnet-bbb,subnet-ccc"
################################################################################

# Ensure we're running with bash
if [ -z "$BASH_VERSION" ]; then
    echo "Error: This script requires bash. Please run with bash instead of sh."
    exit 1
fi

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Parse arguments
REGION="${1:-us-west-1}"
CLUSTER_NAME="${2:-eks-private-cluster}"
EXISTING_VPC_ID="${3}"
EXISTING_SUBNET_IDS="${4}"
VPC_CIDR="10.0.0.0/16"

# Determine if using existing VPC
USE_EXISTING_VPC=false
if [ -n "$EXISTING_VPC_ID" ]; then
    USE_EXISTING_VPC=true
fi

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}AWS VPC Infrastructure Setup${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "Region: ${GREEN}${REGION}${NC}"
echo -e "Cluster Name: ${GREEN}${CLUSTER_NAME}${NC}"

if [ "$USE_EXISTING_VPC" = true ]; then
    echo -e "Mode: ${YELLOW}Using Existing VPC${NC}"
    echo -e "VPC ID: ${GREEN}${EXISTING_VPC_ID}${NC}"
    echo -e "Subnet IDs: ${GREEN}${EXISTING_SUBNET_IDS}${NC}"
else
    echo -e "Mode: ${YELLOW}Creating New VPC${NC}"
    echo -e "VPC CIDR: ${GREEN}${VPC_CIDR}${NC}"
fi
echo ""

# Check if AWS CLI is installed
echo -e "${YELLOW}[1/12] Checking prerequisites...${NC}"
if ! command -v aws >/dev/null 2>&1; then
    echo -e "${RED}Error: AWS CLI is not installed.${NC}"
    echo -e "${YELLOW}Install: https://aws.amazon.com/cli/${NC}"
    exit 1
fi
echo -e "${GREEN}✓ AWS CLI found${NC}"

# Check AWS credentials
echo -e "${YELLOW}[2/12] Checking AWS credentials...${NC}"
if ! aws sts get-caller-identity --region ${REGION} >/dev/null 2>&1; then
    echo -e "${RED}Error: AWS credentials not configured.${NC}"
    echo -e "${YELLOW}Run: aws configure${NC}"
    exit 1
fi
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
echo -e "${GREEN}✓ Connected to AWS Account: ${ACCOUNT_ID}${NC}"
echo ""

# Setup VPC and Subnets
if [ "$USE_EXISTING_VPC" = true ]; then
    echo -e "${YELLOW}[2/12] Validating existing VPC...${NC}"

    # Validate VPC exists
    VPC_ID=$EXISTING_VPC_ID
    VPC_EXISTS=$(aws ec2 describe-vpcs \
        --vpc-ids ${VPC_ID} \
        --region ${REGION} \
        --query 'Vpcs[0].VpcId' \
        --output text 2>/dev/null || echo "None")

    if [ "$VPC_EXISTS" = "None" ]; then
        echo -e "${RED}Error: VPC ${VPC_ID} not found in region ${REGION}${NC}"
        exit 1
    fi

    # Get VPC CIDR
    VPC_CIDR=$(aws ec2 describe-vpcs \
        --vpc-ids ${VPC_ID} \
        --region ${REGION} \
        --query 'Vpcs[0].CidrBlock' \
        --output text)

    echo -e "${GREEN}✓ VPC exists: ${VPC_ID} (${VPC_CIDR})${NC}"

    # Parse and validate subnets
    # Convert comma-separated string to array
    IFS=',' read -ra PRIVATE_SUBNET_IDS <<< "$EXISTING_SUBNET_IDS"

    if [ ${#PRIVATE_SUBNET_IDS[@]} -lt 2 ]; then
        echo -e "${RED}Error: Need at least 2 subnets for EKS.${NC}"
        exit 1
    fi

    echo -e "${GREEN}✓ Using ${#PRIVATE_SUBNET_IDS[@]} existing subnets${NC}"

    # Validate each subnet and collect AZs
    AZS=()
    for SUBNET_ID in "${PRIVATE_SUBNET_IDS[@]}"; do
        SUBNET_EXISTS=$(aws ec2 describe-subnets \
            --subnet-ids ${SUBNET_ID} \
            --region ${REGION} \
            --query 'Subnets[0].SubnetId' \
            --output text 2>/dev/null || echo "None")

        if [ "$SUBNET_EXISTS" = "None" ]; then
            echo -e "${RED}Error: Subnet ${SUBNET_ID} not found${NC}"
            exit 1
        fi

        SUBNET_AZ=$(aws ec2 describe-subnets \
            --subnet-ids ${SUBNET_ID} \
            --region ${REGION} \
            --query 'Subnets[0].AvailabilityZone' \
            --output text)

        SUBNET_CIDR=$(aws ec2 describe-subnets \
            --subnet-ids ${SUBNET_ID} \
            --region ${REGION} \
            --query 'Subnets[0].CidrBlock' \
            --output text)

        AZS+=("${SUBNET_AZ}")
        echo -e "${GREEN}  ✓ Subnet ${SUBNET_ID} (${SUBNET_AZ}, ${SUBNET_CIDR})${NC}"
    done
    echo ""

    # Get route tables from existing subnets
    echo -e "${YELLOW}[3/12] Getting route table from subnets...${NC}"
    ROUTE_TABLE_ID=$(aws ec2 describe-route-tables \
        --region ${REGION} \
        --filters "Name=association.subnet-id,Values=${PRIVATE_SUBNET_IDS[0]}" \
        --query 'RouteTables[0].RouteTableId' \
        --output text)

    if [ "$ROUTE_TABLE_ID" = "None" ] || [ -z "$ROUTE_TABLE_ID" ]; then
        # Get main route table
        ROUTE_TABLE_ID=$(aws ec2 describe-route-tables \
            --region ${REGION} \
            --filters "Name=vpc-id,Values=${VPC_ID}" "Name=association.main,Values=true" \
            --query 'RouteTables[0].RouteTableId' \
            --output text)
    fi

    echo -e "${GREEN}✓ Using Route Table: ${ROUTE_TABLE_ID}${NC}"
    echo ""

else
    # Create new VPC and subnets
    echo -e "${YELLOW}[2/12] Getting availability zones...${NC}"
    AZS=($(aws ec2 describe-availability-zones \
        --region ${REGION} \
        --filters "Name=state,Values=available" \
        --query 'AvailabilityZones[0:3].ZoneName' \
        --output text))

    if [ ${#AZS[@]} -lt 2 ]; then
        echo -e "${RED}Error: Need at least 2 availability zones.${NC}"
        exit 1
    fi

    echo -e "${GREEN}✓ Using AZs: ${AZS[0]}, ${AZS[1]}, ${AZS[2]}${NC}"
    echo ""

    # Create VPC
    echo -e "${YELLOW}[3/12] Creating VPC...${NC}"
    VPC_ID=$(aws ec2 create-vpc \
        --cidr-block ${VPC_CIDR} \
        --region ${REGION} \
        --tag-specifications "ResourceType=vpc,Tags=[{Key=Name,Value=${CLUSTER_NAME}},{Key=kubernetes.io/cluster/${CLUSTER_NAME},Value=owned}]" \
        --query 'Vpc.VpcId' \
        --output text)

    echo -e "${GREEN}✓ VPC Created: ${VPC_ID}${NC}"

    # Enable DNS hostnames and DNS support
    aws ec2 modify-vpc-attribute --vpc-id ${VPC_ID} --enable-dns-hostnames --region ${REGION}
    aws ec2 modify-vpc-attribute --vpc-id ${VPC_ID} --enable-dns-support --region ${REGION}
    echo -e "${GREEN}✓ DNS hostnames and support enabled${NC}"
    echo ""
fi

# Create Internet Gateway (optional, only if you want bastion or debugging)
# echo -e "${YELLOW}[4/12] Creating Internet Gateway...${NC}"
# IGW_ID=$(aws ec2 create-internet-gateway \
#     --region ${REGION} \
#     --tag-specifications "ResourceType=internet-gateway,Tags=[{Key=Name,Value=${CLUSTER_NAME}-igw}]" \
#     --query 'InternetGateway.InternetGatewayId' \
#     --output text)
#
# aws ec2 attach-internet-gateway \
#     --vpc-id ${VPC_ID} \
#     --internet-gateway-id ${IGW_ID} \
#     --region ${REGION}
#
# echo -e "${GREEN}✓ Internet Gateway Created: ${IGW_ID}${NC}"
# echo ""

if [ "$USE_EXISTING_VPC" = false ]; then
    # Create Private Subnets
    echo -e "${YELLOW}[4/12] Creating private subnets...${NC}"
    PRIVATE_SUBNET_IDS=()
    for i in "${!AZS[@]}"; do
        CIDR="10.0.$((i * 16)).0/20"
        SUBNET_ID=$(aws ec2 create-subnet \
            --vpc-id ${VPC_ID} \
            --cidr-block ${CIDR} \
            --availability-zone ${AZS[$i]} \
            --region ${REGION} \
            --tag-specifications "ResourceType=subnet,Tags=[{Key=Name,Value=${CLUSTER_NAME}-private-${AZS[$i]}},{Key=kubernetes.io/cluster/${CLUSTER_NAME},Value=owned},{Key=kubernetes.io/role/internal-elb,Value=1},{Key=Type,Value=private}]" \
            --query 'Subnet.SubnetId' \
            --output text)

        PRIVATE_SUBNET_IDS+=("${SUBNET_ID}")
        echo -e "${GREEN}✓ Private Subnet Created: ${SUBNET_ID} (${AZS[$i]}, ${CIDR})${NC}"
    done
    echo ""

    # Create Route Table for Private Subnets
    echo -e "${YELLOW}[5/12] Creating route table...${NC}"
    ROUTE_TABLE_ID=$(aws ec2 create-route-table \
        --vpc-id ${VPC_ID} \
        --region ${REGION} \
        --tag-specifications "ResourceType=route-table,Tags=[{Key=Name,Value=${CLUSTER_NAME}-private-rt}]" \
        --query 'RouteTable.RouteTableId' \
        --output text)

    echo -e "${GREEN}✓ Route Table Created: ${ROUTE_TABLE_ID}${NC}"

    # Associate subnets with route table
    for SUBNET_ID in "${PRIVATE_SUBNET_IDS[@]}"; do
        aws ec2 associate-route-table \
            --subnet-id ${SUBNET_ID} \
            --route-table-id ${ROUTE_TABLE_ID} \
            --region ${REGION} > /dev/null
        echo -e "${GREEN}✓ Subnet ${SUBNET_ID} associated with route table${NC}"
    done
    echo ""
else
    echo -e "${YELLOW}[4/12] Skipping subnet creation (using existing)${NC}"
    echo -e "${YELLOW}[5/12] Skipping route table creation (using existing)${NC}"
    echo ""
fi

# Create Security Group for VPC Endpoints
echo -e "${YELLOW}[6/12] Creating security group for VPC Endpoints...${NC}"

# Check if security group already exists
EXISTING_SG=$(aws ec2 describe-security-groups \
    --region ${REGION} \
    --filters "Name=group-name,Values=${CLUSTER_NAME}-vpc-endpoints-sg" "Name=vpc-id,Values=${VPC_ID}" \
    --query 'SecurityGroups[0].GroupId' \
    --output text 2>/dev/null || echo "None")

if [ "$EXISTING_SG" != "None" ] && [ -n "$EXISTING_SG" ]; then
    echo -e "${YELLOW}⚠ Security Group already exists: ${EXISTING_SG}${NC}"
    VPC_ENDPOINT_SG_ID=$EXISTING_SG
else
    VPC_ENDPOINT_SG_ID=$(aws ec2 create-security-group \
        --group-name "${CLUSTER_NAME}-vpc-endpoints-sg" \
        --description "Security group for VPC Endpoints - Allow HTTPS from VPC" \
        --vpc-id ${VPC_ID} \
        --region ${REGION} \
        --tag-specifications "ResourceType=security-group,Tags=[{Key=Name,Value=${CLUSTER_NAME}-vpc-endpoints-sg}]" \
        --query 'GroupId' \
        --output text)

    echo -e "${GREEN}✓ Security Group Created: ${VPC_ENDPOINT_SG_ID}${NC}"

    # Add ingress rule: Allow HTTPS (443) from VPC CIDR
    aws ec2 authorize-security-group-ingress \
        --group-id ${VPC_ENDPOINT_SG_ID} \
        --protocol tcp \
        --port 443 \
        --cidr ${VPC_CIDR} \
        --region ${REGION}

    echo -e "${GREEN}✓ Added ingress rule: HTTPS from VPC CIDR${NC}"

    # Add egress rule: Allow all outbound
    aws ec2 authorize-security-group-egress \
        --group-id ${VPC_ENDPOINT_SG_ID} \
        --protocol -1 \
        --cidr 0.0.0.0/0 \
        --region ${REGION} 2>/dev/null || true

    echo -e "${GREEN}✓ Egress rules configured${NC}"
fi
echo ""

# Create VPC Endpoints
echo -e "${YELLOW}[7/12] Creating VPC Endpoints...${NC}"
echo ""

# Get ALL route tables in the VPC (not just the one we created)
echo -e "${BLUE}Discovering all route tables in VPC...${NC}"
ALL_ROUTE_TABLE_IDS=$(aws ec2 describe-route-tables \
    --region ${REGION} \
    --filters "Name=vpc-id,Values=${VPC_ID}" \
    --query 'RouteTables[].RouteTableId' \
    --output text)

ROUTE_TABLE_COUNT=$(echo ${ALL_ROUTE_TABLE_IDS} | wc -w)
echo -e "${GREEN}✓ Found ${ROUTE_TABLE_COUNT} route tables:${NC}"
for rt_id in ${ALL_ROUTE_TABLE_IDS}; do
    echo -e "${GREEN}  - ${rt_id}${NC}"
done
echo ""

# S3 Gateway Endpoint (Free) - Associate with ALL route tables
echo -e "${BLUE}Creating S3 Gateway Endpoint...${NC}"
echo -e "${BLUE}This will be associated with all ${ROUTE_TABLE_COUNT} route tables automatically${NC}"

# Check if S3 endpoint already exists
EXISTING_S3_ENDPOINT=$(aws ec2 describe-vpc-endpoints \
    --region ${REGION} \
    --filters "Name=vpc-id,Values=${VPC_ID}" "Name=service-name,Values=com.amazonaws.${REGION}.s3" \
    --query 'VpcEndpoints[0].VpcEndpointId' \
    --output text 2>/dev/null)

if [ "$EXISTING_S3_ENDPOINT" != "None" ] && [ -n "$EXISTING_S3_ENDPOINT" ]; then
    echo -e "${YELLOW}⚠ S3 Gateway Endpoint already exists: ${EXISTING_S3_ENDPOINT}${NC}"
    echo -e "${BLUE}Adding missing route tables to existing endpoint...${NC}"

    # Get current route tables
    CURRENT_RTS=$(aws ec2 describe-vpc-endpoints \
        --vpc-endpoint-ids ${EXISTING_S3_ENDPOINT} \
        --region ${REGION} \
        --query 'VpcEndpoints[0].RouteTableIds[]' \
        --output text)

    # Find missing route tables
    MISSING_RTS=""
    for rt_id in ${ALL_ROUTE_TABLE_IDS}; do
        if ! echo "${CURRENT_RTS}" | grep -q "${rt_id}"; then
            MISSING_RTS="${MISSING_RTS} ${rt_id}"
        fi
    done

    if [ -n "$MISSING_RTS" ]; then
        echo -e "${BLUE}Adding route tables:${MISSING_RTS}${NC}"
        aws ec2 modify-vpc-endpoint \
            --vpc-endpoint-id ${EXISTING_S3_ENDPOINT} \
            --add-route-table-ids ${MISSING_RTS} \
            --region ${REGION}
        echo -e "${GREEN}✓ Route tables added to existing S3 endpoint${NC}"
    else
        echo -e "${GREEN}✓ All route tables already associated${NC}"
    fi

    S3_ENDPOINT_ID=${EXISTING_S3_ENDPOINT}
else
    # Create new S3 endpoint with all route tables
    S3_ENDPOINT_ID=$(aws ec2 create-vpc-endpoint \
        --vpc-id ${VPC_ID} \
        --service-name com.amazonaws.${REGION}.s3 \
        --route-table-ids ${ALL_ROUTE_TABLE_IDS} \
        --region ${REGION} \
        --tag-specifications "ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=${CLUSTER_NAME}-s3-endpoint}]" \
        --query 'VpcEndpoint.VpcEndpointId' \
        --output text)
    echo -e "${GREEN}✓ S3 Gateway Endpoint created: ${S3_ENDPOINT_ID}${NC}"
fi

echo -e "${GREEN}✓ S3 Endpoint associated with ${ROUTE_TABLE_COUNT} route tables${NC}"

# Interface Endpoints
declare -A ENDPOINTS=(
    ["ecr.api"]="ECR API"
    ["ecr.dkr"]="ECR Docker"
    ["ec2"]="EC2"
    ["sts"]="STS"
    ["logs"]="CloudWatch Logs"
    ["elasticloadbalancing"]="Elastic Load Balancing"
    ["autoscaling"]="Autoscaling"
    ["eks"]="EKS"
    ["ssm"]="Systems Manager"
    ["ssmmessages"]="SSM Messages"
    ["ec2messages"]="EC2 Messages"
)

# ECR Public is only available in us-east-1
if [ "$REGION" = "us-east-1" ]; then
    ENDPOINTS["ecr-public"]="ECR Public"
else
    echo -e "${YELLOW}Note: ECR Public endpoint is only available in us-east-1 (skipping)${NC}"
fi

SUBNET_IDS_STR=$(IFS=,; echo "${PRIVATE_SUBNET_IDS[*]}")

for service in "${!ENDPOINTS[@]}"; do
    echo -e "${BLUE}Creating ${ENDPOINTS[$service]} Endpoint...${NC}"

    # Check if endpoint already exists
    EXISTING_ENDPOINT=$(aws ec2 describe-vpc-endpoints \
        --region ${REGION} \
        --filters "Name=vpc-id,Values=${VPC_ID}" "Name=service-name,Values=com.amazonaws.${REGION}.${service}" \
        --query 'VpcEndpoints[0].VpcEndpointId' \
        --output text 2>/dev/null)

    if [ "$EXISTING_ENDPOINT" != "None" ] && [ -n "$EXISTING_ENDPOINT" ]; then
        echo -e "${YELLOW}⚠ ${ENDPOINTS[$service]} Endpoint already exists: ${EXISTING_ENDPOINT}${NC}"
        continue
    fi

    # Create endpoint with error handling
    ENDPOINT_ID=$(timeout 60 aws ec2 create-vpc-endpoint \
        --vpc-id ${VPC_ID} \
        --vpc-endpoint-type Interface \
        --service-name com.amazonaws.${REGION}.${service} \
        --subnet-ids ${PRIVATE_SUBNET_IDS[@]} \
        --security-group-ids ${VPC_ENDPOINT_SG_ID} \
        --private-dns-enabled \
        --region ${REGION} \
        --tag-specifications "ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=${CLUSTER_NAME}-${service}-endpoint}]" \
        --query 'VpcEndpoint.VpcEndpointId' \
        --output text 2>&1)

    if [[ $ENDPOINT_ID == vpc-* ]]; then
        echo -e "${GREEN}✓ ${ENDPOINTS[$service]} Endpoint: ${ENDPOINT_ID}${NC}"
    elif [[ $ENDPOINT_ID == *"Timeout"* ]]; then
        echo -e "${RED}✗ ${ENDPOINTS[$service]} Endpoint: Command timed out${NC}"
    else
        echo -e "${YELLOW}⚠ ${ENDPOINTS[$service]} Endpoint: ${ENDPOINT_ID}${NC}"
    fi

    # Small delay to avoid rate limiting
    sleep 2
done
echo ""

# Optional: EFS Endpoint (if using EFS)
echo -e "${BLUE}Creating EFS Endpoint (optional)...${NC}"

# Check if endpoint already exists
EXISTING_EFS_ENDPOINT=$(aws ec2 describe-vpc-endpoints \
    --region ${REGION} \
    --filters "Name=vpc-id,Values=${VPC_ID}" "Name=service-name,Values=com.amazonaws.${REGION}.elasticfilesystem" \
    --query 'VpcEndpoints[0].VpcEndpointId' \
    --output text 2>/dev/null || echo "None")

if [ "$EXISTING_EFS_ENDPOINT" != "None" ] && [ -n "$EXISTING_EFS_ENDPOINT" ]; then
    echo -e "${YELLOW}⚠ EFS Endpoint already exists: ${EXISTING_EFS_ENDPOINT}${NC}"
else
    EFS_ENDPOINT_ID=$(timeout 60 aws ec2 create-vpc-endpoint \
        --vpc-id ${VPC_ID} \
        --vpc-endpoint-type Interface \
        --service-name com.amazonaws.${REGION}.elasticfilesystem \
        --subnet-ids ${PRIVATE_SUBNET_IDS[@]} \
        --security-group-ids ${VPC_ENDPOINT_SG_ID} \
        --private-dns-enabled \
        --region ${REGION} \
        --tag-specifications "ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=${CLUSTER_NAME}-efs-endpoint}]" \
        --query 'VpcEndpoint.VpcEndpointId' \
        --output text 2>&1) || true

    if [[ $EFS_ENDPOINT_ID == vpc-* ]]; then
        echo -e "${GREEN}✓ EFS Endpoint: ${EFS_ENDPOINT_ID}${NC}"
    else
        echo -e "${YELLOW}⚠ EFS Endpoint not created (may not be available in this region)${NC}"
    fi
fi
echo ""

# Create EC2 Instance Connect Endpoint (one per subnet for redundancy)
echo -e "${YELLOW}[8/12] Creating EC2 Instance Connect Endpoints...${NC}"
EC2_IC_ENDPOINT_IDS=()
for i in "${!PRIVATE_SUBNET_IDS[@]}"; do
    echo -e "${BLUE}Checking EC2 Instance Connect Endpoint in ${AZS[$i]}...${NC}"

    # Check if endpoint already exists in this subnet
    EXISTING_EC2_IC=$(aws ec2 describe-instance-connect-endpoints \
        --region ${REGION} \
        --filters "Name=subnet-id,Values=${PRIVATE_SUBNET_IDS[$i]}" "Name=vpc-id,Values=${VPC_ID}" \
        --query 'InstanceConnectEndpoints[0].InstanceConnectEndpointId' \
        --output text 2>/dev/null || echo "None")

    if [ "$EXISTING_EC2_IC" != "None" ] && [ -n "$EXISTING_EC2_IC" ]; then
        echo -e "${YELLOW}⚠ EC2 Instance Connect Endpoint already exists: ${EXISTING_EC2_IC}${NC}"
        EC2_IC_ENDPOINT_IDS+=("${EXISTING_EC2_IC}")
    else
        EC2_IC_ID=$(aws ec2 create-instance-connect-endpoint \
            --subnet-id ${PRIVATE_SUBNET_IDS[$i]} \
            --security-group-ids ${VPC_ENDPOINT_SG_ID} \
            --region ${REGION} \
            --tag-specifications "ResourceType=instance-connect-endpoint,Tags=[{Key=Name,Value=${CLUSTER_NAME}-ec2-ic-${i}}]" \
            --query 'InstanceConnectEndpoint.InstanceConnectEndpointId' \
            --output text 2>&1) || true

        if [[ $EC2_IC_ID == eice-* ]]; then
            EC2_IC_ENDPOINT_IDS+=("${EC2_IC_ID}")
            echo -e "${GREEN}✓ EC2 Instance Connect Endpoint: ${EC2_IC_ID}${NC}"
        else
            echo -e "${YELLOW}⚠ EC2 Instance Connect Endpoint: ${EC2_IC_ID}${NC}"
        fi
    fi

    sleep 2
done
echo ""

# Wait for endpoints to become available
echo -e "${YELLOW}[9/12] Waiting for VPC Endpoints to become available...${NC}"
echo -e "${BLUE}This may take 2-5 minutes...${NC}"

MAX_WAIT=300  # 5 minutes
ELAPSED=0
while [ $ELAPSED -lt $MAX_WAIT ]; do
    PENDING=$(aws ec2 describe-vpc-endpoints \
        --region ${REGION} \
        --filters "Name=vpc-id,Values=${VPC_ID}" \
        --query 'VpcEndpoints[?State==`pending`].VpcEndpointId' \
        --output text | wc -w)

    if [ $PENDING -eq 0 ]; then
        echo -e "${GREEN}✓ All VPC Endpoints are available${NC}"
        break
    fi

    echo -e "${YELLOW}⏳ Still waiting for ${PENDING} endpoints... (${ELAPSED}s elapsed)${NC}"
    sleep 10
    ELAPSED=$((ELAPSED + 10))
done
echo ""

# Summary
echo -e "${YELLOW}[10/12] Generating summary...${NC}"
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Infrastructure Created Successfully!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${BLUE}VPC Information:${NC}"
echo -e "  VPC ID: ${GREEN}${VPC_ID}${NC}"
echo -e "  VPC CIDR: ${GREEN}${VPC_CIDR}${NC}"
echo -e "  Region: ${GREEN}${REGION}${NC}"
echo ""
echo -e "${BLUE}Private Subnets:${NC}"
for i in "${!PRIVATE_SUBNET_IDS[@]}"; do
    echo -e "  Subnet ${i}: ${GREEN}${PRIVATE_SUBNET_IDS[$i]}${NC} (${AZS[$i]})"
done
echo ""
echo -e "${BLUE}Route Tables:${NC}"
if [ "$USE_EXISTING_VPC" = true ]; then
    echo -e "  Total Route Tables: ${GREEN}${ROUTE_TABLE_COUNT}${NC}"
    echo -e "  Route Table IDs: ${GREEN}${ALL_ROUTE_TABLE_IDS}${NC}"
else
    echo -e "  Route Table ID: ${GREEN}${ROUTE_TABLE_ID}${NC}"
fi
echo ""
echo -e "${BLUE}Security Group:${NC}"
echo -e "  VPC Endpoints SG: ${GREEN}${VPC_ENDPOINT_SG_ID}${NC}"
echo ""
echo -e "${BLUE}VPC Endpoints:${NC}"
echo -e "  S3 Gateway: ${GREEN}${S3_ENDPOINT_ID}${NC} (associated with ${ROUTE_TABLE_COUNT} route tables)"
echo -e "  Total Interface Endpoints: ${GREEN}$(aws ec2 describe-vpc-endpoints --region ${REGION} --filters "Name=vpc-id,Values=${VPC_ID}" "Name=vpc-endpoint-type,Values=Interface" --query 'VpcEndpoints[].VpcEndpointId' --output text | wc -w)${NC}"
echo ""

# Export variables for Terraform
echo -e "${YELLOW}[11/12] Generating Terraform variables...${NC}"
cat > /tmp/vpc-outputs.txt <<EOF
# Copy these values to your terraform.tfvars

existing_vpc          = true
private_only          = true
vpc_id                = "${VPC_ID}"
private_subnets_ids   = [$(printf '"%s",' "${PRIVATE_SUBNET_IDS[@]}" | sed 's/,$//')]
region                = "${REGION}"
cluster_name          = "${CLUSTER_NAME}"

# Note: You may need these for bastion/public resources (optional)
# public_network_acl_id = ""  # Not created in this script
# bastion_host_sg_id    = ""  # Not created in this script
EOF

echo -e "${GREEN}✓ Terraform variables saved to: /tmp/vpc-outputs.txt${NC}"
echo ""
cat /tmp/vpc-outputs.txt
echo ""

# Generate AWS CLI commands for reference
echo -e "${YELLOW}[12/12] Generating reference commands...${NC}"
cat > /tmp/vpc-reference-commands.txt <<EOF
# Reference Commands

## View VPC Endpoints
aws ec2 describe-vpc-endpoints \\
  --region ${REGION} \\
  --filters "Name=vpc-id,Values=${VPC_ID}" \\
  --output table

## View Subnets
aws ec2 describe-subnets \\
  --region ${REGION} \\
  --filters "Name=vpc-id,Values=${VPC_ID}" \\
  --output table

## View Route Tables
aws ec2 describe-route-tables \\
  --region ${REGION} \\
  --filters "Name=vpc-id,Values=${VPC_ID}" \\
  --output table

## View Security Groups
aws ec2 describe-security-groups \\
  --region ${REGION} \\
  --filters "Name=vpc-id,Values=${VPC_ID}" \\
  --output table

## Delete VPC (cleanup)
# WARNING: This will delete ALL resources created by this script
./scripts/delete-vpc-infrastructure.sh ${VPC_ID} ${REGION}
EOF

echo -e "${GREEN}✓ Reference commands saved to: /tmp/vpc-reference-commands.txt${NC}"
echo ""

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Setup Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${YELLOW}Next Steps:${NC}"
echo -e "1. Copy the Terraform variables from ${BLUE}/tmp/vpc-outputs.txt${NC}"
echo -e "2. Update your ${BLUE}terraform.tfvars${NC} or ${BLUE}kxi-terraform.env${NC}"
echo -e "3. Run ${BLUE}./scripts/deploy-cluster.sh${NC} to deploy EKS"
echo ""
echo -e "${YELLOW}To view created resources:${NC}"
echo -e "  cat /tmp/vpc-reference-commands.txt"
echo ""
