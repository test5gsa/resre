#!/bin/bash

# Get version from version.txt
VERSION_FILE="version.txt"
if [[ -f $VERSION_FILE ]]; then
  VERSION=$(grep 'kxi-terraform-version' "$VERSION_FILE" | cut -d '=' -f2 | tr -d '[:space:]')
else
  echo "Error: version.txt not found."
  exit 1
fi

if [[ -z $VERSION ]]; then
  echo "Error: kxi-terraform-version not set in version.txt."
  exit 1
fi

IMAGE_NAME="kxi-terraform:${VERSION}"

# Detect Apple Silicon and set platform option
if [ "$(uname -m)" = "arm64" ] && [ "$(uname -s)" = "Darwin" ]; then
  DOCKER_OPTS="--platform linux/arm64"
fi

# shellcheck disable=SC2086
docker run -it --rm \
  -v "$(pwd)":/terraform \
  --env CLUSTER_READY=false \
  $DOCKER_OPTS \
  "$IMAGE_NAME" ./scripts/setup-env.sh
