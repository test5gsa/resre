#!/bin/bash
set -e

VERSION_FILE="version.txt"

if [[ ! -f $VERSION_FILE ]]; then
  echo "version.txt not found!"
  exit 1
fi

VERSION=$(grep 'kxi-terraform-version' "$VERSION_FILE" | cut -d '=' -f2)
if [[ -z $VERSION ]]; then
  echo "kxi-terraform-version not found in version.txt"
  exit 1
fi

echo "Building Docker image with version: $VERSION"
docker build -t kxi-terraform:"$VERSION" ./config
