#!/bin/bash

#Source variables and remove temp file
if [ -f kxi-terraform.env ]; then
  ENV_FILE="/tmp/env_vars"
  grep -v '^#' kxi-terraform.env | grep -v '^$' | grep -v 'whitelist_ips' > "$ENV_FILE"
  source "$ENV_FILE"
  rm -f "$ENV_FILE"
fi

# Get version from version.txt
VERSION_FILE="version.txt"
if [[ -f $VERSION_FILE ]]; then
  VERSION=$(grep 'kxi-terraform-version' "$VERSION_FILE" | cut -d '=' -f2 | tr -d '[:space:]')
else
  echo "Error: version.txt not found."
  exit 1
fi

if [[ -z $VERSION ]]; then
  echo "Error: kxi-terraform-version not set in version.txt."
  exit 1
fi

IMAGE_NAME="kxi-terraform:${VERSION}"
CONTAINER_NAME="${CLOUD}-${ENV}-manage-cluster"

# Check if container is already running
docker ps --format "{{.Names}}" | grep -q -w "$CONTAINER_NAME"
commandStatus=$?

if [ "$commandStatus" -eq 0 ]; then
  echo -e "\n--- Container manage-cluster is already running. Opening a shell... ---\n"
else
  echo -e "\n--- Container manage-cluster is not running. Spawning container and opening a shell... ---\n"

  # Set Docker options for Apple Silicon (arm64)
  if [ "$(uname -m)" = "arm64" ] && [ "$(uname -s)" = "Darwin" ]; then
    DOCKER_OPTS="--platform linux/arm64"
  fi

  # Start Docker container
  docker run -it -d --rm \
    --name "$CONTAINER_NAME" \
    -v "$(pwd)":/terraform \
    --env CLUSTER_READY=true \
    --env-file kxi-terraform.env \
    --cap-add=NET_ADMIN \
    --device /dev/net/tun \
    $DOCKER_OPTS \
    "$IMAGE_NAME" bash &> /dev/null
fi

# Attach to container
docker exec -it "$CONTAINER_NAME" bash
