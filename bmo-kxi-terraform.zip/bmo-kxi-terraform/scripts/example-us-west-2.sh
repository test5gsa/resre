#!/bin/bash

################################################################################
# Example: Create VPC Endpoints for us-west-2
################################################################################
#
# This is a complete example for your current setup in us-west-2
#

set -e

# Your actual values from the screenshot
export VPC_ID="vpc-08acd442308802d0f"
export PRIVATE_SUBNET_IDS="subnet-06e8c7c3bd3c57310 subnet-05e8d1372115e0477"
export CLUSTER_NAME="aws-endpoint"
export AWS_REGION="us-west-2"

# Get route table IDs automatically
echo "Finding private route tables..."
export PRIVATE_RT_IDS=$(aws ec2 describe-route-tables \
  --filters "Name=vpc-id,Values=$VPC_ID" \
            "Name=association.subnet-id,Values=$(echo $PRIVATE_SUBNET_IDS | tr ' ' ',')" \
  --query 'RouteTables[*].RouteTableId' \
  --output text \
  --region $AWS_REGION | head -1)

if [ -z "$PRIVATE_RT_IDS" ]; then
  echo "ERROR: Could not find route table for private subnets"
  echo "Please set manually: export PRIVATE_RT_IDS='rtb-xxxxx'"
  exit 1
fi

echo "Found route table: $PRIVATE_RT_IDS"
echo ""
echo "Configuration:"
echo "  VPC ID:      $VPC_ID"
echo "  Subnets:     $PRIVATE_SUBNET_IDS"
echo "  Route Table: $PRIVATE_RT_IDS"
echo "  Cluster:     $CLUSTER_NAME"
echo "  Region:      $AWS_REGION"
echo ""
read -p "Press Enter to continue or Ctrl+C to cancel..."

# Enable SSM for remote access
export ENABLE_SSM=true

# Run the main script
./create-vpc-endpoints-manual.sh
