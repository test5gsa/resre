#!/usr/bin/env bash

function create_azure_backend {

    # Login to Azure using service principal
    az login --service-principal -u "${ARM_CLIENT_ID}" -p "${ARM_CLIENT_SECRET}" --tenant "${ARM_TENANT_ID}"

    # Check if variables are set and if not set the default values
    # shellcheck disable=SC2154
    if [ -z "$KX_STATE_RESOURCE_GROUP_NAME" ]; then KX_STATE_RESOURCE_GROUP_NAME="kxi-terraform-azure-${TF_VAR_region}-${ARM_SUBSCRIPTION_ID}"; fi
    if [ -z "$KX_STATE_STORAGE_ACCOUNT_NAME" ]; then KX_STATE_STORAGE_ACCOUNT_NAME="kxitf${RANDOM}"; fi
    if [ -z "$KX_STATE_BUCKET_NAME" ]; then KX_STATE_BUCKET_NAME="terraform-state"; fi

    echo -e "\r\n--- Configuring azure backend ---\r\n"
    # Create resource group
    groupExists=$(az group exists --name "$KX_STATE_RESOURCE_GROUP_NAME")
    if [ "$groupExists" = "true" ]; then
        echo "Resource group $KX_STATE_RESOURCE_GROUP_NAME exists"
    else
        echo "Creating resource group $KX_STATE_RESOURCE_GROUP_NAME"
        az group create --name "$KX_STATE_RESOURCE_GROUP_NAME" --location "${TF_VAR_region}" -o none
    fi

    # Check the storage account and create if necessary
    storageAccountCheck=$(az storage account check-name --name "$KX_STATE_STORAGE_ACCOUNT_NAME" -o yaml)
    storageAccountAvailable=$(echo "$storageAccountCheck" | grep nameAvailable | cut -f 2 -d : | sed 's/ //g')
    storageAccountMessage=$(echo "$storageAccountCheck" | grep message | cut -f 2 -d :)
    storageAccountReason=$(echo "$storageAccountCheck" | grep reason | cut -f 2 -d : | sed 's/ //g')
    if [ "$storageAccountAvailable" = "false" ]; then
        # If the name is not available, check if it's because it already exists
        if [ "$storageAccountReason" = "AlreadyExists" ]; then
            echo "Storage account $KX_STATE_STORAGE_ACCOUNT_NAME already exists."
        else
            echo "Error checking storage account."
            echo "$storageAccountMessage"
            exit 1
        fi
    else
        echo "Creating storage account $KX_STATE_STORAGE_ACCOUNT_NAME"
        # Create the storage account if it doesn't exist
        az storage account create --resource-group "$KX_STATE_RESOURCE_GROUP_NAME" --name "$KX_STATE_STORAGE_ACCOUNT_NAME" --sku Standard_LRS --encryption-services blob --allow-blob-public-access false -o none
    fi

    # Create blob container
    containerExists="$(az storage container exists --name "$KX_STATE_BUCKET_NAME" --account-name "$KX_STATE_STORAGE_ACCOUNT_NAME" --auth-mode login -o tsv )"
    if [ "$containerExists" = "True" ]; then
        echo "Container $KX_STATE_BUCKET_NAME exists"
    else
        echo "Creating container $KX_STATE_BUCKET_NAME"
        az storage container create --name "$KX_STATE_BUCKET_NAME" --account-name "$KX_STATE_STORAGE_ACCOUNT_NAME" --auth-mode login
    fi

    if [ -f kxi-terraform.env ]; then
        sed -i '/KX_STATE_RESOURCE_GROUP_NAME/d' kxi-terraform.env
        sed -i '/KX_STATE_STORAGE_ACCOUNT_NAME/d' kxi-terraform.env
        sed -i '/KX_STATE_BUCKET_NAME/d' kxi-terraform.env
        # shellcheck disable=SC2129
        echo "KX_STATE_RESOURCE_GROUP_NAME=$KX_STATE_RESOURCE_GROUP_NAME" >> kxi-terraform.env
        echo "KX_STATE_STORAGE_ACCOUNT_NAME=$KX_STATE_STORAGE_ACCOUNT_NAME" >> kxi-terraform.env
        echo "KX_STATE_BUCKET_NAME=$KX_STATE_BUCKET_NAME" >> kxi-terraform.env
    fi

    echo -e "\r\n--- Backend configured. ---\r\n"

}

function create_aws_backend {
    # Declare default values
    ACCOUNT_ID=$(aws sts get-caller-identity --output text --query 'Account')
    if [ -z "$KX_STATE_BUCKET_NAME" ]; then KX_STATE_BUCKET_NAME="kxi-terraform-aws-${TF_VAR_region}-${ACCOUNT_ID}"; fi

    echo -e "\r\n--- Configuring aws backend ---\r\n"
    # Check if S3 Bucket exists
    aws s3api head-bucket --bucket "$KX_STATE_BUCKET_NAME" > /dev/null 2>&1
    bucketStatus=$?
    if [ "$bucketStatus" -eq 0 ]
    then
        echo "S3 Bucket $KX_STATE_BUCKET_NAME exists"
    else
        echo "Create S3 Bucket $KX_STATE_BUCKET_NAME on $TF_VAR_region region"
        if [ "${TF_VAR_region}" = "us-east-1" ]
        then
          aws s3api create-bucket --bucket "$KX_STATE_BUCKET_NAME"
        else
          aws s3api create-bucket --bucket "$KX_STATE_BUCKET_NAME" --region "$TF_VAR_region" --create-bucket-configuration LocationConstraint="$TF_VAR_region"
        fi

        # Configure encryption
        aws s3api put-bucket-encryption --bucket "$KX_STATE_BUCKET_NAME" --server-side-encryption-configuration '{
            "Rules": [
                {
                    "ApplyServerSideEncryptionByDefault": {
                        "SSEAlgorithm": "AES256"
                    }
                }
            ]
        }'

        # Block public access
        aws s3api put-public-access-block --bucket "$KX_STATE_BUCKET_NAME" --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
    fi

    if [ -f kxi-terraform.env ]; then
        sed -i '/KX_STATE_BUCKET_NAME/d' kxi-terraform.env
        echo "KX_STATE_BUCKET_NAME=$KX_STATE_BUCKET_NAME" >> kxi-terraform.env
    fi

    echo -e "\r\n--- Backend configured. ---\r\n"
}

function create_gcp_backend {

    # Login to GCP using service account
    # shellcheck disable=SC2154
    gcloud auth activate-service-account --key-file="${GOOGLE_APPLICATION_CREDENTIALS}" --project="${TF_VAR_project}"

    # Declare default values
    # shellcheck disable=SC2154
    PROJECT_NUMBER=$(gcloud projects list --filter="${TF_VAR_project}" --format="value(PROJECT_NUMBER)")
    if [ -z "$KX_STATE_BUCKET_NAME" ]; then KX_STATE_BUCKET_NAME="kxi-terraform-gcp-${TF_VAR_region}-${PROJECT_NUMBER}"; fi

    echo -e "\r\n--- Configuring gcp backend ---\r\n"
    # Check if GCP Bucket exists
    gsutil ls gs://"$KX_STATE_BUCKET_NAME" > /dev/null 2>&1
    bucketStatus=$?
    if [ "$bucketStatus" -eq 0 ]
    then
        echo "GCP Bucket $KX_STATE_BUCKET_NAME exists"
    else
        echo "Create GCP Bucket $KX_STATE_BUCKET_NAME on $TF_VAR_region region"
        gsutil mb -l "$TF_VAR_region" gs://"$KX_STATE_BUCKET_NAME"

        # Enforce public access prevention
        gsutil pap set enforced gs://"${KX_STATE_BUCKET_NAME}"

    fi

    if [ -f kxi-terraform.env ]; then
        sed -i '/KX_STATE_BUCKET_NAME/d' kxi-terraform.env
        echo "KX_STATE_BUCKET_NAME=$KX_STATE_BUCKET_NAME" >> kxi-terraform.env
    fi

    echo -e "\r\n--- Backend configured. ---\r\n"
}

# Set additional variable for region
TF_VAR_region="${REGION}"
# Set additional variable for GCP
TF_VAR_project="${PROJECT}"

if [ "${CLOUD}" = "azure" ]
  then
    create_azure_backend
elif [ "${CLOUD}" = "aws" ]
  then
    export AWS_DEFAULT_REGION="${REGION}"
    create_aws_backend
elif [ "${CLOUD}" = "gcp" ]
  then
    create_gcp_backend
fi
