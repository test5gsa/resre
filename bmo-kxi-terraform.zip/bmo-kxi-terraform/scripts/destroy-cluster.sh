#!/bin/bash

# Get version from version.txt
VERSION_FILE="version.txt"
if [[ -f $VERSION_FILE ]]; then
  VERSION=$(grep 'kxi-terraform-version' "$VERSION_FILE" | cut -d '=' -f2 | tr -d '[:space:]')
else
  echo "Error: version.txt not found."
  exit 1
fi

if [[ -z $VERSION ]]; then
  echo "Error: kxi-terraform-version not set in version.txt."
  exit 1
fi

IMAGE_NAME="kxi-terraform:${VERSION}"

# Detect Apple Silicon (arm64) and adjust Docker options
if [ "$(uname -m)" = "arm64" ] && [ "$(uname -s)" = "Darwin" ]; then
  DOCKER_OPTS="--platform linux/arm64"
fi

# Terraform destroy
docker run -it --rm \
  -v "$(pwd)":/terraform \
  --env CLUSTER_READY=false \
  --env-file kxi-terraform.env \
  --cap-add=NET_ADMIN \
  --device /dev/net/tun \
  $DOCKER_OPTS \
  "$IMAGE_NAME" ./scripts/terraform.sh destroy all
