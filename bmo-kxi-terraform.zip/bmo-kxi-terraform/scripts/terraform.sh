#!/bin/bash
# Set additional variable for all environments
export TF_VAR_region="${REGION}"
export TF_VAR_architecture_profile="${PROFILE}"
# Set additional variables for GCP
export TF_VAR_project="${PROJECT}"
export TF_VAR_gcp_project="${PROJECT}"

# Configuration file for each profile
PROFILE_CONFIG_FILE=config/config.json

# Source env variables
if [ -f kxi-terraform.env ]
then
  # Clear TF_VAR_cluster_name
  unset TF_VAR_cluster_name
  grep -v ^# kxi-terraform.env | grep -v ^$ | grep -v whitelist_ips > env_vars
  while read line; do export "$line"; done < env_vars
fi

TERRAFORM_BASE=$(pwd)
readonly TERRAFORM_BASE

usage() {
    cat << EOF
Run terraform commands and manage connectivity to cluster

$0 deploy all - Deploy cluster and configuration
$0 destroy all - Destroy cluster and configuration
$0 [init|plan|apply|output|plan-destroy|destroy|validate|state] [cluster|config|services] [...] - Run terraform operations
$0 vpn [up|down] - Enable/disable openvpn connection
$0 ssh  - SSH to the bastion host
$0 kubeconfig - Generate kubeconfig entry
$0 authenticate - Authenticate to Cloud Provider
$0 connect - Authenticate, generate kubeconfig and connect to VPN
$0 check-vars - Check deployment environment variables
$0 check-apis - Check required apis are enabled
$0 check-credentials - Check deployment user credentials
$0 check-region - Check if cluster exists already exists in a different region
$0 check-node-types - Check if selected node types are using x86-based CPUs
$0 check-quotas - Check resource quotas
$0 check-availability-zones - Check allowed Availability Zones
$0 check-network-rules - Check number of Network Rules
$0 check-tags - Check resource default tags
$0 pre-deploy-check - Perform pre-deployment check
$0 upload-artifacts - Upload the following files: version.txt / terraform/${CLOUD}/client.ovpn / kxi-terraform.env to the terraform backend state location

EOF
}

cd_to_tf_root() {

cd "$TERRAFORM_BASE" || exit 1

# if the script is called from the top level dir and TF_ROOT exists, then cd into it
if [ -d "$TF_ROOT" ]; then
    cd "$TF_ROOT" || exit 1
fi
}

tf_init() {

rm -rf .terraform
if [ -z "$KX_STATE_BUCKET_NAME" ]; then
    echo "Please provide KX_STATE_BUCKET_NAME in environment variables" 1>&2
    exit 1
fi

if [ "${CLOUD}" = "aws" ]
  then
    terraform init \
        -backend-config="bucket=${KX_STATE_BUCKET_NAME}" \
        -backend-config="key=terraform-${TERRAFORM_STATE_NAME}/terraform.tfstate" \
        -backend-config="region=${TF_VAR_region:?TF_VAR_region must be set for AWS region}" \
        -reconfigure \
        -upgrade

elif [ "${CLOUD}" = "azure" ]
  then
    terraform init \
        -backend-config="resource_group_name=${KX_STATE_RESOURCE_GROUP_NAME}" \
        -backend-config="storage_account_name=${KX_STATE_STORAGE_ACCOUNT_NAME}" \
        -backend-config="container_name=${KX_STATE_BUCKET_NAME}" \
        -backend-config="key=${TERRAFORM_STATE_NAME}.tfstate" \
        -reconfigure \
        -upgrade

elif [[ "${CLOUD}" == gcp* ]]
  then
    terraform init \
        -backend-config="bucket=${KX_STATE_BUCKET_NAME}" \
        -backend-config="prefix=terraform-${TERRAFORM_STATE_NAME}/terraform_state" \
        -reconfigure \
        -upgrade
fi

}

vpn() {
  action=$1
  vpnConfig=$2

  # load kernel module only if running outside container
  if [ ! -f /.dockerenv ]; then
    sudo modprobe tun
  fi

  if [[ "$TF_VAR_existing_vpc" == "true" ]]; then
    echo "Existing VPC is true therefore not using vpn."
    return 0
  fi

  if [[ "$TF_VAR_private_only" == "true" ]]; then
    echo "Private-only mode is true therefore not using vpn."
    return 0
  fi

  case $action in
    "up")

      if [ -z "$(type -p resolvconf)" ]; then
        echo "Error: Unable to find resolvconf, please install the resolvconf package first."
        exit 1
      fi
      if [ -z "$(type -p openvpn)" ]; then
        echo "Error: Unable to find openvpn, please install it first."
        exit 1
      fi
      if [ ! -e "$vpnConfig" ]; then
        echo "Error: Unable to find vpn config file at $vpnConfig, please run deploy-cluster.sh first to generate."
        exit 1
      fi
      connectivityCheck=false
      loopCount=0
      while ! $connectivityCheck
      do
        # shellcheck disable=SC2003
        loopCount=$(expr $loopCount + 1)
        logFile="$(mktemp /tmp/openvpn.XXXXX.log)"
        echo "[${loopCount}] Connecting to vpn, check $logFile for log."
        sudo openvpn --config "$vpnConfig" --daemon --log "$logFile" | grep -v block-outside-dns
        sleep 10s
        grep -q 'Initialization Sequence Completed' "$logFile"
        commandStatus=$?
        if [ "$commandStatus" -eq 0 ]
        then
          connectivityCheck=true
          echo "[$loopCount] VPN connected"
        else
          if [ "$loopCount" -le 5 ]; then
            echo "[$loopCount] Unable to connect, retrying..."
            connectivityCheck=false
            pkill openvpn || true
            sleep 10s
          else
            echo "Unable to connect after 5 retries, exiting..."
            exit 1
          fi
        fi
      done
    ;;
    "down")
      echo "Killing openvpn..."
      if [ "$(id -u)" != "0" ]; then
        sudo pkill openvpn || true
        sleep 5
      else
        pkill openvpn || true
        sleep 5
      fi
      echo "Done."
    ;;
    *)
      echo "Please specify vpn action: up, down"
      exit 1
  esac

}

ssh_bastion() {
  TF_ROOT=$1
  echo "Getting ssh credentials..."
  cd "$TF_ROOT" || exit 1
  if [ ! -e "./bastion_ssh_private_key.pem" ]; then
    echo "Unable to find bastion ssh key at $TF_ROOT/bastion_ssh_private_key.pem, please run $0 apply cluster first to generate the ssh key."
    exit 1
  fi
  BASTION_USERNAME="$(terraform output -raw bastion_username)"
  BASTION_IP="$(terraform output -raw bastion_ip)"
  BASTION_SSH_KEY=$(realpath "./bastion_ssh_private_key.pem")


  echo "Connecting to bastion ${BASTION_IP}"
  echo ssh -i "$BASTION_SSH_KEY"  "${BASTION_USERNAME}@${BASTION_IP}"
  ssh -i "$BASTION_SSH_KEY"  "${BASTION_USERNAME}@${BASTION_IP}"
}

run_kubeconfig() {
  if [ "${CLOUD}" = "aws" ]; then
    aws eks update-kubeconfig --name "$TF_VAR_cluster_name" --region "$TF_VAR_region"

  elif [ "${CLOUD}" = "azure" ]; then
    az aks get-credentials --resource-group "${TF_VAR_cluster_name}"-resource-group --name "$TF_VAR_cluster_name" --overwrite-existing

  elif [[ "${CLOUD}" == gcp* ]]; then
    gcloud container clusters get-credentials "$TF_VAR_cluster_name" --region "$TF_VAR_region"
    gcloud container clusters get-credentials "$TF_VAR_cluster_name" --region "$zone"
  fi
  chmod 600 ~/.kube/config
}

authenticate() {
  if [ "${CLOUD}" = "azure" ]; then
    az login --service-principal -u "${ARM_CLIENT_ID}" -p "${ARM_CLIENT_SECRET}" --tenant "${ARM_TENANT_ID}"

  elif [[ "${CLOUD}" == gcp* ]]; then
    # shellcheck disable=SC2154
    gcloud auth activate-service-account --key-file="${GOOGLE_APPLICATION_CREDENTIALS}" --project="${TF_VAR_project}"
  fi
}

check_apis() {
  if [[ "${CLOUD}" == gcp ]]; then
    # Login to GCP using service account
    gcloud auth activate-service-account --key-file="${GOOGLE_APPLICATION_CREDENTIALS}" --project="${TF_VAR_project}" --no-user-output-enabled

    echo -e "\r\n--- Checking gcp apis ---\r\n"
    RETURN=0
    gcloud services list | grep cloudresourcemanager.googleapis.com || RETURN=1;
    gcloud services list | grep container.googleapis.com || RETURN=1;
    gcloud services list | grep compute.googleapis.com || RETURN=1;
    gcloud services list | grep file.googleapis.com || RETURN=1;

    if [ $RETURN -eq 0 ]; then
      echo "All required apis enabled"
    else
      echo "Please ensure that the following are enabled:
      Cloud Resource Manager API
      Compute Engine API
      Kubernetes Engine API
      Cloud Filestore API
      "
    fi
  fi
}

check_region(){

  if [ "${CLOUD}" = "azure" ]; then

    # Login to Azure using service principal
    az login --service-principal -u "${ARM_CLIENT_ID}" -p "${ARM_CLIENT_SECRET}" --tenant "${ARM_TENANT_ID}" --output none --only-show-errors

    # Skip check if cluster exists
    az aks show --name "${TF_VAR_cluster_name}" --resource-group "${TF_VAR_cluster_name}"-resource-group &> /dev/null
    commandStatus=$?
    if [ "$commandStatus" -eq 0 ]
    then
      region=$(az aks show --name "${TF_VAR_cluster_name}" --resource-group "${TF_VAR_cluster_name}"-resource-group -o json | jq -r '.location')
      if [ "$TF_VAR_region" == "$region" ]
      then
        echo -e "\r\n--- Cluster ${TF_VAR_cluster_name} exists. Skipping pre-deploy-check. ---\r\n"
        exit 0
      else
        echo -e "\r\n--- Cluster ${TF_VAR_cluster_name} exists on $region region. Please set TF_VAR_region variable to $region on kxi-terraform.env and destroy the cluster. Then set TF_VAR_region variable to $TF_VAR_region and deploy the cluster ---\r\n"
        return 1
      fi
    fi

  elif [ "${CLOUD}" = "aws" ]; then

    # Skip check if cluster exists
    aws eks describe-cluster --name "${TF_VAR_cluster_name}" &> /dev/null
    commandStatus=$?
    if [ "$commandStatus" -eq 0 ]
    then
      region=$(aws eks describe-cluster --name "${TF_VAR_cluster_name}" --query "cluster.arn" --output json | jq -r '. | split(":")[3]')
      if [ "$TF_VAR_region" == "$region" ]
      then
        echo -e "\r\n--- Cluster ${TF_VAR_cluster_name} exists. Skipping pre-deploy-check. ---\r\n"
        exit 0
      else
        echo -e "\r\n--- Cluster ${TF_VAR_cluster_name} exists on $region region. Please set TF_VAR_region variable to $region on kxi-terraform.env and destroy the cluster. Then set TF_VAR_region variable to $TF_VAR_region and deploy the cluster ---\r\n"
        return 1
      fi
    fi

  elif [ "${CLOUD}" = "gcp" ]; then

    # Login to GCP using service account
    gcloud auth activate-service-account --key-file="${GOOGLE_APPLICATION_CREDENTIALS}" --project="${TF_VAR_project}" --no-user-output-enabled

    gcloud container clusters list | grep -q "${TF_VAR_cluster_name}"
    commandStatus=$?
    if [ "$commandStatus" -eq 0 ]
    then
      region=$(gcloud container clusters list --filter="name:${TF_VAR_cluster_name}" --format='value(location)')
      if [ "$TF_VAR_region" == "$region" ]
      then
        echo -e "\r\n--- Cluster ${TF_VAR_cluster_name} exists. Skipping pre-deploy-check. ---\r\n"
        exit 0
      else
        echo -e "\r\n--- Cluster ${TF_VAR_cluster_name} exists on $region region. Please set TF_VAR_region variable to $region on kxi-terraform.env and destroy the cluster. Then set TF_VAR_region variable to $TF_VAR_region and deploy the cluster ---\r\n"
        return 1
      fi
    fi
  fi
}


check_vars() {

# Check deployment environment variables

echo -e "\r\n--- Checking environment variables ---\r\n"

if [ -z "${ENV}" ]
then
  echo "ENV is not populated. Please update variable and retry."
  exit 1
else
  if [[ ! $ENV =~ ^[a-z0-9]+$ ]]
  then
    echo "The ENV variable [$ENV] can contain only lowercase letters and numbers. Please update variables and retry."
    exit 1
  fi
  if [[ ${#ENV} -gt 8 ]]
  then
    echo "The ENV variable [$ENV] length should not exceed 8 characters. Please update the variable and retry."
    exit 1
  fi
fi

# shellcheck disable=SC2154
if [[ -n "${TF_VAR_letsencrypt_enable_http_validation}" && "${TF_VAR_letsencrypt_enable_http_validation}" = "false" ]]
then
  if [[ "${TF_VAR_bastion_whitelist_ips}" = '["0.0.0.0/0"]' ]]
  then
    echo "TF_VAR_bastion_whitelist_ips variable is set to 0.0.0.0/0. Please update the variable before proceeding"
    exit 1
  elif [[ "${TF_VAR_insights_whitelist_ips}" = '["0.0.0.0/0"]' ]]
  then
    echo "TF_VAR_insights_whitelist_ips variable is set to 0.0.0.0/0. Please update the variable before proceeding"
    exit 1
  fi
fi

}

check_credentials() {

  if [ "${CLOUD}" = "azure" ]; then

    # Check Azure credentials
    echo -e "\r\n--- Checking azure credentials ---\r\n"
    if [ -z "${ARM_CLIENT_ID}" ]
    then
      echo "ARM_CLIENT_ID is not populated. Please update variable and retry."
      exit 1
    fi
    if [ -z "${ARM_CLIENT_SECRET}" ]
    then
      echo "ARM_CLIENT_SECRET is not populated. Please update variable and retry."
      exit 1
    else
      [[ ${ARM_CLIENT_SECRET} = -* ]] && echo "ARM_CLIENT_SECRET starts with hyphen which is not allowed. Please generate a new secret and retry." && exit 1
    fi
     if [ -z "${ARM_SUBSCRIPTION_ID}" ]
    then
      echo "ARM_SUBSCRIPTION_ID is not populated. Please update variable and retry."
      exit 1
    fi
     if [ -z "${ARM_TENANT_ID}" ]
    then
      echo "ARM_TENANT_ID is not populated. Please update variable and retry."
      exit 1
    fi

    # Validate Azure credentials
    echo -e "\r\n--- Validating azure credentials ---\r\n"
    az login --service-principal -u "${ARM_CLIENT_ID}" -p "${ARM_CLIENT_SECRET}" --tenant "${ARM_TENANT_ID}" --output none --only-show-errors
    commandStatus=$?
    if [ "$commandStatus" -eq 0 ]
    then
      echo -e "\r\n--- Credentials are valid. ---\r\n"
    else
      echo -e "\r\n--- Validation failed. Check credentials variables. ---\r\n"
			exit 1
    fi

  elif [ "${CLOUD}" = "aws" ]; then

    # Check AWS credentials
    echo -e "\r\n--- Checking aws credentials ---\r\n"
    if [ -z "${AWS_ACCESS_KEY_ID}" ]
    then
      echo "AWS_ACCESS_KEY_ID is not populated. Please update variable and retry."
      exit 1
    fi
    if [ -z "${AWS_SECRET_ACCESS_KEY}" ]
    then
      echo "AWS_SECRET_ACCESS_KEY is not populated. Please update variable and retry."
      exit 1
    fi

    # Validate AWS credentials
    echo -e "\r\n--- Validating aws credentials ---\r\n"
    aws sts get-caller-identity 1> /dev/null
    commandStatus=$?
    if [ "$commandStatus" -eq 0 ]
    then
      echo -e "\r\n--- Credentials are valid. ---\r\n"
    else
      echo -e "\r\n--- Validation failed. Check credentials variables. ---\r\n"
			exit 1
    fi

  elif [ "${CLOUD}" = "gcp" ]; then

    # Check GCP credentials
    echo -e "\r\n--- Checking gcp credentials ---\r\n"
    if [ -z "${TF_VAR_project}" ]
    then
      echo "TF_VAR_project is not populated. Please update variable and retry."
      exit 1
    fi
    if [ -z "${TF_VAR_gcp_project}" ]
    then
      echo "TF_VAR_gcp_project is not populated. Please update variable and retry."
      exit 1
    fi
    if [ -z "${GOOGLE_APPLICATION_CREDENTIALS}" ]
    then
      echo "GOOGLE_APPLICATION_CREDENTIALS is not populated. Please update variable and retry."
      exit 1
    else
      if [ ! -f "${GOOGLE_APPLICATION_CREDENTIALS}" ]
      then
        echo "GOOGLE_APPLICATION_CREDENTIALS is incorrect. Please update variable and retry."
        exit 1
      fi
    fi

    # Validate GCP credentials
    echo -e "\r\n--- Validating gcp credentials ---\r\n"
    gcloud auth activate-service-account --key-file="${GOOGLE_APPLICATION_CREDENTIALS}" --project="${TF_VAR_project}" --no-user-output-enabled
    commandStatus=$?
    if [ "$commandStatus" -eq 0 ]
    then
      echo -e "\r\n--- Credentials are valid. ---\r\n"
    else
      echo -e "\r\n--- Validation failed. Check credentials variables. ---\r\n"
			exit 1
    fi
  fi
}

check_tags() {

# Check if default_tags.json exists and if not create it
echo -e "\r\n--- Checking default tags file ---\r\n"

DEFAULT_TAGS_FILE="config/default_tags.json"

if [ ! -f "$DEFAULT_TAGS_FILE" ]
then
  echo "{
  \"managed_by\": \"terraform-client-scripts\"
}" > "$DEFAULT_TAGS_FILE"
else
  # File exists – check if kdbInsightsInfraProfile is present and correct
  existing_profile=$(jq -r '.kdbInsightsInfraProfile // empty' "$DEFAULT_TAGS_FILE")

  if [ "$existing_profile" != "$PROFILE" ]; then
    echo "Setting 'kdbInsightsInfraProfile' tag to '$PROFILE'"
    tmpfile=$(mktemp)
    jq --arg profile "$PROFILE" '.kdbInsightsInfraProfile = $profile' "$DEFAULT_TAGS_FILE" > "$tmpfile" && mv "$tmpfile" "$DEFAULT_TAGS_FILE"
  else
    echo "'kdbInsightsInfraProfile' already set to '$PROFILE' – no changes made"
  fi
fi
}

check_node_types() {


# Check if node types are using x86 based CPUs
if [ "${CLOUD}" = "aws" ]
then
  echo -e "\r\n--- Checking node types ---\r\n"

  # Check default node pool
  if [ -n "${TF_VAR_default_node_type}" ]
  then
    DEFAULT_NODE_TYPE_ARCH=$(aws ec2 describe-instance-types --instance-types ${TF_VAR_default_node_type} | jq -r '.InstanceTypes[0].ProcessorInfo.SupportedArchitectures[0]')
    if [ "${DEFAULT_NODE_TYPE_ARCH}" = "arm64" ]
    then
      echo "Node type for default pool uses arm-based CPUs which is not supported. Please select a node type which uses x86-based CPUs"
      echo -e "\r\n--- Node Type check failed. ---\r\n"
      exit 1
    fi
  fi

  # Check rook-ceph node pool
  if [ -n "${TF_VAR_rook_ceph_pool_node_type}" ]
  then
    ROOK_CEPH_NODE_TYPE_ARCH=$(aws ec2 describe-instance-types --instance-types ${TF_VAR_rook_ceph_pool_node_type} | jq -r '.InstanceTypes[0].ProcessorInfo.SupportedArchitectures[0]')
    if [ "${ROOK_CEPH_NODE_TYPE_ARCH}" = "arm64" ]
    then
      echo "Node type for rook-ceph pool uses arm-based CPUs which is not supported. Please select a node type which uses x86-based CPUs"
      echo -e "\r\n--- Node Type check failed. ---\r\n"
      exit 1
    fi
  fi

  echo -e "\r\n--- Node Types are valid. ---\r\n"
fi

}

check_quotas() {

  if [ "${CLOUD}" = "azure" ]; then

    # Login to Azure using service principal
    az login --service-principal -u "${ARM_CLIENT_ID}" -p "${ARM_CLIENT_SECRET}" --tenant "${ARM_TENANT_ID}" --output none --only-show-errors

    # Skip check if cluster exists
    az aks show --name "${TF_VAR_cluster_name}" --resource-group "${TF_VAR_cluster_name}"-resource-group &> /dev/null
    commandStatus=$?
    if [ "$commandStatus" -eq 0 ]
    then
      echo -e "\r\n--- Cluster ${TF_VAR_cluster_name} exists. Skipping pre-deploy-check. ---\r\n"
      return 0
    fi

    case "${PROFILE}" in
      "ha")
        AKS_NODE_TYPE_DEFAULT=$(jq -r '.config' ${PROFILE_CONFIG_FILE} | jq '.[] | select(.name=="azure")' | jq -r '.profile' | jq '.[] | select(.name=="ha")' |  jq -r .default_node_type)
        ;;
      "perf")
        AKS_NODE_TYPE_DEFAULT=$(jq -r '.config' ${PROFILE_CONFIG_FILE} | jq '.[] | select(.name=="azure")' | jq -r '.profile' | jq '.[] | select(.name=="perf")' |  jq -r .default_node_type)
        ;;
      "cost")
        AKS_NODE_TYPE_DEFAULT=$(jq -r '.config' ${PROFILE_CONFIG_FILE} | jq '.[] | select(.name=="azure")' | jq -r '.profile' | jq '.[] | select(.name=="cost")' |  jq -r .default_node_type)
        ;;
      *)
        echo "Unsupported PROFILE value: $PROFILE"
        exit 1
        ;;
    esac

    # Define VM Instances requirements
    # shellcheck disable=SC2154
    AKS_NODE_TYPE="${TF_VAR_default_node_type}"
    # shellcheck disable=SC2154
    AKS_NODE_COUNT="${TF_VAR_max_node_count}"
    BASTION_HOST_NODE_TYPE="Standard_D1_v2"

    if [ "${AKS_NODE_TYPE}" == "${AKS_NODE_TYPE_DEFAULT}" ]
    then
      AKS_NODE_DEFAULT_TYPE=1
    fi

    echo -e "\r\n--- Checking azure providers enabled for quotas check ---\r\n"

    providers=("Microsoft.Network" "Microsoft.Compute" "Microsoft.Storage" "Microsoft.OperationalInsights" "Microsoft.OperationsManagement" "Microsoft.ContainerService" "Microsoft.PolicyInsights")

    for i in "${providers[@]}";
      do
        register_status=$(az provider show --namespace "$i" | jq '.registrationState')
        if [ "$register_status" == '"NotRegistered"' ] || [ "$register_status" == '"Unregistered"' ]
        then
          echo "Registering '$i' provider"
          az provider register --namespace "$i"
        else
          echo "Provider '$i' is already registered"
        fi
      done

    echo -e "\r\n--- Checking azure quotas---\r\n"
    quotaStatus=0

    # Check Quotas for Public IPs (Total/Basic/Standard)
    QUOTA_STATIC_PUBLIC_IPS=$(az network list-usages --location "${TF_VAR_region}" --query "[?name.localizedValue=='Public IP Addresses'].{Limit:limit}" --output tsv)
    QUOTA_STANDARD_PUBLIC_IPS=$(az network list-usages --location "${TF_VAR_region}" --query "[?name.localizedValue=='Public IPv4 Addresses - Standard'].{Limit:limit}" --output tsv)

    CURRENT_STATIC_PUBLIC_IPS=$(az network list-usages --location "${TF_VAR_region}" --query "[?name.localizedValue=='Public IP Addresses'].{Current:currentValue}" --output tsv)
    CURRENT_STANDARD_PUBLIC_IPS=$(az network list-usages --location "${TF_VAR_region}" --query "[?name.localizedValue=='Public IPv4 Addresses - Standard'].{Current:currentValue}" --output tsv)

    # Total Static IPs include Load Balancer Inbound/Outbound, Bastion Host and three for Insights topic-data
    REQUIRED_STATIC_PUBLIC_IPS=6
    REQUIRED_STANDARD_PUBLIC_IPS=$REQUIRED_STATIC_PUBLIC_IPS

    AVAILABLE_STATIC_PUBLIC_IPS=$((QUOTA_STATIC_PUBLIC_IPS - CURRENT_STATIC_PUBLIC_IPS))
    AVAILABLE_STANDARD_PUBLIC_IPS=$((QUOTA_STANDARD_PUBLIC_IPS - CURRENT_STANDARD_PUBLIC_IPS))

    if [ ${AVAILABLE_STATIC_PUBLIC_IPS} -lt ${REQUIRED_STATIC_PUBLIC_IPS} ]
    then
      echo "No capacity to reserve Static Public IPs. Please increase Static Public IP Addresses quota. Available Static Public IPs: ${AVAILABLE_STATIC_PUBLIC_IPS}, Required Static Public IPs: ${REQUIRED_STATIC_PUBLIC_IPS}"
      quotaStatus=1
    fi

    if [ ${AVAILABLE_STANDARD_PUBLIC_IPS} -lt ${REQUIRED_STANDARD_PUBLIC_IPS} ]
    then
      echo "No capacity to reserve Standard Public IPs. Please increase Public IP Addresses - Standard quota. Available Public IP Addresses - Standard: ${AVAILABLE_STANDARD_PUBLIC_IPS}, Required s: ${REQUIRED_STANDARD_PUBLIC_IPS}"
      quotaStatus=1
    fi

    # Check Quotas for vCPUs and Virtual Machines
    QUOTA_TOTAL_REGIONAL_VCPUS=$(az vm list-usage --location "${TF_VAR_region}" --query "[?name.localizedValue=='Total Regional vCPUs'].{Limit:limit}" --output tsv)
    QUOTA_VIRTUAL_MACHINES=$(az vm list-usage --location "${TF_VAR_region}" --query "[?name.localizedValue=='Virtual Machines'].{Limit:limit}" --output tsv)
    QUOTA_STANDARD_EASV5_FAMILY_VCPUS=$(az vm list-usage --location "${TF_VAR_region}" --query "[?name.localizedValue=='Standard EASv5 Family vCPUs'].{Limit:limit}" --output tsv)
    QUOTA_STANDARD_DSV2_FAMILY_VCPUS=$(az vm list-usage --location "${TF_VAR_region}" --query "[?name.localizedValue=='Standard DSv2 Family vCPUs'].{Limit:limit}" --output tsv)

    CURRENT_TOTAL_REGIONAL_VCPUS=$(az vm list-usage --location "${TF_VAR_region}" --query "[?name.localizedValue=='Total Regional vCPUs'].{Current:currentValue}" --output tsv)
    CURRENT_VIRTUAL_MACHINES=$(az vm list-usage --location "${TF_VAR_region}" --query "[?name.localizedValue=='Virtual Machines'].{Current:currentValue}" --output tsv)
    CURRENT_STANDARD_EASV5_FAMILY_VCPUS=$(az vm list-usage --location "${TF_VAR_region}" --query "[?name.localizedValue=='Standard EASv5 Family vCPUs'].{Current:currentValue}" --output tsv)
    CURRENT_STANDARD_DSV2_FAMILY_VCPUS=$(az vm list-usage --location "${TF_VAR_region}" --query "[?name.localizedValue=='Standard DSv2 Family vCPUs'].{Current:currentValue}" --output tsv)

    REQUIRED_AKS_VM_VCPUS_PER_NODE=$(az vm list-skus --resource-type "virtualMachines" --location "${TF_VAR_region}" --size ${AKS_NODE_TYPE} --query "[0].capabilities[?name=='vCPUs'].value | [0]" --output tsv)
    REQUIRED_AKS_VM_VCPUS=$((${REQUIRED_AKS_VM_VCPUS_PER_NODE} * AKS_NODE_COUNT))
    REQUIRED_BASTION_HOST_VM_VCPUS=$(az vm list-skus --resource-type "virtualMachines" --location "${TF_VAR_region}" --size ${BASTION_HOST_NODE_TYPE} --query "[0].capabilities[?name=='vCPUs'].value | [0]" --output tsv)
    REQUIRED_TOTAL_REGIONAL_VCPUS=$((REQUIRED_AKS_VM_VCPUS + REQUIRED_BASTION_HOST_VM_VCPUS))
    REQUIRED_VIRTUAL_MACHINES=$((AKS_NODE_COUNT + 1))

    AVAILABLE_TOTAL_REGIONAL_VCPUS=$((QUOTA_TOTAL_REGIONAL_VCPUS - CURRENT_TOTAL_REGIONAL_VCPUS))
    AVAILABLE_VIRTUAL_MACHINES=$((QUOTA_VIRTUAL_MACHINES - CURRENT_VIRTUAL_MACHINES))
    AVAILABLE_STANDARD_EASV5_FAMILY_VCPUS=$((QUOTA_STANDARD_EASV5_FAMILY_VCPUS - CURRENT_STANDARD_EASV5_FAMILY_VCPUS))
    AVAILABLE_STANDARD_DSV2_FAMILY_VCPUS=$((QUOTA_STANDARD_DSV2_FAMILY_VCPUS - CURRENT_STANDARD_DSV2_FAMILY_VCPUS))

    if [ "${AKS_NODE_DEFAULT_TYPE}" ]
    then
      if [ ${AVAILABLE_STANDARD_EASV5_FAMILY_VCPUS} -lt ${REQUIRED_AKS_VM_VCPUS} ]
      then
        echo "No capacity to create AKS Nodes. Please increase Standard EASv5 Family vCPUs quota. Available Standard EASv5 Family vCPUs: ${AVAILABLE_STANDARD_EASV5_FAMILY_VCPUS}, Required Standard EASv5 Family vCPUs: ${REQUIRED_AKS_VM_VCPUS}"
        quotaStatus=1
      fi
    else
      echo "You have selected a non-default (${AKS_NODE_TYPE}) AKS node type which requires ${REQUIRED_AKS_VM_VCPUS} vCPUs per node. If there is not enough capacity, the deployment may fail. However the check will be marked successful."
    fi

    if [ ${AVAILABLE_STANDARD_DSV2_FAMILY_VCPUS} -lt "${REQUIRED_BASTION_HOST_VM_VCPUS}" ]
    then
      echo "No capacity to create Bastion Host Virtual Machine. Please increase Standard DSv2 Family vCPUs quota. Available Standard Dv2 Family vCPUs: ${AVAILABLE_STANDARD_DV2_FAMILY_VCPUS}, Required Standard Dv2 Family vCPUs: ${REQUIRED_BASTION_HOST_VM_VCPUS}"
      quotaStatus=1
    fi

    if [ ${AVAILABLE_TOTAL_REGIONAL_VCPUS} -lt ${REQUIRED_TOTAL_REGIONAL_VCPUS} ]
    then
      echo "No capacity to create Virtual Machines. Please increase Total Regional vCPUs quota. Available vCPUs: ${AVAILABLE_TOTAL_REGIONAL_VCPUS}, Required vCPUs: ${REQUIRED_TOTAL_REGIONAL_VCPUS}"
      quotaStatus=1
    fi

    if [ ${AVAILABLE_VIRTUAL_MACHINES} -lt ${REQUIRED_VIRTUAL_MACHINES} ]
    then
      echo "No capacity to create Virtual Machines. Please increase Virtual Machines quota. Available Virtual Machines: ${AVAILABLE_VIRTUAL_MACHINES}, Required Virtual Machines: ${REQUIRED_VIRTUAL_MACHINES}"
      quotaStatus=1
    fi

    if [ "$quotaStatus" -eq 0 ]
    then
      echo -e "\r\n--- Quotas are sufficient for deployment. ---\r\n"
    else
      echo -e "\r\n--- Quota check failed. Please increase required quotas. ---\r\n"
      exit 1
    fi

  elif [ "${CLOUD}" = "aws" ]; then

    # Skip check if cluster exists
    aws eks describe-cluster --name "${TF_VAR_cluster_name}" &> /dev/null
    commandStatus=$?
    if [ "$commandStatus" -eq 0 ]
    then
      echo -e "\r\n--- Cluster ${TF_VAR_cluster_name} exists. Skipping pre-deploy-check. ---\r\n"
      return 0
    fi

    # Define Quota Codes to check
    QUOTA_CODE_ELASTIC_IPS=L-0263D0A3
    QUOTA_CODE_ELBS=L-E9E9831D
    QUOTA_CODE_VPCS=L-F678F1CE
    QUOTA_CODE_ON_DEMAND_EC2_INSTANCES=L-1216C47A

    # Define EC2 Instances requirements
    # shellcheck disable=SC2154
    EKS_NODE_TYPE="${TF_VAR_default_node_type}"
    # shellcheck disable=SC2154
    EKS_NODE_COUNT="${TF_VAR_max_node_count}"
    BASTION_HOST_NODE_TYPE=t3.small

    # Generate JSON file for CloudWatch metrics query
    JSON_FILE=$(mktemp)

    # Generate timestamps to use in CloudWatch query for the last 5 minutes
    START_TIME=$(date --iso-8601='minutes' --date="5 minute ago")
    END_TIME=$(date --iso-8601='minutes')

    cat << EOF > "$JSON_FILE"
{
    "MetricDataQueries": [
        {
            "Id": "current_vcpu_allocation",
            "MetricStat": {
                "Metric": {
                    "Namespace": "AWS/Usage",
                    "MetricName": "ResourceCount",
                    "Dimensions": [
                        {
                            "Name": "Type",
                            "Value": "Resource"
                        },
                        {
                            "Name": "Resource",
                            "Value": "vCPU"
                        },
                        {
                            "Name": "Service",
                            "Value": "EC2"
                        },
                        {
                            "Name": "Class",
                            "Value": "Standard/OnDemand"
                        }
                    ]
                },
                "Period": 300,
                "Stat": "Maximum",
                "Unit": "None"
            },
            "Label": "CurrentvCPUAllocation",
            "ReturnData": true
        }
    ],
    "StartTime": "${START_TIME}",
    "EndTime": "${END_TIME}"
}
EOF

    echo -e "\r\n--- Checking aws quotas---\r\n"
    quotaStatus=0

    # Check Quotas for EC2-VPC Elastic IPs
    QUOTA_ELASTIC_IPS=$(aws service-quotas get-service-quota --service-code ec2 --quota-code "${QUOTA_CODE_ELASTIC_IPS}" --region "${TF_VAR_region}" --query "Quota.{Value:Value}" --output text)
    AVAILABITY_ZONES=$(aws ec2 describe-availability-zones --region "${TF_VAR_region}" --query "AvailabilityZones[*].{ZoneName:ZoneName}" --output text | wc -l)
    CURRENT_ELASTIC_IPS=$(aws ec2 describe-addresses --query "Addresses[*].{IP:PublicIp}" --region "${TF_VAR_region}" --output text | wc -l)
    AVAILABLE_ELASTIC_IPS=$((${QUOTA_ELASTIC_IPS/.*} - CURRENT_ELASTIC_IPS))
    # 1 Elastic IP is needed per Availability Zone for NAT Gateway and 1 per Region for Bastion Host
    REQUIRED_ELASTIC_IPS=$((AVAILABITY_ZONES + 1))
    if [ ${AVAILABLE_ELASTIC_IPS} -lt ${REQUIRED_ELASTIC_IPS} ]
    then
      echo "No capacity to reserve Elastic IPs. Please increase quota code ${QUOTA_CODE_ELASTIC_IPS} (EC2-VPC Elastic IPs). Available Elastic IPs: ${AVAILABLE_ELASTIC_IPS}, Required Elastic IPs: ${REQUIRED_ELASTIC_IPS}"
      quotaStatus=1
    fi

    # Check Quotas for Classic Load Balancers per Region
    QUOTA_ELBS=$(aws service-quotas get-service-quota --service-code elasticloadbalancing --quota-code "${QUOTA_CODE_ELBS}" --region "${TF_VAR_region}" --query "Quota.{Value:Value}" --output text)
    CURRENT_ELBS=$(aws elb describe-load-balancers --region "${TF_VAR_region}" --query "LoadBalancerDescriptions[*].{LoadBalancerName:LoadBalancerName}" --output text | wc -l)
    AVAILABLE_ELBS=$((${QUOTA_ELBS/.*} - CURRENT_ELBS))
    REQUIRED_ELBS=1
    if [ "${AVAILABLE_ELBS}" -lt "${REQUIRED_ELBS/.*}" ]
    then
      echo "No capacity to create ELB. Please increase quota code ${QUOTA_CODE_ELBS} (Classic Load Balancers per Region). Available ELBs: ${AVAILABLE_ELBS}, Required ELBs: ${REQUIRED_ELBS}"
      quotaStatus=1
    fi

    # Check Quotas for VPCs per Region
    QUOTA_VPCS=$(aws service-quotas get-service-quota --service-code vpc --quota-code "${QUOTA_CODE_VPCS}" --region "${TF_VAR_region}" --query "Quota.{Value:Value}" --output text)
    CURRENT_VPCS=$(aws ec2 describe-vpcs --query 'Vpcs[*].{VpcId:VpcId}' --region "${TF_VAR_region}" --output text | wc -l)
    AVAILABLE_VPCS=$((${QUOTA_VPCS/.*} -  CURRENT_VPCS))
    REQUIRED_VPCS=1
    if [ "${AVAILABLE_VPCS}" -lt "${REQUIRED_VPCS}" ]
    then
      echo "No capacity to create VPC. Please increase quota code ${QUOTA_CODE_VPCS} (VPCs per Region). Available VPCs: ${AVAILABLE_VPCS}, Required VPCs:${REQUIRED_VPCS}"
      quotaStatus=1
    fi

    # Check Quotas for On-Demand Standard EC2 Instances
    QUOTA_ON_DEMAND_EC2_INSTANCES=$(aws service-quotas get-service-quota --service-code ec2 --quota-code "${QUOTA_CODE_ON_DEMAND_EC2_INSTANCES}" --region "${TF_VAR_region}" --query "Quota.{Value:Value}" --output text)
    CURRENT_ON_DEMAND_EC2_INSTANCES=$(aws cloudwatch get-metric-data --cli-input-json file://"${JSON_FILE}" --query "MetricDataResults[*].Values" --output text)
    # Set value to zero if no data is returned
    [ -z "$CURRENT_ON_DEMAND_EC2_INSTANCES" ] && CURRENT_ON_DEMAND_EC2_INSTANCES=0
    AVAILABLE_ONDEMAND_EC2_INSTANCES=$((${QUOTA_ON_DEMAND_EC2_INSTANCES/.*} - ${CURRENT_ON_DEMAND_EC2_INSTANCES/.*}))
    REQUIRED_EKS_ONDEMAND_EC2_INSTANCES=$(aws ec2 describe-instance-types --instance-types "${EKS_NODE_TYPE}" --query "InstanceTypes[*].VCpuInfo.DefaultVCpus" --output text)
    REQUIRED_BASTION_HOST_ONDEMAND_EC2_INSTANCES=$(aws ec2 describe-instance-types --instance-types "${BASTION_HOST_NODE_TYPE}" --query "InstanceTypes[*].VCpuInfo.DefaultVCpus" --output text)
    REQUIRED_ONDEMAND_EC2_INSTANCES=$((REQUIRED_EKS_ONDEMAND_EC2_INSTANCES * EKS_NODE_COUNT + REQUIRED_BASTION_HOST_ONDEMAND_EC2_INSTANCES))

    if [ ${AVAILABLE_ONDEMAND_EC2_INSTANCES} -lt ${REQUIRED_ONDEMAND_EC2_INSTANCES} ]
    then
      echo "No capacity to create EC2 Instances. Please increase quota code ${QUOTA_CODE_ON_DEMAND_EC2_INSTANCES} (On-Demand Standard EC2 Instances). Available On Demand vCPUs: ${AVAILABLE_ONDEMAND_EC2_INSTANCES}, Required On Demand vCPUs: ${REQUIRED_ONDEMAND_EC2_INSTANCES}"
      quotaStatus=1
    fi

    if [ "$quotaStatus" -eq 0 ]
    then
      echo -e "\r\n--- Quotas are sufficient for deployment. ---\r\n"
    else
      echo -e "\r\n--- Quota check failed. Please increase required quotas. ---\r\n"
      exit 1
    fi

  elif [ "${CLOUD}" = "gcp" ]; then

    # Login to GCP using service account
    gcloud auth activate-service-account --key-file="${GOOGLE_APPLICATION_CREDENTIALS}" --project="${TF_VAR_project}" --no-user-output-enabled

    # Skip check if cluster exists
    gcloud container clusters list --region "${TF_VAR_region}" |grep -q "${TF_VAR_cluster_name}"
    commandStatus=$?
    if [ "$commandStatus" -eq 0 ]
    then
      echo -e "\r\n--- Cluster ${TF_VAR_cluster_name} exists. Skipping pre-deploy-check. ---\r\n"
      return 0
    fi

    # Define VM Instances requirements
    # shellcheck disable=SC2154
    GKE_NODE_TYPE="${TF_VAR_default_node_type}"
    # shellcheck disable=SC2154
    GKE_NODE_COUNT=$((TF_VAR_max_node_count * 3))
    BASTION_HOST_NODE_TYPE=e2-medium

    echo -e "\r\n--- Checking gcp quotas---\r\n"
    quotaStatus=0

    # Check VM limits
    # gcloud compute regions describe us-central1 --format="table(quotas:format='table(metric,limit,usage)')"
    ZONE=$(gcloud compute zones list --filter="region:${TF_VAR_region}" --format='value(name)' | sort | head -1)
    QUOTA_REGION=$(gcloud compute regions describe "${TF_VAR_region}" --project "${TF_VAR_project}" --format="json(quotas)")
    QUOTA_CPUS=$(echo "${QUOTA_REGION}" | jq '.quotas[] | select(.metric | startswith("CPUS")) | .limit')
    CURRENT_CPUS=$(echo "${QUOTA_REGION}" | jq '.quotas[] | select(.metric | startswith("CPUS")) | .usage')
    AVAILABLE_CPUS=$((${QUOTA_CPUS/.*} -  ${CURRENT_CPUS/.*}))
    REQUIRED_GKE_CPUS=$(gcloud compute machine-types list --filter="zone = ${ZONE} AND name = ${GKE_NODE_TYPE}" --format="value(guestCpus)")
    REQUIRED_BASTION_HOST_CPUS=$(gcloud compute machine-types list --filter="zone = ${ZONE} AND name = ${BASTION_HOST_NODE_TYPE}" --format="value(guestCpus)")

    REQUIRED_CPUS=$((REQUIRED_GKE_CPUS * GKE_NODE_COUNT + REQUIRED_BASTION_HOST_CPUS))

    if [ ${AVAILABLE_CPUS} -lt ${REQUIRED_CPUS} ]
    then
      echo "No capacity to create VM Instances. Please increase CPUS quota on ${TF_VAR_project} project. Available CPUs: ${AVAILABLE_CPUS}, Required CPUs:${REQUIRED_CPUS}"
      quotaStatus=1
    fi

    # Check networks and static ip addresses
    QUOTA_PROJECT=$(gcloud compute project-info describe --project "${TF_VAR_project}" --format="json(quotas)")
    QUOTA_VPCS=$(echo "${QUOTA_PROJECT}" | jq '.quotas[] | select(.metric | startswith("NETWORKS")) | .limit')
    CURRENT_VPCS=$(echo "${QUOTA_PROJECT}" | jq '.quotas[] | select(.metric | startswith("NETWORKS")) | .usage')
    AVAILABLE_VPCS=$((${QUOTA_VPCS/.*} -  ${CURRENT_VPCS/.*}))
    REQUIRED_VPCS=1
    QUOTA_STATIC_IPS=$(echo "${QUOTA_PROJECT}" | jq '.quotas[] | select(.metric | startswith("STATIC_ADDRESSES")) | .limit')
    CURRENT_STATIC_IPS=$(echo "${QUOTA_PROJECT}" | jq '.quotas[] | select(.metric | startswith("STATIC_ADDRESSES")) | .usage')
    AVAILABLE_STATIC_IPS=$((${QUOTA_STATIC_IPS/.*} -  ${CURRENT_STATIC_IPS/.*}))
    REQUIRED_STATIC_IPS=1

    if [ ${AVAILABLE_VPCS} -lt ${REQUIRED_VPCS} ]
    then
      echo "No capacity to create VPC. Please increase Networks quota on ${TF_VAR_project} project. Available VPCs: ${AVAILABLE_VPCS}, Required VPCs:${REQUIRED_VPCS}"
      quotaStatus=1
    else
      if [ "${AVAILABLE_STATIC_IPS}" -lt "${REQUIRED_STATIC_IPS}" ]
      then
        echo "No capacity to reserve Static IPs. Please increase Static IP addresses global quota on ${TF_VAR_project} project. Available Static IPs: ${AVAILABLE_STATIC_IPS}, Required Static IPs:${REQUIRED_STATIC_IPS}"
        quotaStatus=1
      fi
    fi
    if [ "$quotaStatus" -eq 0 ]
    then
      echo -e "\r\n--- Quotas are sufficient for deployment. ---\r\n"
    else
      echo -e "\r\n--- Quota check failed. Please increase required quotas. ---\r\n"
      exit 1
    fi

  fi
}

check_availability_zones() {

  echo -e "\r\n--- Checking node pool restrictions ---\r\n"
  if [ "${CLOUD}" = "azure" ]
  then
    DEFAULT_NODE_POOL_ZONE_LIST_FILE=$(mktemp)
    DEFAULT_NODE_POOL_RESTRICTED_ZONES_FILE=$(mktemp)
    # Get default node type SKUs
    DEFAULT_NODE_POOL_INSTANCE_TYPE_SKUS=$(az vm list-skus --location ${TF_VAR_region} --size ${TF_VAR_default_node_type})
    if [ "$(echo ${DEFAULT_NODE_POOL_INSTANCE_TYPE_SKUS} | jq -c .[0])" = "null" ]
    then
      echo "Instance type ${TF_VAR_default_node_type} is not available in ${TF_VAR_region} region. Please select a different instance type and update kxi-terraform.env"
      exit 0
    fi
    # Check if instance type has any restrictions
    DEFAULT_NODE_POOL_INSTANCE_TYPE_RESTRICTIONS=$(echo ${DEFAULT_NODE_POOL_INSTANCE_TYPE_SKUS} | jq -c .[0].restrictions[0])
    if [ "${DEFAULT_NODE_POOL_INSTANCE_TYPE_RESTRICTIONS}" = "null" ]
    then
      echo "No restrictions for default pool node type"
      #default_node_pool_zones=$(echo ${DEFAULT_NODE_POOL_INSTANCE_TYPE_SKUS} | jq -c .[0].locationInfo[0].zones)
      #export TF_VAR_default_node_pool_zones=$(echo ${DEFAULT_NODE_POOL_INSTANCE_TYPE_SKUS} | jq -c .[0].locationInfo[0] | jq -r '.zones[]' | sort)
      default_node_pool_zones=$(echo ${DEFAULT_NODE_POOL_INSTANCE_TYPE_SKUS} | jq -r .[0].locationInfo[0].zones[] | sort | tr ' ' '\n' | sed -e 's/\(.*\)/"\1"/' | tr '\n' ',' | sed 's/,$//g')
      export TF_VAR_default_node_pool_zones="[$(echo ${default_node_pool_zones})]"
    else
      echo "Restrictions found for default pool node type"
      echo ${DEFAULT_NODE_POOL_INSTANCE_TYPE_SKUS} | jq -c .[0].locationInfo[0] |  jq -r '.zones[]' | sort > ${DEFAULT_NODE_POOL_ZONE_LIST_FILE}
      echo ${DEFAULT_NODE_POOL_INSTANCE_TYPE_SKUS} | jq -c .[0].restrictions[0].restrictionInfo |  jq -r '.zones[]' | sort > ${DEFAULT_NODE_POOL_RESTRICTED_ZONES_FILE}
      default_node_pool_zones=$(comm -3 ${DEFAULT_NODE_POOL_ZONE_LIST_FILE} ${DEFAULT_NODE_POOL_RESTRICTED_ZONES_FILE} | tr ' ' '\n' | sed -e 's/\(.*\)/"\1"/' | tr '\n' ',' | sed 's/,$//g')
      export TF_VAR_default_node_pool_zones="[$(echo ${default_node_pool_zones})]"
    fi
    echo "The default AKS Node Pool is configured on zones ${TF_VAR_default_node_pool_zones} of ${TF_VAR_region} region."
    echo ""
    if [[ "$TF_VAR_enable_rook_ceph_node_pool" == "true" ]]
    then
      ROOK_CEPH_POOL_ZONE_LIST_FILE=$(mktemp)
      ROOK_CEPH_POOL_RESTRICTED_ZONES_FILE=$(mktemp)
      # Get rook-ceph node type SKUs
      ROOK_CEPH_POOL_INSTANCE_TYPE_SKUS=$(az vm list-skus --location ${TF_VAR_region} --size ${TF_VAR_rook_ceph_pool_node_type})
      if [ "$(echo ${ROOK_CEPH_POOL_INSTANCE_TYPE_SKUS} | jq -c .[0])" = "null" ]
      then
        echo "Instance type ${TF_VAR_rook_ceph_pool_node_type} is not available in ${TF_VAR_region} region. Please select a different instance type and update kxi-terraform.env"
        exit 0
      fi
      # Check if instance type has any restrictions
      ROOK_CEPH_NODE_POOL_INSTANCE_TYPE_RESTRICTIONS=$(echo ${ROOK_CEPH_POOL_INSTANCE_TYPE_SKUS} | jq -c .[0].restrictions[0])
      if [ "${ROOK_CEPH_NODE_POOL_INSTANCE_TYPE_RESTRICTIONS}" = "null" ]
      then
        echo "No restrictions for rook-ceph pool node type"
        rook_ceph_pool_zones=$(echo ${ROOK_CEPH_POOL_INSTANCE_TYPE_SKUS} | jq -r .[0].locationInfo[0].zones[] | sort | tr ' ' '\n' | sed -e 's/\(.*\)/"\1"/' | tr '\n' ',' | sed 's/,$//g')
        export TF_VAR_rook_ceph_node_pool_zones="[$(echo ${rook_ceph_pool_zones})]"
      else
        echo "Restrictions found for rook-ceph pool node type"
        echo ${ROOK_CEPH_POOL_INSTANCE_TYPE_SKUS} | jq -c .[0].locationInfo[0] |  jq -r '.zones[]' | sort > ${ROOK_CEPH_POOL_ZONE_LIST_FILE}
        echo ${ROOK_CEPH_POOL_INSTANCE_TYPE_SKUS} | jq -c .[0].restrictions[0].restrictionInfo |  jq -r '.zones[]' | sort > ${ROOK_CEPH_POOL_RESTRICTED_ZONES_FILE}
        rook_ceph_pool_zones=$(comm -3 ${ROOK_CEPH_POOL_ZONE_LIST_FILE} ${ROOK_CEPH_POOL_RESTRICTED_ZONES_FILE} | tr ' ' '\n' | sed -e 's/\(.*\)/"\1"/' | tr '\n' ',' | sed 's/,$//g')
        export TF_VAR_rook_ceph_node_pool_zones="[$(echo ${rook_ceph_pool_zones})]"
      fi
      echo "The rook-ceph AKS Node Pool is configured on zones ${TF_VAR_rook_ceph_node_pool_zones} of ${TF_VAR_region} region."
    fi
  fi
}

check_network_rules() {

  echo -e "\r\n--- Checking network rules ---\r\n"

  if [ "${CLOUD}" = "aws" ]
  then
    # Check current Network ACL quota
    QUOTA_CODE_RULES_PER_NETWORK_ACL=L-2AEEBF1A
    TERRAFORM_RESERVED_RULES_COUNT=10
    QUOTA_RULES_PER_NETWORK_ACL=$(aws service-quotas get-service-quota --service-code vpc --quota-code "${QUOTA_CODE_RULES_PER_NETWORK_ACL}" --region "${TF_VAR_region}" --query "Quota.{Value:Value}" --output text)
    QUOTA_RULES_PER_NETWORK_ACL_INTEGER=${QUOTA_RULES_PER_NETWORK_ACL%%.*}
    AVAILABLE_RULES=$((${QUOTA_RULES_PER_NETWORK_ACL_INTEGER} - ${TERRAFORM_RESERVED_RULES_COUNT}))
    BASTION_WHITELIST_IPS_COUNT=$(echo "$TF_VAR_bastion_whitelist_ips" | jq length)
    BASTION_WHITELIST_IPS_RULES_COUNT=$(($BASTION_WHITELIST_IPS_COUNT * 2)) # SSH and OpenVPN
    INSIGHTS_WHITELIST_IPS_COUNT=$(echo "$TF_VAR_insights_whitelist_ips" | jq length)
    INSIGHTS_WHITELIST_IPS_RULES_COUNT=$(($INSIGHTS_WHITELIST_IPS_COUNT * 1)) # HTTPS
    TOTAL_REQUIRED_RULES=$(($BASTION_WHITELIST_IPS_RULES_COUNT + $INSIGHTS_WHITELIST_IPS_RULES_COUNT))
    if [[ ${TOTAL_REQUIRED_RULES} -gt $AVAILABLE_RULES ]]
    then
      echo "Available Network ACL Rules: $AVAILABLE_RULES"
      echo "Required Network ACL Rules: $TOTAL_REQUIRED_RULES"
      echo "You need to reduce the number of CIDRs on TF_VAR_bastion_whitelist_ips and/or TF_VAR_insights_whitelist_ips variables or raise a request to increase the quota of Network ACL Rules."
      exit 1
    fi
  fi
}

upload_artifacts() {

  # Create a sanitised temp copy of the env file
  if [ -f "kxi-terraform.env" ]; then
    SANITISED_ENV=kxi-terraform.env-sanitised
    grep -vE '^(AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|ARM_CLIENT_ID|ARM_CLIENT_SECRET)=' kxi-terraform.env > "$SANITISED_ENV"
  else
    echo "kxi-terraform.env does not exist. Skipping..."
    SANITISED_ENV=""
  fi

  # List of files to upload including sanitised terraform file
  local files=("version.txt" "terraform/${CLOUD}/client.ovpn")
  if [ -n "$SANITISED_ENV" ]; then
    files+=("$SANITISED_ENV")
  fi

  echo -e "\n--- Uploading files to ${CLOUD} backend ---\n"

  for file in "${files[@]}"; do
    if [ ! -f "$file" ]; then
      echo "File $file does not exist. Skipping..."
      continue
    fi

    case "${CLOUD}" in
      "aws")
        # Upload file to S3
        aws s3 cp "$file" "s3://${KX_STATE_BUCKET_NAME}/${ENV}/$(basename "$file")" --region "$REGION"
        ;;
      "azure")
        # Upload file to storage blob

        if [ -z "$KX_STATE_STORAGE_ACCOUNT_NAME" ] || [ -z "$KX_STATE_BUCKET_NAME" ] || [ -z "$KX_STATE_RESOURCE_GROUP_NAME" ]; then
          echo "Missing Azure storage variables. Please ensure KX_STATE_STORAGE_ACCOUNT_NAME, KX_STATE_BUCKET_NAME and KX_STATE_RESOURCE_GROUP_NAME are set."
          return 1
        fi

        STORAGE_KEY=$(az storage account keys list \
          --resource-group "$KX_STATE_RESOURCE_GROUP_NAME" \
          --account-name "$KX_STATE_STORAGE_ACCOUNT_NAME" \
          --query "[0].value" -o tsv)

        az storage blob upload \
          --account-name "$KX_STATE_STORAGE_ACCOUNT_NAME" \
          --container-name "$KX_STATE_BUCKET_NAME" \
          --file "$file" \
          --name "${ENV}/$(basename "$file")" \
          --auth-mode key \
          --account-key "$STORAGE_KEY" \
          --overwrite true
        ;;
      "gcp")
        # Upload file to gcp bucket
        gsutil cp "$file" "gs://${KX_STATE_BUCKET_NAME}/${ENV}/$(basename "$file")"
        ;;
      *)
        echo "Unsupported CLOUD value: $CLOUD"
        return 1
        ;;
    esac

    if [ $? -eq 0 ]; then
      echo "Uploaded $file successfully."
    else
      echo "Failed to upload $file."
    fi
  done
}

delete_uploaded_artifacts() {
  echo -e "\n--- Deleting uploaded artifacts from ${CLOUD} backend ---\n"

  local files=("version.txt" "client.ovpn" "kxi-terraform.env-sanitised")

  for filename in "${files[@]}"; do
    case "${CLOUD}" in
      "aws")
        aws s3 rm "s3://${KX_STATE_BUCKET_NAME}/${ENV}/${filename}" --region "$REGION"
        ;;
      "azure")
        if [ -z "$KX_STATE_STORAGE_ACCOUNT_NAME" ] || [ -z "$KX_STATE_BUCKET_NAME" ] || [ -z "$KX_STATE_RESOURCE_GROUP_NAME" ]; then
          echo "Missing Azure storage variables. Please ensure KX_STATE_STORAGE_ACCOUNT_NAME, KX_STATE_BUCKET_NAME and KX_STATE_RESOURCE_GROUP_NAME are set."
          return 1
        fi

        STORAGE_KEY=$(az storage account keys list \
          --resource-group "$KX_STATE_RESOURCE_GROUP_NAME" \
          --account-name "$KX_STATE_STORAGE_ACCOUNT_NAME" \
          --query "[0].value" -o tsv)

        az storage blob delete \
          --account-name "$KX_STATE_STORAGE_ACCOUNT_NAME" \
          --container-name "$KX_STATE_BUCKET_NAME" \
          --name "${ENV}/${filename}" \
          --auth-mode key \
          --account-key "$STORAGE_KEY"
        ;;
      "gcp")
        gsutil rm "gs://${KX_STATE_BUCKET_NAME}/${ENV}/${filename}"
        ;;
      *)
        echo "Unsupported CLOUD value: $CLOUD"
        return 1
        ;;
    esac

    if [ $? -eq 0 ]; then
      echo "Deleted ${filename} successfully."
    else
      echo "Failed to delete ${filename}."
    fi
  done

  echo -e "\n--- Artifact deletion complete ---\n"
}



if [[ $# -eq 0 ]]; then
    usage
    exit 1
fi

if [ -z "$CLOUD" ]; then
    echo "Please provide CLOUD in environment variables" 1>&2
    exit 1
fi
if [ -z "$ENV" ] && [ "$1" !=  "check-vars" ] && [ "$1" !=  "check-credentials" ] && [ "$1" !=  "check-quotas" ] && [ "$1" !=  "pre-deploy-check" ]; then
    echo "Please provide ENV in environment variables" 1>&2
    exit 1
fi
if [ -z "$TF_ROOT" ]; then
    export TF_ROOT="terraform/${CLOUD}"
fi
if [ -z "$TF_VAR_cluster_name" ]; then
    export TF_VAR_cluster_name="${CLOUD}-${ENV}"
fi


if [ "${CLOUD}" = "aws" ]
then
  export AWS_DEFAULT_REGION="${TF_VAR_region}"
fi

if [ "${CLOUD}" = "gcp" ]
then
  # Authenticate to GCP
  authenticate
  # Pick the first zone from the region when using Performance or Cost-Optimised profile
  if [[ "${PROFILE}" = "ha" ]]
  then
    zone1=$(gcloud compute zones list --filter="region:${TF_VAR_region}" --format='value(name)' | sort | head -1)
    zone2=$(gcloud compute zones list --filter="region:${TF_VAR_region}" --format='value(name)' | sort | head -2| tail -1)
    zone3=$(gcloud compute zones list --filter="region:${TF_VAR_region}" --format='value(name)' | sort | head -3| tail -1)
    export TF_VAR_zones="[\"${zone1}\",\"${zone2}\",\"${zone3}\"]"
    export TF_VAR_regional=true
  else
    zone=$(gcloud compute zones list --filter="region:${TF_VAR_region}" --format='value(name)' | sort | head -1)
    export TF_VAR_zones="[\"${zone}\"]"
    export TF_VAR_regional=false
  fi
fi

SCRIPT_OPERATION=$1
MODULE=$2
USE_ALL=false

case $MODULE in
  "cluster")
    TF_ROOT="terraform/${CLOUD}"
    TERRAFORM_STATE_NAME="${CLOUD}-${ENV}"
    ;;
  "config")
    TF_ROOT="terraform/k8s_config_${CLOUD}"
    TERRAFORM_STATE_NAME="${CLOUD}-${ENV}-config"
    export TF_VAR_cloud=${CLOUD}
    ;;
  "services")
    TF_ROOT="terraform/${CLOUD}-services"
    TERRAFORM_STATE_NAME="${CLOUD}-${ENV}-services"
    ;;
  "all")
    USE_ALL=true
    ;;
  *)
    if [ "$SCRIPT_OPERATION" !=  "vpn" ] && [ "$SCRIPT_OPERATION" !=  "ssh" ] && [ "$SCRIPT_OPERATION" !=  "kubeconfig" ] && [ "$SCRIPT_OPERATION" !=  "authenticate" ] && [ "$SCRIPT_OPERATION" !=  "connect" ] && [ "$SCRIPT_OPERATION" !=  "check-vars" ] && [ "$SCRIPT_OPERATION" !=  "check-credentials" ] &&  [ "$SCRIPT_OPERATION" !=  "check-node-types" ] && [ "$SCRIPT_OPERATION" !=  "check-quotas" ] && [ "$SCRIPT_OPERATION" !=  "check-tags" ] && [ "$SCRIPT_OPERATION" !=  "check-availability-zones" ]  && [ "$SCRIPT_OPERATION" !=  "check-network-rules" ] && [ "$SCRIPT_OPERATION" !=  "pre-deploy-check" ] && [ "$SCRIPT_OPERATION" !=  "upload-artifacts" ] && [ "$SCRIPT_OPERATION" != "delete-artifacts" ]; then
      echo "Invalid option $MODULE, please use one of cluster|config|services."
      usage
      exit 1
    fi
    ;;
esac

PLANFILE=".terraform/${MODULE}-${CLOUD}-${ENV}.tfplan"
case $SCRIPT_OPERATION in
  "deploy")
    if [ $USE_ALL = "true" ]
    then
      TF_OPERATION="deploy-all"
    else
      echo "Invalid operation $SCRIPT_OPERATION for $MODULE, please use deploy all"
      usage
      exit 1
    fi
    ;;
  "plan")
    TF_OPERATION=$SCRIPT_OPERATION
    TF_ARGS="-out=${PLANFILE}"
    ;;
  "apply")
    TF_OPERATION="apply"
    TF_ARGS="-input=false ${PLANFILE}"
    ;;
  "destroy")
    if [ $USE_ALL = "true" ]
    then
      TF_OPERATION="destroy-all"
    else
      TF_OPERATION="apply"
      TF_ARGS="-input=false ${PLANFILE}"
    fi
    ;;
  "init")
    if [ -d "$TF_ROOT" ]; then cd "$TF_ROOT" || exit 1; fi
    tf_init
    exit 0
    ;;
  "plan-destroy")
    TF_OPERATION="plan -destroy"
    TF_ARGS="-out=${PLANFILE}"
    ;;
  "output")
    TF_OPERATION="output"
    TF_ARGS=""
    ;;
  "validate")
    TF_OPERATION="validate"
    TF_ARGS=""
    ;;
  "state")
    TF_OPERATION="state"
    TF_ARGS=""
    ;;
  "vpn")
    vpn "$2" "terraform/${CLOUD}/client.ovpn"
    exit 0
    ;;
  "ssh")
    ssh_bastion "terraform/${CLOUD}"
    exit 0
    ;;
  "kubeconfig")
    run_kubeconfig
    exit 0
    ;;
  "authenticate")
    authenticate
    exit 0
    ;;
  "connect")
    authenticate
    run_kubeconfig
    vpn up "terraform/${CLOUD}/client.ovpn"
    exit 0
    ;;
  "check-vars")
    check_vars
    exit 0
    ;;
  "check-apis")
    check_apis
    exit 0
    ;;
  "check-credentials")
    check_credentials
    exit 0
    ;;
  "check-region")
    check_region
    exit 0
    ;;
  "check-node-types")
    check_node_types
    exit 0
    ;;
  "check-tags")
    check_tags
    exit 0
    ;;
  "check-availability-zones")
    check_availability_zones
    exit 0
    ;;
  "check-network-rules")
    check_network_rules
    exit 0
    ;;
  "check-quotas")
    check_quotas
    exit 0
    ;;
  "pre-deploy-check")
    check_vars
    check_credentials
    check_apis
    check_tags
    check_region
    check_node_types
    check_network_rules
    check_quotas
    exit 0
    ;;
  "upload-artifacts")
    upload_artifacts
    exit 0
    ;;
  "delete-artifacts")
    delete_uploaded_artifacts
    exit 0
    ;;
  *)
    echo "Unsupported operation $1."
    usage
    exit 1
esac

if [ "$TF_OPERATION" == "deploy-all" ]
then
  set -e
  authenticate
  check_availability_zones
  vpn down
  TF_ROOT="terraform/${CLOUD}"
  TERRAFORM_STATE_NAME="${CLOUD}-${ENV}"
  PLANFILE=".terraform/cluster-${CLOUD}-${ENV}.tfplan"
  cd_to_tf_root
  tf_init
  # shellcheck disable=SC2086
  terraform plan -out=${PLANFILE}
  # shellcheck disable=SC2086
  terraform apply -input=false ${PLANFILE}
  # Only try VPN if not in private_only or existing_vpc mode
  if [[ "$TF_VAR_private_only" != "true" ]] && [[ "$TF_VAR_existing_vpc" != "true" ]]; then
    set +e
    vpn up client.ovpn
    set -e
  else
    echo ""
    echo "=========================================="
    echo "Skipping VPN connection"
    echo "=========================================="
    if [[ "$TF_VAR_private_only" == "true" ]]; then
      echo "Reason: private_only mode is enabled"
      echo "Assuming cluster has public endpoint access for deployment"
    elif [[ "$TF_VAR_existing_vpc" == "true" ]]; then
      echo "Reason: using existing VPC"
      echo "Assuming direct connectivity to cluster"
    fi
    echo ""
  fi

  # Deploy k8s config
  TF_ROOT="terraform/k8s_config_${CLOUD}"
  TERRAFORM_STATE_NAME="${CLOUD}-${ENV}-config"
  export TF_VAR_cloud=${CLOUD}
  PLANFILE=".terraform/config-${CLOUD}-${ENV}.tfplan"
  cd_to_tf_root
  tf_init
  # shellcheck disable=SC2086
  terraform plan -out=${PLANFILE}
  # shellcheck disable=SC2086
  terraform apply -input=false ${PLANFILE}
  echo ""
  # add kubeconfig entry only if running outside container
  if [ ! -f /.dockerenv ]; then
    run_kubeconfig
  fi
  echo ""
  cd ../../

  upload_artifacts
  echo ""
elif [ "$TF_OPERATION" == "destroy-all" ]
then
  if [ "${CLOUD}" = "aws" ]
  then
    for i in 1 2 3; do
      echo "Delete AWS Network Load Balancers"

      # Get VPC ID based on Name
      VPC_ID=$(aws ec2 describe-vpcs --filters "Name=tag:Name,Values='${TF_VAR_cluster_name}'" --query 'Vpcs[*].{VpcId:VpcId}' --output text)

      # Get AWS Network Load Balancer ARNs
      NLB_ARNS=$(aws elbv2 describe-load-balancers --query "LoadBalancers[?VpcId=='${VPC_ID}'].LoadBalancerArn" --output text)

      # Delete AWS Network Load Balancers
      for nlb_arn in ${NLB_ARNS}
      do
        aws elbv2 delete-load-balancer --load-balancer-arn "${nlb_arn}"
      done

      echo "Delete AWS Target Groups"

      # Get AWS Network Load Balancer Target Group ARNs
      TG_ARNS=$(aws elbv2 describe-target-groups --query "TargetGroups[?VpcId=='${VPC_ID}'].TargetGroupArn" --output text)

      # Delete AWS Target Groups
      for tg_arn in ${TG_ARNS}
      do
        aws elbv2 delete-target-group --target-group-arn "${tg_arn}"
      done

      echo "Delete AWS Classic Load Balancers"

      # Get AWS Classic Load Balancer ARNs
      CLB_NAMES=$(aws elb describe-load-balancers --query "LoadBalancerDescriptions[?VPCId=='${VPC_ID}'].LoadBalancerName" --output text)

      # Delete AWS Classic Load Balancers
      for clb_name in ${CLB_NAMES}
      do
        aws elb delete-load-balancer --load-balancer-name "${clb_name}"
      done

      echo "Remove load balancer rules from AWS EKS Security Groups"

      # Get AWS EKS Security Group ID - Master Nodes
      EKS_SG_ID_MASTER=$(aws ec2 describe-security-groups  --query "SecurityGroups[?VpcId=='${VPC_ID}'].{ID:GroupId}" --filters "Name=group-name,Values=eks-cluster-sg-${TF_VAR_cluster_name}*" --output text)

      # Get AWS EKS Security Group ID - Worker Nodes
      EKS_SG_ID_WORKER=$(aws ec2 describe-security-groups  --query "SecurityGroups[?VpcId=='${VPC_ID}'].{ID:GroupId}" --filters "Name=group-name,Values=${TF_VAR_cluster_name}-node*" --output text)

      # Get AWS Load Balancer Security Group IDs
      LB_SG_IDS=$(aws ec2 describe-security-groups  --query "SecurityGroups[?VpcId=='${VPC_ID}'].{ID:GroupId}" --filters "Name=group-name,Values=k8s-elb-*" --output text)

      # Remove load balancer rules from EKS Security Groups
      for lb_sg_id in ${LB_SG_IDS}
      do
        aws ec2 revoke-security-group-ingress --group-id "${EKS_SG_ID_MASTER}" --source-group "${lb_sg_id}"  --protocol -1 1> /dev/null
        aws ec2 revoke-security-group-ingress --group-id "${EKS_SG_ID_WORKER}" --source-group "${lb_sg_id}"  --protocol -1 1> /dev/null
      done

      # Wait until all security group rules are removed
      sleep 20

      echo "Delete AWS Load Balancer Security Groups"

      # Delete AWS Load Balancer Security Groups
      for lb_sg_id in ${LB_SG_IDS}
      do
        aws ec2 delete-security-group --group-id "$lb_sg_id" 1> /dev/null
      done

      sleep 20

      NLB_ARNS=$(aws elbv2 describe-load-balancers --query "LoadBalancers[?VpcId=='${VPC_ID}'].LoadBalancerArn" --output text)
      TG_ARNS=$(aws elbv2 describe-target-groups --query "TargetGroups[?VpcId=='${VPC_ID}'].TargetGroupArn" --output text)
      CLB_NAMES=$(aws elb describe-load-balancers --query "LoadBalancerDescriptions[?VPCId=='${VPC_ID}'].LoadBalancerName" --output text)
      EKS_SG_ID_MASTER=$(aws ec2 describe-security-groups  --query "SecurityGroups[?VpcId=='${VPC_ID}'].{ID:GroupId}" --filters "Name=group-name,Values=eks-cluster-sg-${TF_VAR_cluster_name}*" --output text)
      EKS_SG_ID_WORKER=$(aws ec2 describe-security-groups  --query "SecurityGroups[?VpcId=='${VPC_ID}'].{ID:GroupId}" --filters "Name=group-name,Values=${TF_VAR_cluster_name}-node*" --output text)
      LB_SG_IDS=$(aws ec2 describe-security-groups  --query "SecurityGroups[?VpcId=='${VPC_ID}'].{ID:GroupId}" --filters "Name=group-name,Values=k8s-elb-*" --output text)

      if [[ -z "$NLB_ARNS" && -z "$TG_ARNS" && -z "$CLB_NAMES" && -z "$EKS_SG_ID_MASTER" && -z "$EKS_SG_ID_WORKER" && -z "$LB_SG_IDS" ]]; then
        echo "All AWS resources destroyed"
        break
      else
        echo "Destroy failed....Retrying"
      fi
    done
  fi
  set -e
  authenticate
  check_availability_zones
  TF_ROOT="terraform/${CLOUD}"
  cd_to_tf_root
  # Check if VPN client file exists
  if [ -f client.ovpn ]
  then
    vpn down
    set +e
    vpn up client.ovpn
    TF_ROOT="terraform/k8s_config_${CLOUD}"
    TERRAFORM_STATE_NAME="${CLOUD}-${ENV}-config"
    export TF_VAR_cloud=${CLOUD}
    PLANFILE=".terraform/config-${CLOUD}-${ENV}.tfplan"
    cd_to_tf_root
    tf_init
    # shellcheck disable=SC2086
    terraform plan -destroy -out=${PLANFILE}
    # shellcheck disable=SC2086
    terraform  apply -input=false ${PLANFILE}
    # Cleanup and delete rook-ceph namespace (required to delete dedicated node pool)
    if [ "${TF_VAR_enable_rook_ceph}" == "true" ]
    then
      echo "Cleanup and delete rook-ceph namespace"
      run_kubeconfig
      kubectl config set-context --current --namespace=rook-ceph
      kubectl patch cephblockpools.ceph.rook.io ceph-blockpool --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
      kubectl patch cephfilesystems.ceph.rook.io ceph-filesystem --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
      kubectl patch cephclusters.ceph.rook.io rook-ceph --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
      kubectl patch cephfilesystemsubvolumegroups.ceph.rook.io ceph-filesystem-csi --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
      kubectl patch cephobjectstores.ceph.rook.io ceph-objectstore --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
      kubectl delete cephblockpools.ceph.rook.io ceph-blockpool
      kubectl delete cephfilesystems.ceph.rook.io ceph-filesystem
      kubectl delete cephfilesystemsubvolumegroups.ceph.rook.io ceph-filesystem-csi
      kubectl delete cephobjectstores.ceph.rook.io ceph-objectstore
      kubectl delete cephclusters.ceph.rook.io rook-ceph
      kubectl delete all --all --force
      kubectl patch configmaps rook-ceph-mon-endpoints --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
      kubectl patch secrets rook-ceph-mon --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
      kubectl config set-context --current --namespace=default
      kubectl delete namespace rook-ceph
    else
      echo "Skipping rook-ceph cleanup"
    fi
    set -e
  fi
  TF_ROOT="terraform/${CLOUD}"
  TERRAFORM_STATE_NAME="${CLOUD}-${ENV}"
  PLANFILE=".terraform/cluster-${CLOUD}-${ENV}.tfplan"
  cd_to_tf_root
  vpn down
  tf_init
  # shellcheck disable=SC2086
  terraform plan -destroy -out=${PLANFILE}
  # shellcheck disable=SC2086
  terraform apply -input=false ${PLANFILE}
  echo ""
  # remove kubeconfig entry only if running outside container
  if [ ! -f /.dockerenv ]; then
    kubectl config get-contexts | grep "$TF_VAR_cluster_name" | awk '{ print $2}' | xargs kubectl config delete-context
  fi
  echo ""
  cd ../
  delete_uploaded_artifacts
else
  cd_to_tf_root
  # shellcheck disable=SC2086
  terraform $TF_OPERATION $TF_ARGS "${@: 3}"
fi
