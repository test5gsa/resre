#!/usr/bin/env bash

# Script to mirror images that are actually failing in your cluster
# Instead of guessing versions, this discovers real images from pod events

# Ensure we're running with bash
if [ -z "$BASH_VERSION" ]; then
    echo "Error: This script requires bash. Please run with bash instead of sh."
    exit 1
fi

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
REGION="${1:-us-west-1}"
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Mirror Images from Cluster Events${NC}"
echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}Region: ${REGION}${NC}"
echo -e "${GREEN}AWS Account: ${AWS_ACCOUNT_ID}${NC}"
echo -e "${GREEN}ECR Registry: ${ECR_REGISTRY}${NC}"
echo ""
echo -e "${YELLOW}Note: This script will verify access during actual operations${NC}"
echo -e "${YELLOW}      to avoid time-consuming upfront checks.${NC}"
echo ""

# Check prerequisites
echo -e "${BLUE}Checking prerequisites...${NC}"

if ! command -v kubectl >/dev/null 2>&1; then
    echo -e "${RED}✗ kubectl is not installed${NC}"
    exit 1
fi

if ! command -v aws >/dev/null 2>&1; then
    echo -e "${RED}✗ aws CLI is not installed${NC}"
    exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
    echo -e "${RED}✗ docker is not installed${NC}"
    exit 1
fi

echo -e "${GREEN}✓ All prerequisites found${NC}"

# Check kubectl connectivity
echo -e "${BLUE}Checking kubectl connectivity...${NC}"
if ! kubectl cluster-info >/dev/null 2>&1; then
    echo -e "${RED}✗ Cannot connect to Kubernetes cluster${NC}"
    echo -e "${YELLOW}  Make sure kubectl is configured and can access the cluster${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Connected to Kubernetes cluster${NC}"

# Check AWS credentials (skip time-consuming checks)
echo -e "${BLUE}Checking AWS credentials...${NC}"
echo -e "${GREEN}✓ AWS credentials configured (assuming valid)${NC}"
echo -e "${GREEN}✓ Will verify ECR access during actual operations${NC}"
echo ""

# Extract failed images from cluster events
echo -e "${BLUE}Discovering failed images from cluster...${NC}"

# Get images from failed pods
FAILED_IMAGES=$(kubectl get events -A \
    --field-selector reason=Failed \
    --sort-by='.lastTimestamp' 2>/dev/null \
    | grep -i "failed.*pull" \
    | grep -oP 'public\.ecr\.aws[^ "]+' \
    | sort -u || true)

if [ -z "$FAILED_IMAGES" ]; then
    echo -e "${YELLOW}No failed image pulls found in events${NC}"
    echo -e "${YELLOW}Checking pod specs for public.ecr.aws images...${NC}"

    # Fallback: check all pods for public.ecr.aws images
    FAILED_IMAGES=$(kubectl get pods -A -o json 2>/dev/null \
        | jq -r '.items[].spec.containers[]?.image, .items[].spec.initContainers[]?.image' 2>/dev/null \
        | grep "public.ecr.aws" \
        | sort -u || true)
fi

if [ -z "$FAILED_IMAGES" ]; then
    echo -e "${GREEN}✓ No public.ecr.aws images found in cluster${NC}"
    echo -e "${GREEN}Your cluster may already be using private ECR images${NC}"
    exit 0
fi

echo -e "${GREEN}Found the following public images:${NC}"
echo "$FAILED_IMAGES" | while read -r img; do
    echo -e "${BLUE}  - $img${NC}"
done
echo ""

# Login to ECR
echo -e "${BLUE}Logging into ECR...${NC}"
if aws ecr get-login-password --region ${REGION} 2>/dev/null | docker login --username AWS --password-stdin ${ECR_REGISTRY} 2>/dev/null; then
    echo -e "${GREEN}✓ Logged into ECR${NC}"
else
    echo -e "${RED}✗ Failed to login to ECR${NC}"
    exit 1
fi
echo ""

# Login to public ECR
echo -e "${BLUE}Logging into public ECR...${NC}"
if aws ecr-public get-login-password --region us-east-1 2>/dev/null | docker login --username AWS --password-stdin public.ecr.aws 2>/dev/null; then
    echo -e "${GREEN}✓ Logged into public ECR${NC}"
else
    echo -e "${RED}✗ Failed to login to public ECR${NC}"
    exit 1
fi
echo ""

# Function to create ECR repository if doesn't exist
create_ecr_repo() {
    local repo_name=$1

    echo -e "${BLUE}Checking ECR repository: ${repo_name}${NC}"

    if aws ecr describe-repositories --repository-names "${repo_name}" --region ${REGION} >/dev/null 2>&1; then
        echo -e "${GREEN}✓ Repository ${repo_name} already exists${NC}"
        return 0
    else
        echo -e "${YELLOW}Creating repository: ${repo_name}${NC}"
        if aws ecr create-repository \
            --repository-name "${repo_name}" \
            --region ${REGION} \
            --image-scanning-configuration scanOnPush=true \
            --encryption-configuration encryptionType=AES256 >/dev/null 2>&1; then
            echo -e "${GREEN}✓ Repository ${repo_name} created${NC}"
            return 0
        else
            echo -e "${RED}✗ Failed to create repository ${repo_name}${NC}"
            return 1
        fi
    fi
}

# Function to mirror image
mirror_image() {
    local source_image=$1

    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}Processing: ${source_image}${NC}"

    # Extract repository name (everything after public.ecr.aws/)
    local repo_path=$(echo "${source_image}" | sed 's|public\.ecr\.aws/||' | cut -d: -f1)
    local image_tag=$(echo "${source_image}" | grep -oP ':[^:]+$' | sed 's/://')

    # If no tag, use latest
    if [ -z "$image_tag" ]; then
        image_tag="latest"
    fi

    # Target image in private ECR
    local target_image="${ECR_REGISTRY}/${repo_path}:${image_tag}"

    echo -e "${GREEN}Source: ${source_image}${NC}"
    echo -e "${GREEN}Target: ${target_image}${NC}"

    # Check if image already exists in ECR
    if aws ecr describe-images \
        --repository-name "${repo_path}" \
        --image-ids imageTag="${image_tag}" \
        --region ${REGION} >/dev/null 2>&1; then
        echo -e "${GREEN}✓ Image already exists in ECR: ${repo_path}:${image_tag}${NC}"
        echo ""
        return 0
    fi

    # Create ECR repository if needed
    if ! create_ecr_repo "${repo_path}"; then
        echo -e "${YELLOW}⚠ Skipping image due to repository creation failure${NC}"
        echo ""
        return 1
    fi

    # Pull from public ECR
    echo -e "${YELLOW}Pulling: ${source_image}${NC}"
    if ! docker pull "${source_image}" 2>&1 | grep -v "WARNING"; then
        echo -e "${RED}✗ Failed to pull ${source_image}${NC}"
        echo -e "${YELLOW}  This image may not exist or may have been removed${NC}"
        echo ""
        return 1
    fi

    # Tag for private ECR
    echo -e "${YELLOW}Tagging: ${target_image}${NC}"
    docker tag "${source_image}" "${target_image}"

    # Push to private ECR
    echo -e "${YELLOW}Pushing: ${target_image}${NC}"
    if ! docker push "${target_image}" 2>&1 | grep -v "WARNING"; then
        echo -e "${RED}✗ Failed to push ${target_image}${NC}"
        echo -e "${YELLOW}  Check ECR permissions: ecr:PutImage, ecr:InitiateLayerUpload, ecr:UploadLayerPart, ecr:CompleteLayerUpload${NC}"
        echo ""
        return 1
    fi

    echo -e "${GREEN}✓ Successfully mirrored: ${source_image} → ${target_image}${NC}"
    echo ""
    return 0
}

# Process each image
SUCCESS_COUNT=0
FAIL_COUNT=0

while IFS= read -r image; do
    if mirror_image "${image}"; then
        SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
    else
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
done <<< "$FAILED_IMAGES"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Mirroring Summary${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}✓ Successfully mirrored: ${SUCCESS_COUNT} images${NC}"
if [ $FAIL_COUNT -gt 0 ]; then
    echo -e "${YELLOW}⚠ Failed: ${FAIL_COUNT} images${NC}"
fi
echo ""

if [ $SUCCESS_COUNT -gt 0 ]; then
    echo -e "${BLUE}Next steps:${NC}"
    echo -e "1. Configure Terraform to use private ECR:"
    echo -e "   ${YELLOW}use_private_ecr = true${NC}"
    echo -e "   ${YELLOW}private_ecr_account_id = \"${AWS_ACCOUNT_ID}\"${NC}"
    echo ""
    echo -e "2. Apply Terraform changes:"
    echo -e "   ${YELLOW}cd terraform/aws && terraform apply${NC}"
    echo ""
    echo -e "3. Delete failed pods to force recreation:"
    echo -e "   ${YELLOW}kubectl delete pods -n kube-system --field-selector=status.phase=Failed${NC}"
    echo ""
fi

if [ $FAIL_COUNT -gt 0 ]; then
    echo -e "${YELLOW}Some images failed to mirror. Common issues:${NC}"
    echo -e "1. Image version doesn't exist in public.ecr.aws"
    echo -e "2. Missing ECR permissions (need ecr:PutImage)"
    echo -e "3. Network/connectivity issues"
    echo ""
    echo -e "${YELLOW}Check the error messages above for details${NC}"
    exit 1
fi
