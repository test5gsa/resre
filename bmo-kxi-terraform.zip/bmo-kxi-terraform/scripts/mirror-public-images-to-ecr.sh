#!/usr/bin/env bash

# Script to mirror public ECR images to private ECR
# This solves the issue where EKS nodes in private subnets cannot access public.ecr.aws
#
# IMPORTANT: Run this BEFORE creating the cluster!
# This script does NOT require kubectl or cluster access.

# Ensure we're running with bash
if [ -z "$BASH_VERSION" ]; then
    echo "Error: This script requires bash. Please run with bash instead of sh."
    exit 1
fi

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
REGION="${1:-us-west-1}"
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Mirror Public Images to Private ECR${NC}"
echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}Region: ${REGION}${NC}"
echo -e "${GREEN}AWS Account: ${AWS_ACCOUNT_ID}${NC}"
echo -e "${GREEN}ECR Registry: ${ECR_REGISTRY}${NC}"
echo ""

# Helm chart versions - matching deployed versions
declare -A CHART_VERSIONS=(
    ["aws-ebs-csi-driver"]="2.41.0"
    ["aws-efs-csi-driver"]="3.1.7"
    ["aws-load-balancer-controller"]="1.11.1"
    ["metrics-server"]="3.12.2"
    ["cluster-autoscaler"]="46.3"
    ["cert-manager"]="1.17.2"
    ["ingress-nginx"]="11.5"
)

# Function to create ECR repository if doesn't exist
create_ecr_repo() {
    local repo_name=$1

    echo -e "${BLUE}Checking ECR repository: ${repo_name}${NC}"

    if aws ecr describe-repositories --repository-names "${repo_name}" --region ${REGION} >/dev/null 2>&1; then
        echo -e "${GREEN}✓ Repository ${repo_name} already exists${NC}"
    else
        echo -e "${YELLOW}Creating repository: ${repo_name}${NC}"
        aws ecr create-repository \
            --repository-name "${repo_name}" \
            --region ${REGION} \
            --image-scanning-configuration scanOnPush=true \
            --encryption-configuration encryptionType=AES256 >/dev/null
        echo -e "${GREEN}✓ Repository ${repo_name} created${NC}"
    fi
}

# Function to mirror image
mirror_image() {
    local source_image=$1

    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}Processing: ${source_image}${NC}"

    # Remove digest (@sha256:...) if present for tag extraction
    local source_without_digest=$(echo "${source_image}" | cut -d@ -f1)

    # Extract repository and tag
    local repo_path=""
    local image_tag=""

    if [[ "${source_image}" == public.ecr.aws/* ]]; then
        # public.ecr.aws images
        repo_path=$(echo "${source_without_digest}" | sed 's|public\.ecr\.aws/||' | cut -d: -f1)
        image_tag=$(echo "${source_without_digest}" | grep -oP ':[^:]+$' | sed 's/://' || echo "latest")
    elif [[ "${source_image}" == *.dkr.ecr.*.amazonaws.com/* ]]; then
        # AWS ECR images (e.g., 602401143452.dkr.ecr.us-west-1.amazonaws.com/eks/aws-efs-csi-driver)
        repo_path=$(echo "${source_without_digest}" | sed -E 's|[0-9]+\.dkr\.ecr\.[^.]+\.amazonaws\.com/||' | cut -d: -f1)
        image_tag=$(echo "${source_without_digest}" | grep -oP ':[^:]+$' | sed 's/://' || echo "latest")
    elif [[ "${source_image}" == registry.k8s.io/* ]]; then
        # registry.k8s.io images -> mirror as kubernetes/*
        repo_path="kubernetes/$(echo "${source_without_digest}" | sed 's|registry\.k8s\.io/||' | cut -d: -f1)"
        image_tag=$(echo "${source_without_digest}" | grep -oP ':[^:]+$' | sed 's/://' || echo "latest")
    elif [[ "${source_image}" == quay.io/* ]]; then
        # quay.io images
        repo_path=$(echo "${source_without_digest}" | sed 's|quay\.io/||' | cut -d: -f1)
        image_tag=$(echo "${source_without_digest}" | grep -oP ':[^:]+$' | sed 's/://' || echo "latest")
    elif [[ "${source_image}" == docker.io/* ]]; then
        # docker.io images
        repo_path=$(echo "${source_without_digest}" | sed 's|docker\.io/||' | cut -d: -f1)
        image_tag=$(echo "${source_without_digest}" | grep -oP ':[^:]+$' | sed 's/://' || echo "latest")
    else
        echo -e "${RED}✗ Unknown registry for: ${source_image}${NC}"
        return 1
    fi

    # If no tag, use latest
    if [ -z "$image_tag" ]; then
        image_tag="latest"
    fi

    # Target image in private ECR
    local target_image="${ECR_REGISTRY}/${repo_path}:${image_tag}"

    echo -e "${GREEN}Source: ${source_image}${NC}"
    echo -e "${GREEN}Target: ${target_image}${NC}"

    # Check if image already exists in ECR
    if aws ecr describe-images \
        --repository-name "${repo_path}" \
        --image-ids imageTag="${image_tag}" \
        --region ${REGION} >/dev/null 2>&1; then
        echo -e "${GREEN}✓ Image already exists in ECR: ${repo_path}:${image_tag}${NC}"
        echo ""
        return 0
    fi

    # Create ECR repository if needed
    create_ecr_repo "${repo_path}"

    # Pull from source registry
    echo -e "${YELLOW}Pulling: ${source_image}${NC}"
    if ! docker pull "${source_image}" 2>&1 | grep -v "WARNING"; then
        echo -e "${RED}✗ Failed to pull ${source_image}${NC}"
        echo ""
        return 1
    fi

    # Tag for private ECR
    echo -e "${YELLOW}Tagging: ${target_image}${NC}"
    docker tag "${source_image}" "${target_image}"

    # Push to private ECR
    echo -e "${YELLOW}Pushing: ${target_image}${NC}"
    if ! docker push "${target_image}" 2>&1 | grep -v "WARNING"; then
        echo -e "${RED}✗ Failed to push ${target_image}${NC}"
        echo ""
        return 1
    fi

    echo -e "${GREEN}✓ Successfully mirrored: ${source_image} → ${target_image}${NC}"
    echo ""
    return 0
}

# Check prerequisites
echo -e "${BLUE}Checking prerequisites...${NC}"

if ! command -v aws >/dev/null 2>&1; then
    echo -e "${RED}✗ aws CLI is not installed${NC}"
    echo -e "${YELLOW}Install: https://aws.amazon.com/cli/${NC}"
    exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
    echo -e "${RED}✗ docker is not installed${NC}"
    echo -e "${YELLOW}Install: https://docs.docker.com/get-docker/${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Prerequisites found${NC}"
echo ""

# Login to private ECR (for pushing)
echo -e "${BLUE}Logging into private ECR...${NC}"
if aws ecr get-login-password --region ${REGION} 2>/dev/null | docker login --username AWS --password-stdin ${ECR_REGISTRY} 2>/dev/null; then
    echo -e "${GREEN}✓ Logged into private ECR${NC}"
else
    echo -e "${RED}✗ Failed to login to private ECR${NC}"
    exit 1
fi
echo ""

# Login to public ECR (for pulling public.ecr.aws images)
echo -e "${BLUE}Logging into public ECR...${NC}"
if aws ecr-public get-login-password --region us-east-1 2>/dev/null | docker login --username AWS --password-stdin public.ecr.aws 2>/dev/null; then
    echo -e "${GREEN}✓ Logged into public ECR${NC}"
else
    echo -e "${YELLOW}⚠ Failed to login to public ECR (may not be needed if no public.ecr.aws images)${NC}"
fi
echo ""

# Login to AWS ECR for EKS images (account 602401143452)
echo -e "${BLUE}Logging into AWS ECR for EKS images (602401143452)...${NC}"
AWS_EKS_ECR_REGISTRY="602401143452.dkr.ecr.${REGION}.amazonaws.com"
if aws ecr get-login-password --region ${REGION} 2>/dev/null | docker login --username AWS --password-stdin ${AWS_EKS_ECR_REGISTRY} 2>/dev/null; then
    echo -e "${GREEN}✓ Logged into AWS EKS ECR${NC}"
else
    echo -e "${YELLOW}⚠ Failed to login to AWS EKS ECR (may not have access to 602401143452)${NC}"
fi
echo ""

echo -e "${YELLOW}Note: No authentication needed for registry.k8s.io, quay.io, and docker.io (public registries)${NC}"
echo ""

# Hardcoded images from helm charts (matching deployed versions)
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Preparing Images for Mirroring${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Images from public.ecr.aws and AWS ECR
# CSI Components now at: public.ecr.aws/csi-components (eks-distro/kubernetes-csi is deprecated)
PUBLIC_ECR_IMAGES=(
    # EBS CSI Driver v2.45.1 (app version v1.45.0) - matching terraform version
    "public.ecr.aws/ebs-csi-driver/aws-ebs-csi-driver:v1.45.0"
    "public.ecr.aws/csi-components/csi-node-driver-registrar:v2.14.0-eksbuild.3"
    "public.ecr.aws/csi-components/livenessprobe:v2.16.0-eksbuild.3"
    "public.ecr.aws/csi-components/csi-provisioner:v5.3.0-eksbuild.2"
    "public.ecr.aws/csi-components/csi-attacher:v4.9.0-eksbuild.2"
    "public.ecr.aws/csi-components/csi-resizer:v1.14.0-eksbuild.2"
    "public.ecr.aws/csi-components/csi-snapshotter:v8.3.0-eksbuild.2"

    # EFS CSI Driver v3.2.0 (app version 2.1.9) - from AWS ECR - matching terraform version
    # Note: Using same versions as EBS CSI that work
    "602401143452.dkr.ecr.us-west-1.amazonaws.com/eks/aws-efs-csi-driver:v2.1.9"
    "public.ecr.aws/csi-components/livenessprobe:v2.16.0-eksbuild.3"
    "public.ecr.aws/csi-components/csi-node-driver-registrar:v2.14.0-eksbuild.3"
    "public.ecr.aws/csi-components/csi-provisioner:v5.3.0-eksbuild.2"

    # AWS Load Balancer Controller v1.13.3 (app version v2.11.0) - matching terraform version
    "public.ecr.aws/eks/aws-load-balancer-controller:v2.11.0"

    # Metrics Server v3.12.2 - matching terraform version
    "public.ecr.aws/eks-distro/kubernetes-sigs/metrics-server:v0.7.2-eks-1-32-1"

    # EKS Managed Addons
    # CoreDNS
    "public.ecr.aws/eks-distro/coredns/coredns:v1.12.2-eks-1-34-8"
)

# Images from OTHER registries (registry.k8s.io, quay.io, docker.io, etc.)
OTHER_REGISTRY_IMAGES=(
    # Cluster Autoscaler v9.48.0 (matching terraform version)
    # Note: cluster-autoscaler comes from registry.k8s.io, NOT eks-distro
    # Helm chart 9.48.0 uses v1.33.0 by default
    "registry.k8s.io/autoscaling/cluster-autoscaler:v1.33.0"

    # Ingress NGINX v4.11.5 (matching terraform version)
    "registry.k8s.io/ingress-nginx/controller:v1.11.5"
    "registry.k8s.io/ingress-nginx/kube-webhook-certgen:v1.5.2"
    "registry.k8s.io/ingress-nginx/opentelemetry:v20230721-3e2062ee5"

    # Cert Manager v1.18.2 (matching terraform version)
    "quay.io/jetstack/cert-manager-controller:v1.18.2"
    "quay.io/jetstack/cert-manager-webhook:v1.18.2"
    "quay.io/jetstack/cert-manager-cainjector:v1.18.2"
    "quay.io/jetstack/cert-manager-acmesolver:v1.18.2"
    "quay.io/jetstack/cert-manager-startupapicheck:v1.18.2"

    # Rook Ceph v1.17.6 (from docker.io and quay.io)
    "docker.io/rook/ceph:v1.17.6"
    "quay.io/ceph/ceph:v19.2.0"

    # Rook Ceph CSI drivers (from quay.io and registry.k8s.io)
    "quay.io/cephcsi/cephcsi:v3.14.1"
    "registry.k8s.io/sig-storage/csi-node-driver-registrar:v2.13.0"
    "registry.k8s.io/sig-storage/csi-attacher:v4.8.1"
    "registry.k8s.io/sig-storage/csi-provisioner:v5.2.0"
    "registry.k8s.io/sig-storage/csi-resizer:v1.13.2"
    "registry.k8s.io/sig-storage/csi-snapshotter:v8.2.1"
)

# Combine all images
KNOWN_IMAGES=("${PUBLIC_ECR_IMAGES[@]}" "${OTHER_REGISTRY_IMAGES[@]}")

echo -e "${BLUE}Total images to mirror: ${#KNOWN_IMAGES[@]}${NC}"
echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Mirroring Images to Private ECR${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

SUCCESS_COUNT=0
FAIL_COUNT=0

for image in "${KNOWN_IMAGES[@]}"; do
    if mirror_image "${image}"; then
        SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
    else
        echo -e "${YELLOW}⚠ Skipping failed image${NC}"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
done

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Mirroring Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${GREEN}Successfully mirrored: ${SUCCESS_COUNT} images${NC}"
if [ $FAIL_COUNT -gt 0 ]; then
    echo -e "${YELLOW}Failed: ${FAIL_COUNT} images${NC}"
fi
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo -e "1. Configure Terraform to use private ECR:"
echo -e "   ${YELLOW}use_private_ecr = true${NC}"
echo -e "   ${YELLOW}private_ecr_account_id = \"${AWS_ACCOUNT_ID}\"${NC}"
echo ""
echo -e "2. Now you can safely run: ${YELLOW}./deploy-cluster.sh${NC}"
echo ""
echo -e "3. If you need to mirror additional images after cluster is created:"
echo -e "   ${YELLOW}./scripts/mirror-images-from-cluster.sh${NC}"
echo ""

if [ $FAIL_COUNT -gt 0 ]; then
    echo -e "${YELLOW}Some images failed to mirror. This may be due to:${NC}"
    echo -e "1. Image version doesn't exist in public.ecr.aws"
    echo -e "2. Network/connectivity issues"
    echo -e "3. The images may work anyway - EKS can use alternative versions"
    echo ""
    exit 1
fi
