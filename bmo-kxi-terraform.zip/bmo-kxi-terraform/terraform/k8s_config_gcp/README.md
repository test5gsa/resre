# k8s_config_gcp

This module includes all kubernetes configuration that must be applied once the GKE cluster is created on GCP.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | 1.5.5 |
| <a name="requirement_google"></a> [google](#requirement\_google) | 6.41.0 |
| <a name="requirement_google-beta"></a> [google-beta](#requirement\_google-beta) | 6.41.0 |
| <a name="requirement_helm"></a> [helm](#requirement\_helm) | 2.17.0 |
| <a name="requirement_kubectl"></a> [kubectl](#requirement\_kubectl) | 2.1.3 |
| <a name="requirement_kubernetes"></a> [kubernetes](#requirement\_kubernetes) | 2.37.1 |
| <a name="requirement_time"></a> [time](#requirement\_time) | 0.13.1 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 6.41.0 |
| <a name="provider_helm"></a> [helm](#provider\_helm) | 2.17.0 |
| <a name="provider_kubectl"></a> [kubectl](#provider\_kubectl) | 2.1.3 |
| <a name="provider_kubernetes"></a> [kubernetes](#provider\_kubernetes) | 2.37.1 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_rook-ceph-helm"></a> [rook-ceph-helm](#module\_rook-ceph-helm) | ../modules/rook-ceph-helm | n/a |

## Resources

| Name | Type |
|------|------|
| [google_project_iam_member.logging_gcp_service_account_permissions](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/project_iam_member) | resource |
| [google_service_account.logging_gcp_service_account](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/service_account) | resource |
| [google_service_account_iam_member.logging_workload_identity](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/service_account_iam_member) | resource |
| [helm_release.cert-manager](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.ingress-nginx](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.prometheus-operator-crds](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [kubectl_manifest.clusterissuer](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_fluent_bit_cluster_role](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_fluent_bit_cluster_role_binding](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_fluent_bit_configmap](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_fluent_bit_daemonset](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_fluent_bit_service_account](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_namespace](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubernetes_storage_class.gcp_storage_class](https://registry.terraform.io/providers/hashicorp/kubernetes/2.37.1/docs/resources/storage_class) | resource |
| [kubernetes_storage_class.sharedfiles_filestore_storage_class](https://registry.terraform.io/providers/hashicorp/kubernetes/2.37.1/docs/resources/storage_class) | resource |
| [google_client_config.default](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/data-sources/client_config) | data source |
| [google_container_cluster.default](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/data-sources/container_cluster) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_architecture_profile"></a> [architecture\_profile](#input\_architecture\_profile) | The architecture profile used | `string` | n/a | yes |
| <a name="input_cert_manager_helm_version"></a> [cert\_manager\_helm\_version](#input\_cert\_manager\_helm\_version) | cert-manager Helm chart version to deploy, see https://artifacthub.io/packages/helm/cert-manager/cert-manager for more info | `string` | `"1.18.2"` | no |
| <a name="input_cloud"></a> [cloud](#input\_cloud) | Name of cloud provider | `string` | n/a | yes |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | Name of the cluster | `string` | n/a | yes |
| <a name="input_enable_cert_manager"></a> [enable\_cert\_manager](#input\_enable\_cert\_manager) | Deploy cert-manager Helm chart | `bool` | `true` | no |
| <a name="input_enable_ingress_nginx"></a> [enable\_ingress\_nginx](#input\_enable\_ingress\_nginx) | Deployment of community nginx ingress helm chart | `bool` | `true` | no |
| <a name="input_enable_logging"></a> [enable\_logging](#input\_enable\_logging) | Whether to enable logging or not | `bool` | `false` | no |
| <a name="input_enable_rook_ceph"></a> [enable\_rook\_ceph](#input\_enable\_rook\_ceph) | Whether to enable Rook Ceph or not | `bool` | `true` | no |
| <a name="input_enable_rook_ceph_node_pool"></a> [enable\_rook\_ceph\_node\_pool](#input\_enable\_rook\_ceph\_node\_pool) | Whether to create the rook-ceph node pool or not | `bool` | `false` | no |
| <a name="input_enable_sharedfiles_storage_class"></a> [enable\_sharedfiles\_storage\_class](#input\_enable\_sharedfiles\_storage\_class) | Whether to create the sharedfiles storage class or not | `bool` | `true` | no |
| <a name="input_gcp_project"></a> [gcp\_project](#input\_gcp\_project) | GCP project for this cluster when deploying to GCP cloud | `string` | `""` | no |
| <a name="input_ingress_nginx_helm_version"></a> [ingress\_nginx\_helm\_version](#input\_ingress\_nginx\_helm\_version) | ingress-nginx  Helm chart version to deploy, see https://artifacthub.io/packages/helm/ingress-nginx/ingress-nginx for more info | `string` | `"4.11.5"` | no |
| <a name="input_ingress_nginx_resources_limit_memory"></a> [ingress\_nginx\_resources\_limit\_memory](#input\_ingress\_nginx\_resources\_limit\_memory) | ingress nginx memory limit | `string` | `"512Mi"` | no |
| <a name="input_ingress_nginx_resources_request_cpu"></a> [ingress\_nginx\_resources\_request\_cpu](#input\_ingress\_nginx\_resources\_request\_cpu) | ingress nginx CPU request | `string` | `"100m"` | no |
| <a name="input_ingress_nginx_resources_request_memory"></a> [ingress\_nginx\_resources\_request\_memory](#input\_ingress\_nginx\_resources\_request\_memory) | ingress nginx memory request | `string` | `"256Mi"` | no |
| <a name="input_letsencrypt_account"></a> [letsencrypt\_account](#input\_letsencrypt\_account) | Email address to associate with the LetsEncrypt issuer | `string` | n/a | yes |
| <a name="input_letsencrypt_enable_http_validation"></a> [letsencrypt\_enable\_http\_validation](#input\_letsencrypt\_enable\_http\_validation) | Whether to enable cluster issuer for http validation or not | `bool` | `false` | no |
| <a name="input_prometheus_operator_crds_helm_version"></a> [prometheus\_operator\_crds\_helm\_version](#input\_prometheus\_operator\_crds\_helm\_version) | prometheus-operator-crds helm chart version to deploy | `string` | `"5.0.0"` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `string` | `""` | no |
| <a name="input_regional"></a> [regional](#input\_regional) | # GCP specific configuration # When cluster is not regional you need to provide zones list, when cluster is regional then zones list is optional, but region parameter is required. | `bool` | `false` | no |
| <a name="input_rook_ceph_mds_resources_memory_limit"></a> [rook\_ceph\_mds\_resources\_memory\_limit](#input\_rook\_ceph\_mds\_resources\_memory\_limit) | Setting resource limit of MDS | `string` | `"8Gi"` | no |
| <a name="input_rook_ceph_storage_size"></a> [rook\_ceph\_storage\_size](#input\_rook\_ceph\_storage\_size) | Cloud storage size to use for Ceph. Only applies when cloud storage is used | `string` | `"100Gi"` | no |
| <a name="input_rook_ceph_storage_type"></a> [rook\_ceph\_storage\_type](#input\_rook\_ceph\_storage\_type) | The storage type used by rook-ceph. Should match existing StorageClass defined in Kubernetes. Set to local for local storage | `string` | `"standard-rwo"` | no |
| <a name="input_zones"></a> [zones](#input\_zones) | n/a | `list(string)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_installing_insights"></a> [installing\_insights](#output\_installing\_insights) | n/a |
<!-- END_TF_DOCS -->
