Deploy private EKS cluster on AWS and a bastion host for management.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | 1.5.5 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | 5.100.0 |
| <a name="requirement_kubernetes"></a> [kubernetes](#requirement\_kubernetes) | 2.37.1 |

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_kx-aws"></a> [kx-aws](#module\_kx-aws) | ../modules/k8s_cluster_aws | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bastion_host_sg_id"></a> [bastion\_host\_sg\_id](#input\_bastion\_host\_sg\_id) | ID of the bastion security group ID | `string` | `""` | no |
| <a name="input_bastion_instance_type"></a> [bastion\_instance\_type](#input\_bastion\_instance\_type) | Type of node to use for the bastion host. See https://aws.amazon.com/ec2/instance-types for more information. | `string` | `"t3.small"` | no |
| <a name="input_bastion_whitelist_ips"></a> [bastion\_whitelist\_ips](#input\_bastion\_whitelist\_ips) | List of IPs to be whitelisted on the Bastion Host | `list(any)` | `[]` | no |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | Name of the cluster and prefix for associated resources. | `string` | n/a | yes |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Default version for the EKS cluster | `string` | `"1.32"` | no |
| <a name="input_default_node_type"></a> [default\_node\_type](#input\_default\_node\_type) | Type of node to use for the cluster. See https://aws.amazon.com/ec2/instance-types for more information. | `string` | `"t3.xlarge"` | no |
| <a name="input_default_tags"></a> [default\_tags](#input\_default\_tags) | Tags which will be assigned to resources which are created. | `map(string)` | `{}` | no |
| <a name="input_desired_node_count"></a> [desired\_node\_count](#input\_desired\_node\_count) | Desired number of nodes in the cluster | `number` | `3` | no |
| <a name="input_enable_rook_ceph_node_pool"></a> [enable\_rook\_ceph\_node\_pool](#input\_enable\_rook\_ceph\_node\_pool) | Whether to create the rook-ceph node pool or not | `bool` | `false` | no |
| <a name="input_existing_vpc"></a> [existing\_vpc](#input\_existing\_vpc) | Set to true if deploying to existing vpc | `bool` | `false` | no |
| <a name="input_insights_whitelist_ips"></a> [insights\_whitelist\_ips](#input\_insights\_whitelist\_ips) | List of IP ranges in CIDR notation to allow access to insights | `list(string)` | `[]` | no |
| <a name="input_letsencrypt_enable_http_validation"></a> [letsencrypt\_enable\_http\_validation](#input\_letsencrypt\_enable\_http\_validation) | Whether to enable cluster issuer for http validation or not | `bool` | `false` | no |
| <a name="input_max_node_count"></a> [max\_node\_count](#input\_max\_node\_count) | Maximum number of nodes in the cluster | `number` | `10` | no |
| <a name="input_min_node_count"></a> [min\_node\_count](#input\_min\_node\_count) | Minimum number of nodes in the cluster | `number` | `3` | no |
| <a name="input_private_subnets_ids"></a> [private\_subnets\_ids](#input\_private\_subnets\_ids) | List of private subnet IDs in the existing VPC | `list(string)` | `[]` | no |
| <a name="input_public_network_acl_id"></a> [public\_network\_acl\_id](#input\_public\_network\_acl\_id) | The public network ACL ID attached to public subnets | `string` | `""` | no |
| <a name="input_reduced_azs"></a> [reduced\_azs](#input\_reduced\_azs) | Set to true to only use 2 AZs and create 2 subnets for both public and private | `bool` | `false` | no |
| <a name="input_region"></a> [region](#input\_region) | AWS region for the cluster and associated resources. See https://aws.amazon.com/about-aws/global-infrastructure/regions_az/ for available regions. | `string` | n/a | yes |
| <a name="input_rook_ceph_pool_desired_node_count"></a> [rook\_ceph\_pool\_desired\_node\_count](#input\_rook\_ceph\_pool\_desired\_node\_count) | n/a | `number` | `3` | no |
| <a name="input_rook_ceph_pool_max_node_count"></a> [rook\_ceph\_pool\_max\_node\_count](#input\_rook\_ceph\_pool\_max\_node\_count) | n/a | `number` | `3` | no |
| <a name="input_rook_ceph_pool_min_node_count"></a> [rook\_ceph\_pool\_min\_node\_count](#input\_rook\_ceph\_pool\_min\_node\_count) | n/a | `number` | `3` | no |
| <a name="input_rook_ceph_pool_node_type"></a> [rook\_ceph\_pool\_node\_type](#input\_rook\_ceph\_pool\_node\_type) | n/a | `string` | `"c5d.2xlarge"` | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | ID of the existing VPC to use | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_bastion_ip"></a> [bastion\_ip](#output\_bastion\_ip) | Bastion Host Elastic IP Address |
| <a name="output_bastion_ssh_private_key"></a> [bastion\_ssh\_private\_key](#output\_bastion\_ssh\_private\_key) | Bastion Host SSH Private Key |
| <a name="output_bastion_username"></a> [bastion\_username](#output\_bastion\_username) | Bastion Host username |
| <a name="output_openvpn_instructions"></a> [openvpn\_instructions](#output\_openvpn\_instructions) | OpenVPN instructions |
<!-- END_TF_DOCS -->
