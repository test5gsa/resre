# k8s_cluster_gcp

Create a basic GKE cluster on GCP with private API endpoint and bastion host for management.

The overall architecture created by this module is as per the diagram below;

![Overview](docs/img/PrivateCluster.png)
<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | 1.5.5 |
| <a name="requirement_google"></a> [google](#requirement\_google) | 6.41.0 |
| <a name="requirement_google-beta"></a> [google-beta](#requirement\_google-beta) | 6.41.0 |
| <a name="requirement_kubernetes"></a> [kubernetes](#requirement\_kubernetes) | 2.37.1 |
| <a name="requirement_local"></a> [local](#requirement\_local) | 2.5.3 |
| <a name="requirement_null"></a> [null](#requirement\_null) | 3.2.4 |
| <a name="requirement_time"></a> [time](#requirement\_time) | 0.13.1 |
| <a name="requirement_tls"></a> [tls](#requirement\_tls) | 4.1.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 6.41.0 |
| <a name="provider_google-beta"></a> [google-beta](#provider\_google-beta) | 6.41.0 |
| <a name="provider_local"></a> [local](#provider\_local) | 2.5.3 |
| <a name="provider_null"></a> [null](#provider\_null) | 3.2.4 |
| <a name="provider_tls"></a> [tls](#provider\_tls) | 4.1.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_cloud_router_with_nat"></a> [cloud\_router\_with\_nat](#module\_cloud\_router\_with\_nat) | terraform-google-modules/cloud-router/google | 6.3.0 |
| <a name="module_gke"></a> [gke](#module\_gke) | terraform-google-modules/kubernetes-engine/google//modules/beta-private-cluster-update-variant | 35.0.1 |

## Resources

| Name | Type |
|------|------|
| [google_compute_address.bastion_host_static_external_ip](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/compute_address) | resource |
| [google_compute_address.bastion_host_static_internal_ip](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/compute_address) | resource |
| [google_compute_firewall.allow_http_letsencrypt](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/compute_firewall) | resource |
| [google_compute_firewall.bastion_host_firewall](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/compute_firewall) | resource |
| [google_compute_firewall.vpc_firewall_bastion](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/compute_firewall) | resource |
| [google_compute_firewall.vpc_firewall_insights](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/compute_firewall) | resource |
| [google_compute_instance.bastion_host](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/compute_instance) | resource |
| [google_compute_network.container_network](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/compute_network) | resource |
| [google_compute_subnetwork.container_subnetwork](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/compute_subnetwork) | resource |
| [google_container_node_pool.rook_ceph_node_pool](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/resources/container_node_pool) | resource |
| [local_file.bastion_ssh_private_key](https://registry.terraform.io/providers/hashicorp/local/2.5.3/docs/resources/file) | resource |
| [null_resource.openvpn_config](https://registry.terraform.io/providers/hashicorp/null/3.2.4/docs/resources/resource) | resource |
| [null_resource.openvpn_install](https://registry.terraform.io/providers/hashicorp/null/3.2.4/docs/resources/resource) | resource |
| [tls_private_key.bastion_host_ssh_key_pair](https://registry.terraform.io/providers/hashicorp/tls/4.1.0/docs/resources/private_key) | resource |
| [google-beta_google_container_engine_versions.gke_versions](https://registry.terraform.io/providers/hashicorp/google-beta/6.41.0/docs/data-sources/google_container_engine_versions) | data source |
| [google_client_config.default](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/data-sources/client_config) | data source |
| [google_compute_zones.available](https://registry.terraform.io/providers/hashicorp/google/6.41.0/docs/data-sources/compute_zones) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bastion_admin_user"></a> [bastion\_admin\_user](#input\_bastion\_admin\_user) | Default admin user to create on the bastion host. | `string` | `"admin"` | no |
| <a name="input_bastion_host_internal_ip"></a> [bastion\_host\_internal\_ip](#input\_bastion\_host\_internal\_ip) | The internal IP of the bastion host | `string` | `null` | no |
| <a name="input_bastion_instance_type"></a> [bastion\_instance\_type](#input\_bastion\_instance\_type) | Type of node to use for the bastion host. See https://cloud.google.com/compute/docs/machine-types for more information. | `string` | `"e2-medium"` | no |
| <a name="input_bastion_ssh_private_key_file"></a> [bastion\_ssh\_private\_key\_file](#input\_bastion\_ssh\_private\_key\_file) | Path to store the ssh private key for bastion host. | `string` | `"bastion_ssh_private_key.pem"` | no |
| <a name="input_bastion_whitelist_ips"></a> [bastion\_whitelist\_ips](#input\_bastion\_whitelist\_ips) | List of IPs to be whitelisted on the Bastion Host | `list(any)` | `[]` | no |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | Name of the cluster | `string` | n/a | yes |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Default version for the GKE cluster | `string` | `null` | no |
| <a name="input_default_labels"></a> [default\_labels](#input\_default\_labels) | Tags which will be assigned to resources which are created. | `map(string)` | `{}` | no |
| <a name="input_default_node_count"></a> [default\_node\_count](#input\_default\_node\_count) | Initial number of nodes running on the cluster | `number` | `1` | no |
| <a name="input_default_node_type"></a> [default\_node\_type](#input\_default\_node\_type) | Type of node to use for the cluster. See https://cloud.google.com/compute/docs/machine-types for more information. | `string` | `"n1-highmem-4"` | no |
| <a name="input_disk_size"></a> [disk\_size](#input\_disk\_size) | Size of disk to use for the cluster | `number` | `"100"` | no |
| <a name="input_disk_type"></a> [disk\_type](#input\_disk\_type) | Type of disk to use for the cluster. See https://cloud.google.com/compute/docs/disks for more information. | `string` | `"pd-standard"` | no |
| <a name="input_enable_filestore_csi_driver"></a> [enable\_filestore\_csi\_driver](#input\_enable\_filestore\_csi\_driver) | Whether to enable GCP Filestore CSI driver or not | `bool` | `true` | no |
| <a name="input_enable_metrics"></a> [enable\_metrics](#input\_enable\_metrics) | Whether to enable container metrics or not | `bool` | `false` | no |
| <a name="input_enable_rook_ceph_node_pool"></a> [enable\_rook\_ceph\_node\_pool](#input\_enable\_rook\_ceph\_node\_pool) | Whether to create the rook-ceph node pool or not | `bool` | `false` | no |
| <a name="input_existing_vpc"></a> [existing\_vpc](#input\_existing\_vpc) | Set to true if deploying to existing vpc | `bool` | `false` | no |
| <a name="input_image_type"></a> [image\_type](#input\_image\_type) | The image to use for worker nodes, cos or ubuntu | `string` | `"UBUNTU_CONTAINERD"` | no |
| <a name="input_insights_whitelist_ips"></a> [insights\_whitelist\_ips](#input\_insights\_whitelist\_ips) | List of IP ranges in CIDR notation to allow access to insights | `list(string)` | `[]` | no |
| <a name="input_letsencrypt_enable_http_validation"></a> [letsencrypt\_enable\_http\_validation](#input\_letsencrypt\_enable\_http\_validation) | Whether to enable cluster issuer for http validation or not | `bool` | `false` | no |
| <a name="input_logging_service"></a> [logging\_service](#input\_logging\_service) | The logging service that the cluster should write logs to. Available options include logging.googleapis.com, logging.googleapis.com/kubernetes (beta), and none | `string` | `"logging.googleapis.com/kubernetes"` | no |
| <a name="input_max_node_count"></a> [max\_node\_count](#input\_max\_node\_count) | Maximum number of nodes running on the cluster | `number` | `4` | no |
| <a name="input_min_node_count"></a> [min\_node\_count](#input\_min\_node\_count) | Minimum number of nodes running on the cluster | `number` | `1` | no |
| <a name="input_monitoring_service"></a> [monitoring\_service](#input\_monitoring\_service) | The monitoring service that the cluster should write metrics to. Available options include monitoring.googleapis.com, monitoring.googleapis.com/kubernetes (beta) and none | `string` | `"monitoring.googleapis.com/kubernetes"` | no |
| <a name="input_network_name"></a> [network\_name](#input\_network\_name) | GCP VPC Network Name | `string` | `null` | no |
| <a name="input_pods_range_name"></a> [pods\_range\_name](#input\_pods\_range\_name) | Pod range name for cluster | `string` | `null` | no |
| <a name="input_project"></a> [project](#input\_project) | The project ID to host the cluster in | `string` | n/a | yes |
| <a name="input_reduced_azs"></a> [reduced\_azs](#input\_reduced\_azs) | Set to true to only use 1 AZ | `bool` | `false` | no |
| <a name="input_region"></a> [region](#input\_region) | GCP region for the cluster and associated resources. See https://cloud.google.com/compute/docs/regions-zones for available regions. | `string` | `null` | no |
| <a name="input_rook_ceph_pool_max_count"></a> [rook\_ceph\_pool\_max\_count](#input\_rook\_ceph\_pool\_max\_count) | n/a | `number` | `3` | no |
| <a name="input_rook_ceph_pool_min_count"></a> [rook\_ceph\_pool\_min\_count](#input\_rook\_ceph\_pool\_min\_count) | n/a | `number` | `3` | no |
| <a name="input_rook_ceph_pool_node_type"></a> [rook\_ceph\_pool\_node\_type](#input\_rook\_ceph\_pool\_node\_type) | n/a | `string` | `"n2-standard-8"` | no |
| <a name="input_subnet_name"></a> [subnet\_name](#input\_subnet\_name) | Subnet name for cluster | `string` | `null` | no |
| <a name="input_svc_range_name"></a> [svc\_range\_name](#input\_svc\_range\_name) | IP Range Services for cluster | `string` | `null` | no |
| <a name="input_zones"></a> [zones](#input\_zones) | n/a | `list(string)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_bastion_ip"></a> [bastion\_ip](#output\_bastion\_ip) | Bastion Host External Static IP Address |
| <a name="output_bastion_ssh_private_key"></a> [bastion\_ssh\_private\_key](#output\_bastion\_ssh\_private\_key) | Bastion Host SSH Private Key |
| <a name="output_bastion_username"></a> [bastion\_username](#output\_bastion\_username) | Bastion Host username |
| <a name="output_openvpn_instructions"></a> [openvpn\_instructions](#output\_openvpn\_instructions) | OpenVPN instructions |
<!-- END_TF_DOCS -->
