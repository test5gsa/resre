Deploys rook-ceph with  [Rook Ceph Operator](https://rook.io/docs/rook/latest-release/Helm-Charts/operator-chart/)  and [Rook Ceph Cluster](https://rook.io/docs/rook/latest-release/Helm-Charts/ceph-cluster-chart/)  helm charts

enable this module by setting the below variable in kxi-terraform.env

```
TF_VAR_enable_rook_ceph_helm=true
```

the corresponding value files are in templates directory

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | 1.5.5 |
| <a name="requirement_helm"></a> [helm](#requirement\_helm) | 2.17.0 |
| <a name="requirement_kubectl"></a> [kubectl](#requirement\_kubectl) | 2.1.3 |
| <a name="requirement_kubernetes"></a> [kubernetes](#requirement\_kubernetes) | 2.37.1 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_helm"></a> [helm](#provider\_helm) | 2.17.0 |
| <a name="provider_kubectl"></a> [kubectl](#provider\_kubectl) | 2.1.3 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [helm_release.rook-ceph-cluster](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.rook_ceph](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [kubectl_manifest.ResourceQuota](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_architecture_profile"></a> [architecture\_profile](#input\_architecture\_profile) | The architecture profile used | `string` | n/a | yes |
| <a name="input_disable_exporters"></a> [disable\_exporters](#input\_disable\_exporters) | Whether to disable exporters | `bool` | `true` | no |
| <a name="input_disable_rbddriver"></a> [disable\_rbddriver](#input\_disable\_rbddriver) | Whether to disable RbdDriver | `bool` | `true` | no |
| <a name="input_enable_rook_ceph_node_pool"></a> [enable\_rook\_ceph\_node\_pool](#input\_enable\_rook\_ceph\_node\_pool) | Whether to deploy rook-ceph on a dedicated node pool or not | `bool` | `false` | no |
| <a name="input_rook_ceph_helm_version"></a> [rook\_ceph\_helm\_version](#input\_rook\_ceph\_helm\_version) | rook-ceph  Helm chart version to deploy, see https://github.com/rook/rook for more info | `string` | `"1.17.6"` | no |
| <a name="input_rook_ceph_mds_resources_memory_limit"></a> [rook\_ceph\_mds\_resources\_memory\_limit](#input\_rook\_ceph\_mds\_resources\_memory\_limit) | Setting resource limit of MDS | `string` | `"8Gi"` | no |
| <a name="input_rook_ceph_storage_size"></a> [rook\_ceph\_storage\_size](#input\_rook\_ceph\_storage\_size) | The storage size when using Cloud Storage | `string` | n/a | yes |
| <a name="input_rook_ceph_storage_type"></a> [rook\_ceph\_storage\_type](#input\_rook\_ceph\_storage\_type) | The storage type used by rook-ceph. Should match existing StorageClass defined in Kubernetes. | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->
