# Terraform Runner Module

## Overview

This module creates an EC2 instance in a private subnet that can run Terraform and access the private EKS cluster.

## Problem It Solves

When your EKS cluster has `endpointPublicAccess: false`, you cannot run Terraform or kubectl from your local machine. This module creates a "jump box" specifically for running infrastructure-as-code tools.

## Usage

```hcl
module "terraform_runner" {
  source = "../modules/terraform_runner"

  cluster_name = "aws-endpoint"
  vpc_id       = "vpc-08acd442308802d0f"
  subnet_id    = "subnet-06e8c7c3bd3c57310"  # Private subnet
  region       = "us-west-1"

  instance_type = "t3.medium"  # or t3.large for heavy workloads

  tags = {
    Environment = "production"
    Purpose     = "terraform-runner"
  }
}

output "terraform_runner_access" {
  value = module.terraform_runner.usage_instructions
}
```

## What Gets Created

- **EC2 Instance** (Amazon Linux 2) in private subnet
- **IAM Role** with permissions for:
  - EKS cluster access
  - SSM Session Manager
  - Administrator access (customize as needed)
- **Security Group** allowing all outbound traffic
- **Pre-installed tools**:
  - Terraform (latest)
  - kubectl (configured for your cluster)
  - AWS CLI v2
  - Helm
  - Git

## Access

```bash
# Get instance ID from Terraform output
terraform output terraform_runner_access

# Connect via SSM
aws ssm start-session --target i-xxxxx --region us-west-1

# Switch to ec2-user
sudo su - ec2-user

# Verify tools
terraform --version
kubectl get nodes
aws --version
helm version
```

## Using Terraform from Inside

### Method 1: Clone from Git

```bash
# Inside the instance
git clone https://github.com/your-org/terraform-config.git
cd terraform-config
terraform init
terraform plan
terraform apply
```

### Method 2: Copy from S3

```bash
# From your local machine
cd /path/to/terraform
tar czf terraform-config.tar.gz .
aws s3 cp terraform-config.tar.gz s3://your-bucket/

# Inside the instance
aws s3 cp s3://your-bucket/terraform-config.tar.gz .
tar xzf terraform-config.tar.gz
terraform init
terraform apply
```

### Method 3: Use AWS Systems Manager Session Manager Port Forwarding

```bash
# Forward local directory to remote instance
aws ssm start-session \
  --target i-xxxxx \
  --document-name AWS-StartPortForwardingSession \
  --parameters "portNumber=22,localPortNumber=2222"

# Then use scp
scp -P 2222 -r ./* ec2-user@localhost:/home/ec2-user/terraform/
```

## Cost

- **t3.medium**: ~$30/month (0.0416/hour × 730 hours)
- **t3.large**: ~$60/month (if you need more resources)
- **Data transfer**: Usually minimal

## Security Considerations

### Current Setup (Development)
- ✅ No public IP
- ✅ Access only via SSM
- ⚠️ Has AdministratorAccess (very permissive)

### Production Setup (Recommended)

Replace the `AdministratorAccess` policy with specific permissions:

```hcl
resource "aws_iam_role_policy" "terraform_runner_custom" {
  name = "${var.cluster_name}-terraform-runner-policy"
  role = aws_iam_role.terraform_runner.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "eks:*",
          "ec2:*",
          "iam:Get*",
          "iam:List*",
          # Add specific permissions needed
        ]
        Resource = "*"
      }
    ]
  })
}
```

## Alternative: GitHub Actions Self-Hosted Runner

For CI/CD workflows, you could also use this instance as a GitHub Actions self-hosted runner:

```bash
# Inside the instance
mkdir actions-runner && cd actions-runner
curl -o actions-runner-linux-x64-2.311.0.tar.gz -L https://github.com/actions/runner/releases/download/v2.311.0/actions-runner-linux-x64-2.311.0.tar.gz
tar xzf ./actions-runner-linux-x64-2.311.0.tar.gz
./config.sh --url https://github.com/your-org/your-repo --token YOUR_TOKEN
sudo ./svc.sh install
sudo ./svc.sh start
```

## Troubleshooting

### Can't connect via SSM

Check if SSM VPC Endpoints exist:
```bash
aws ec2 describe-vpc-endpoints \
  --filters "Name=vpc-id,Values=vpc-xxxxx" \
           "Name=service-name,Values=*ssm*" \
  --region us-west-1
```

You need:
- `com.amazonaws.us-west-1.ssm`
- `com.amazonaws.us-west-1.ssmmessages`
- `com.amazonaws.us-west-1.ec2messages`

### kubectl can't connect to cluster

```bash
# Re-configure kubectl
aws eks update-kubeconfig --name aws-endpoint --region us-west-1

# Test
kubectl get nodes
```

### Terraform state locking issues

Use S3 backend with DynamoDB:

```hcl
terraform {
  backend "s3" {
    bucket         = "your-terraform-state-bucket"
    key            = "eks/terraform.tfstate"
    region         = "us-west-1"
    dynamodb_table = "terraform-locks"
    encrypt        = true
  }
}
```

## Example: Complete Deployment Flow

```bash
# 1. Deploy Terraform Runner (from local machine with internet)
cd terraform
terraform apply -target=module.terraform_runner

# 2. Get instance ID
INSTANCE_ID=$(terraform output -raw terraform_runner_instance_id)

# 3. Connect
aws ssm start-session --target $INSTANCE_ID --region us-west-1

# 4. Inside the instance, clone your repo
sudo su - ec2-user
git clone https://github.com/your-org/terraform-config.git
cd terraform-config

# 5. Run Terraform
terraform init
terraform plan
terraform apply

# 6. Deploy applications
kubectl apply -f manifests/
helm install myapp ./charts/myapp
```

## Cleanup

To remove the Terraform Runner:

```bash
terraform destroy -target=module.terraform_runner
```

## References

- [AWS Systems Manager Session Manager](https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager.html)
- [EKS Private Clusters](https://docs.aws.amazon.com/eks/latest/userguide/private-clusters.html)
