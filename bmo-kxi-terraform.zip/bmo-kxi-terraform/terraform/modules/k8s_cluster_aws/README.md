# k8s_cluster_aws

Create a basic EKS cluster on AWS with private API endpoint and optional bastion host for management.

## Deployment Modes

This module supports two deployment modes:

### 1. Standard Mode (Default)
Creates a VPC with both public and private subnets:
- **Public subnets**: Host NAT Gateways and Bastion Host with OpenVPN
- **Private subnets**: Host EKS cluster nodes
- **Internet connectivity**: Via NAT Gateways in public subnets
- **Access**: Via Bastion Host + OpenVPN

### 2. Private-Only Mode
Set `private_only = true` to create a fully private VPC:
- **No public subnets**: Only private subnets are created
- **No NAT Gateways**: No internet gateway or NAT gateways
- **No Bastion Host**: No public-facing resources
- **Internet connectivity**: You must provide alternative connectivity (VPC Endpoints, VPN, Direct Connect, etc.)
- **Access**: Via AWS Systems Manager Session Manager, VPN, or Direct Connect

**Important**: When using `private_only = true`, you need to configure:
- VPC Endpoints for AWS services (S3, ECR, EC2, Logs, STS, ELB)
- Alternative access method (SSM, VPN, Direct Connect)
- DNS resolution for private endpoints

The overall architecture created by this module is as per the diagram below;

![Overview](docs/img/PrivateCluster.png)
<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | 1.5.5 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | 5.100.0 |
| <a name="requirement_kubernetes"></a> [kubernetes](#requirement\_kubernetes) | 2.37.1 |
| <a name="requirement_local"></a> [local](#requirement\_local) | 2.5.3 |
| <a name="requirement_null"></a> [null](#requirement\_null) | 3.2.4 |
| <a name="requirement_tls"></a> [tls](#requirement\_tls) | 4.1.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.100.0 |
| <a name="provider_local"></a> [local](#provider\_local) | 2.5.3 |
| <a name="provider_null"></a> [null](#provider\_null) | 3.2.4 |
| <a name="provider_tls"></a> [tls](#provider\_tls) | 4.1.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_eks"></a> [eks](#module\_eks) | terraform-aws-modules/eks/aws | 20.37.1 |
| <a name="module_eks_managed_node_group_rook_ceph"></a> [eks\_managed\_node\_group\_rook\_ceph](#module\_eks\_managed\_node\_group\_rook\_ceph) | terraform-aws-modules/eks/aws//modules/eks-managed-node-group | 20.37.1 |
| <a name="module_vpc"></a> [vpc](#module\_vpc) | terraform-aws-modules/vpc/aws | 5.21.0 |

## Resources

| Name | Type |
|------|------|
| [aws_eip.eks_bastion_host_elastic_ip](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/eip) | resource |
| [aws_eip.nat_gateway_eip](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/eip) | resource |
| [aws_eip_association.bastion_host_elastic_ip](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/eip_association) | resource |
| [aws_instance.eks_bastion_host_instance](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/instance) | resource |
| [aws_key_pair.bastion_host_ssh_public_key](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/key_pair) | resource |
| [aws_network_acl_rule.allow_http_letsencrypt](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/network_acl_rule) | resource |
| [aws_security_group.eks_bastion_host_sg](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/security_group) | resource |
| [aws_security_group_rule.allow_outbound_access_eks_bastion_host_sg](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.whitelist_ips_eks_bastion_host_sg](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.whitelist_ips_openvpn](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/security_group_rule) | resource |
| [local_file.bastion_ssh_private_key](https://registry.terraform.io/providers/hashicorp/local/2.5.3/docs/resources/file) | resource |
| [null_resource.openvpn_config](https://registry.terraform.io/providers/hashicorp/null/3.2.4/docs/resources/resource) | resource |
| [null_resource.openvpn_install](https://registry.terraform.io/providers/hashicorp/null/3.2.4/docs/resources/resource) | resource |
| [tls_private_key.bastion_host_ssh_key_pair](https://registry.terraform.io/providers/hashicorp/tls/4.1.0/docs/resources/private_key) | resource |
| [aws_ami.ubuntu_2204_ami_latest](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/data-sources/ami) | data source |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/data-sources/availability_zones) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bastion_admin_user"></a> [bastion\_admin\_user](#input\_bastion\_admin\_user) | Default admin user of bastion host. | `string` | `"ubuntu"` | no |
| <a name="input_bastion_host_sg_id"></a> [bastion\_host\_sg\_id](#input\_bastion\_host\_sg\_id) | ID of the bastion security group ID | `string` | `""` | no |
| <a name="input_bastion_instance_type"></a> [bastion\_instance\_type](#input\_bastion\_instance\_type) | Type of node to use for the bastion host. See https://aws.amazon.com/ec2/instance-types for more information. | `string` | `"t3.micro"` | no |
| <a name="input_bastion_ssh_private_key_file"></a> [bastion\_ssh\_private\_key\_file](#input\_bastion\_ssh\_private\_key\_file) | Path to store the ssh private key for bastion host. | `string` | `"bastion_ssh_private_key.pem"` | no |
| <a name="input_bastion_whitelist_ips"></a> [bastion\_whitelist\_ips](#input\_bastion\_whitelist\_ips) | List of IPs to be whitelisted on the Bastion Host | `list(any)` | `[]` | no |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | Name of the cluster and prefix for associated resources. | `string` | n/a | yes |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Default version for the EKS cluster | `string` | `null` | no |
| <a name="input_default_node_type"></a> [default\_node\_type](#input\_default\_node\_type) | Type of node to use for the cluster. See https://aws.amazon.com/ec2/instance-types for more information. | `string` | `"r5.xlarge"` | no |
| <a name="input_default_tags"></a> [default\_tags](#input\_default\_tags) | Tags which will be assigned to resources which are created. | `map(string)` | `{}` | no |
| <a name="input_desired_node_count"></a> [desired\_node\_count](#input\_desired\_node\_count) | Desired number of nodes in the cluster | `number` | `3` | no |
| <a name="input_enable_rook_ceph_node_pool"></a> [enable\_rook\_ceph\_node\_pool](#input\_enable\_rook\_ceph\_node\_pool) | Whether to create the rook-ceph node pool or not | `bool` | `false` | no |
| <a name="input_existing_vpc"></a> [existing\_vpc](#input\_existing\_vpc) | Set to true if deploying to existing vpc | `bool` | `false` | no |
| <a name="input_insights_whitelist_ips"></a> [insights\_whitelist\_ips](#input\_insights\_whitelist\_ips) | List of IP ranges in CIDR notation to allow access to insights | `list(string)` | `[]` | no |
| <a name="input_letsencrypt_enable_http_validation"></a> [letsencrypt\_enable\_http\_validation](#input\_letsencrypt\_enable\_http\_validation) | Whether to enable cluster issuer for http validation or not | `bool` | `false` | no |
| <a name="input_max_node_count"></a> [max\_node\_count](#input\_max\_node\_count) | Maximum number of nodes in the cluster | `number` | `10` | no |
| <a name="input_min_node_count"></a> [min\_node\_count](#input\_min\_node\_count) | Minimum number of nodes in the cluster | `number` | `3` | no |
| <a name="input_private_subnets_ids"></a> [private\_subnets\_ids](#input\_private\_subnets\_ids) | List of private subnet IDs in the existing VPC | `list(string)` | `[]` | no |
| <a name="input_public_network_acl_id"></a> [public\_network\_acl\_id](#input\_public\_network\_acl\_id) | The public network ACL ID attached to public subnets | `string` | `""` | no |
| <a name="input_reduced_azs"></a> [reduced\_azs](#input\_reduced\_azs) | Set to true to only use 2 AZs and create 2 subnets for both public and private | `bool` | `false` | no |
| <a name="input_rook_ceph_pool_desired_node_count"></a> [rook\_ceph\_pool\_desired\_node\_count](#input\_rook\_ceph\_pool\_desired\_node\_count) | n/a | `number` | `3` | no |
| <a name="input_rook_ceph_pool_max_node_count"></a> [rook\_ceph\_pool\_max\_node\_count](#input\_rook\_ceph\_pool\_max\_node\_count) | n/a | `number` | `3` | no |
| <a name="input_rook_ceph_pool_min_node_count"></a> [rook\_ceph\_pool\_min\_node\_count](#input\_rook\_ceph\_pool\_min\_node\_count) | n/a | `number` | `3` | no |
| <a name="input_rook_ceph_pool_node_type"></a> [rook\_ceph\_pool\_node\_type](#input\_rook\_ceph\_pool\_node\_type) | n/a | `string` | `"i3.2xlarge"` | no |
| <a name="input_rook_ceph_pool_root_disk_iops"></a> [rook\_ceph\_pool\_root\_disk\_iops](#input\_rook\_ceph\_pool\_root\_disk\_iops) | IOPS for io1 rook-ceph-pool root disk. Set to null for gp3 | `string` | `null` | no |
| <a name="input_rook_ceph_pool_root_disk_size"></a> [rook\_ceph\_pool\_root\_disk\_size](#input\_rook\_ceph\_pool\_root\_disk\_size) | Size of rook-ceph-pool root disk in GB | `string` | `"20"` | no |
| <a name="input_rook_ceph_pool_root_disk_type"></a> [rook\_ceph\_pool\_root\_disk\_type](#input\_rook\_ceph\_pool\_root\_disk\_type) | Type of rook-ceph-pool root disk. Can be either gp3 or io1 | `string` | `"gp3"` | no |
| <a name="input_root_disk_iops"></a> [root\_disk\_iops](#input\_root\_disk\_iops) | IOPS for io1 root disk. Set to null for gp3 | `string` | `null` | no |
| <a name="input_root_disk_size"></a> [root\_disk\_size](#input\_root\_disk\_size) | Size of root disk in GB | `string` | `"100"` | no |
| <a name="input_root_disk_type"></a> [root\_disk\_type](#input\_root\_disk\_type) | Type of root disk. Can be either gp3 or io1 | `string` | `"gp3"` | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | ID of the existing VPC to use | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_bastion_ip"></a> [bastion\_ip](#output\_bastion\_ip) | Bastion Host Elastic IP Address |
| <a name="output_bastion_ssh_private_key"></a> [bastion\_ssh\_private\_key](#output\_bastion\_ssh\_private\_key) | Bastion Host SSH Private Key |
| <a name="output_bastion_username"></a> [bastion\_username](#output\_bastion\_username) | Bastion Host username |
| <a name="output_openvpn_instructions"></a> [openvpn\_instructions](#output\_openvpn\_instructions) | OpenVPN instructions |
<!-- END_TF_DOCS -->
