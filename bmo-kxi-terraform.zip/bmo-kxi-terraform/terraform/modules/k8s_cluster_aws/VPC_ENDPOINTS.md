# VPC Endpoints for Private-Only EKS Deployments

## Overview

This module now supports **fully private EKS deployments** without NAT Gateway by automatically creating VPC Endpoints when `private_only = true` and `existing_vpc = false`.

## When are VPC Endpoints Created?

VPC Endpoints are **automatically created** when:
- `existing_vpc = false` (creating a new VPC)
- `private_only = true` (no public subnets or NAT Gateway)

In this configuration, the module creates **10 VPC Endpoints** to enable EKS nodes to access AWS services privately.

## VPC Endpoints Created

### Essential Endpoints (Always Created)

| Service | Type | Purpose | Monthly Cost* |
|---------|------|---------|---------------|
| **S3** | Gateway | ECR image layers, bootstrap scripts | FREE |
| **ECR API** | Interface | Docker authentication to ECR | ~$7.20 |
| **ECR DKR** | Interface | Pulling Docker images | ~$7.20 |
| **EC2** | Interface | Node registration, instance metadata | ~$7.20 |
| **STS** | Interface | IAM authentication, IRSA | ~$7.20 |
| **CloudWatch Logs** | Interface | Control plane logs, Fluent Bit | ~$7.20 |
| **ELB** | Interface | AWS Load Balancer Controller | ~$7.20 |
| **Autoscaling** | Interface | Cluster Autoscaler | ~$7.20 |
| **EKS** | Interface | kubectl API access | ~$7.20 |

### Optional Endpoints

| Service | Type | Purpose | Variable | Monthly Cost* |
|---------|------|---------|----------|---------------|
| **EFS** | Interface | EFS CSI driver | `enable_efs_endpoint` | ~$7.20 |

**Total estimated cost**: ~$50-65/month (depends on number of AZs and data transfer)

*Cost based on $0.01/hour per Interface endpoint per AZ (3 AZs) + data processing fees

## Usage Example

### Basic Private-Only Deployment

```hcl
module "eks_cluster" {
  source = "./modules/k8s_cluster_aws"

  cluster_name    = "my-private-cluster"
  cluster_version = "1.31"

  # Enable private-only mode
  private_only = true
  existing_vpc = false

  # EKS configuration
  min_node_count     = 3
  max_node_count     = 10
  desired_node_count = 3
  default_node_type  = "r5.xlarge"

  # Optional: Disable EFS endpoint if not using EFS
  enable_efs_endpoint = false

  default_tags = {
    Environment = "production"
    Project     = "my-project"
  }
}
```

### With Existing VPC (User Must Create Endpoints Manually)

```hcl
module "eks_cluster" {
  source = "./modules/k8s_cluster_aws"

  cluster_name    = "my-private-cluster"
  cluster_version = "1.31"

  # Using existing VPC
  existing_vpc        = true
  vpc_id              = "vpc-xxxxx"
  private_subnets_ids = ["subnet-aaa", "subnet-bbb", "subnet-ccc"]

  # Private-only mode with existing VPC
  # NOTE: You must manually create VPC Endpoints in your existing VPC!
  private_only = true

  min_node_count     = 3
  max_node_count     = 10
  desired_node_count = 3

  default_tags = {
    Environment = "production"
  }
}
```

## What Gets Created

When `private_only = true` and `existing_vpc = false`:

1. **VPC** with only private subnets (no public subnets)
2. **Security Group** for VPC Endpoints (allows HTTPS from VPC CIDR)
3. **10 VPC Endpoints** (9 essential + 1 optional)
4. **No NAT Gateway** (cost savings!)
5. **No Bastion Host** (not accessible from internet)
6. **No Internet Gateway** (fully isolated)

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                         VPC (10.0.0.0/16)                    │
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │Private Subnet│  │Private Subnet│  │Private Subnet│       │
│  │  us-east-1a  │  │  us-east-1b  │  │  us-east-1c  │       │
│  │              │  │              │  │              │       │
│  │ ┌──────────┐ │  │ ┌──────────┐ │  │ ┌──────────┐ │       │
│  │ │EKS Nodes │ │  │ │EKS Nodes │ │  │ │EKS Nodes │ │       │
│  │ └──────────┘ │  │ └──────────┘ │  │ └──────────┘ │       │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘       │
│         │                 │                 │               │
│         └─────────────────┼─────────────────┘               │
│                           │                                 │
│                           ▼                                 │
│                  ┌─────────────────┐                        │
│                  │ VPC Endpoints   │                        │
│                  │  - ECR API/DKR  │                        │
│                  │  - S3 (Gateway) │                        │
│                  │  - EC2, STS     │                        │
│                  │  - Logs, ELB    │                        │
│                  │  - Autoscaling  │                        │
│                  │  - EKS, EFS     │                        │
│                  └─────────┬───────┘                        │
│                            │                                │
└────────────────────────────┼────────────────────────────────┘
                             │
                             ▼
                     AWS Services
              (ECR, S3, EC2, STS, etc)
```

## Important Considerations

### ✅ What Works

- EKS node registration and bootstrap
- Pulling images from **AWS ECR only**
- IAM authentication (IRSA)
- CloudWatch logging and metrics
- AWS Load Balancer Controller
- Cluster Autoscaler
- EFS CSI Driver (if `enable_efs_endpoint = true`)
- All AWS service integrations

### ❌ What Doesn't Work

- **Pulling images from DockerHub** or other public registries
- **apt-get/yum install** from public repositories
- **Access to external APIs** (e.g., GitHub, npm registry)
- **Internet access** for any reason

### 🔄 Workarounds

1. **For Docker images**: Copy all required images to ECR first
   ```bash
   # On your local machine (with internet)
   docker pull nginx:latest
   docker tag nginx:latest 123456789012.dkr.ecr.us-east-1.amazonaws.com/nginx:latest
   docker push 123456789012.dkr.ecr.us-east-1.amazonaws.com/nginx:latest
   ```

2. **For packages**: Build custom AMIs with pre-installed packages or use AWS Systems Manager for patching

3. **For external APIs**: Use AWS PrivateLink or proxy through another VPC with NAT

## Outputs

When VPC Endpoints are created, the module outputs:

```hcl
output "vpc_endpoints_created" {
  description = "Map of all VPC Endpoints created"
  value = {
    s3                   = "vpce-xxxxx"
    ecr_api              = "vpce-yyyyy"
    ecr_dkr              = "vpce-zzzzz"
    ec2                  = "vpce-aaaaa"
    sts                  = "vpce-bbbbb"
    logs                 = "vpce-ccccc"
    elasticloadbalancing = "vpce-ddddd"
    autoscaling          = "vpce-eeeee"
    eks                  = "vpce-fffff"
    efs                  = "vpce-ggggg"
  }
}

output "vpc_endpoints_security_group" {
  description = "Security Group ID for VPC Endpoints"
  value       = "sg-xxxxx"
}
```

## Troubleshooting

### Nodes Fail to Join Cluster

**Symptom**: `NodeCreationFailure: Instances failed to join the kubernetes cluster`

**Solution**:
1. Verify all VPC Endpoints are in `available` state:
   ```bash
   aws ec2 describe-vpc-endpoints --vpc-id vpc-xxxxx --region us-east-1
   ```

2. Verify Private DNS is enabled:
   ```bash
   aws ec2 describe-vpc-endpoints --vpc-endpoint-ids vpce-xxxxx \
     --query 'VpcEndpoints[0].PrivateDnsEnabled'
   ```
   Should return `true`

3. Check Security Group allows HTTPS from VPC CIDR

### Images Won't Pull

**Symptom**: `Failed to pull image: ErrImagePull`

**Solution**: Ensure images are in **ECR**, not DockerHub:
```yaml
# ❌ Won't work
image: nginx:latest

# ✅ Works
image: 123456789012.dkr.ecr.us-east-1.amazonaws.com/nginx:latest
```

### Can't Access Cluster via kubectl

**Symptom**: Connection timeout when running `kubectl get nodes`

**Solution**: You need private network access to the cluster:
1. Use VPN connection to your VPC
2. Use AWS Systems Manager Session Manager
3. Deploy a bastion host in the private subnet
4. Use AWS Client VPN

## Migration from NAT Gateway to VPC Endpoints

If you have an existing cluster with NAT Gateway and want to switch:

```hcl
# Before
module "eks_cluster" {
  source       = "./modules/k8s_cluster_aws"
  existing_vpc = false
  private_only = false  # Has NAT Gateway
}

# After (requires cluster rebuild)
module "eks_cluster" {
  source       = "./modules/k8s_cluster_aws"
  existing_vpc = false
  private_only = true   # Uses VPC Endpoints
}
```

**⚠️ Warning**: This requires rebuilding the cluster. Plan migration carefully!

## Cost Comparison

| Configuration | Monthly Cost | Internet Access |
|--------------|--------------|-----------------|
| **NAT Gateway** (3 AZs) | ~$100-150 | ✅ Full internet |
| **VPC Endpoints** (9 essential) | ~$50-65 | ❌ AWS services only |
| **Transit Gateway** to shared VPC | ~$50-100 | ✅ Via shared NAT |

## References

- [AWS VPC Endpoints Pricing](https://aws.amazon.com/privatelink/pricing/)
- [EKS Private Clusters](https://docs.aws.amazon.com/eks/latest/userguide/private-clusters.html)
- [AWS PrivateLink](https://aws.amazon.com/privatelink/)
