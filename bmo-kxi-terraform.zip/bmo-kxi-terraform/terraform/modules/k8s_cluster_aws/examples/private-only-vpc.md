# Private-Only VPC Deployment Example

This example shows how to deploy an EKS cluster in a fully private VPC without any public subnets or internet-facing resources.

## Configuration

```hcl
module "kx-aws-private" {
  source = "../modules/k8s_cluster_aws"

  cluster_name       = "my-private-cluster"
  cluster_version    = "1.32"
  default_node_type  = "r5.xlarge"
  desired_node_count = 3
  min_node_count     = 3
  max_node_count     = 10

  # Enable private-only mode
  private_only = true

  # Use 2 AZs instead of all available
  reduced_azs = true

  default_tags = {
    Environment = "production"
    ManagedBy   = "terraform"
  }
}
```

## Required Additional Resources

Since this is a private-only deployment, you need to configure additional resources for connectivity:

### 1. VPC Endpoints for AWS Services

```hcl
# S3 Gateway Endpoint
resource "aws_vpc_endpoint" "s3" {
  vpc_id       = module.kx-aws-private.vpc_id
  service_name = "com.amazonaws.${var.region}.s3"
  route_table_ids = module.kx-aws-private.private_route_table_ids
}

# ECR API Interface Endpoint
resource "aws_vpc_endpoint" "ecr_api" {
  vpc_id              = module.kx-aws-private.vpc_id
  service_name        = "com.amazonaws.${var.region}.ecr.api"
  vpc_endpoint_type   = "Interface"
  subnet_ids          = module.kx-aws-private.private_subnet_ids
  security_group_ids  = [aws_security_group.vpc_endpoints.id]
  private_dns_enabled = true
}

# ECR Docker Interface Endpoint
resource "aws_vpc_endpoint" "ecr_dkr" {
  vpc_id              = module.kx-aws-private.vpc_id
  service_name        = "com.amazonaws.${var.region}.ecr.dkr"
  vpc_endpoint_type   = "Interface"
  subnet_ids          = module.kx-aws-private.private_subnet_ids
  security_group_ids  = [aws_security_group.vpc_endpoints.id]
  private_dns_enabled = true
}

# EC2 Interface Endpoint
resource "aws_vpc_endpoint" "ec2" {
  vpc_id              = module.kx-aws-private.vpc_id
  service_name        = "com.amazonaws.${var.region}.ec2"
  vpc_endpoint_type   = "Interface"
  subnet_ids          = module.kx-aws-private.private_subnet_ids
  security_group_ids  = [aws_security_group.vpc_endpoints.id]
  private_dns_enabled = true
}

# CloudWatch Logs Interface Endpoint
resource "aws_vpc_endpoint" "logs" {
  vpc_id              = module.kx-aws-private.vpc_id
  service_name        = "com.amazonaws.${var.region}.logs"
  vpc_endpoint_type   = "Interface"
  subnet_ids          = module.kx-aws-private.private_subnet_ids
  security_group_ids  = [aws_security_group.vpc_endpoints.id]
  private_dns_enabled = true
}

# STS Interface Endpoint
resource "aws_vpc_endpoint" "sts" {
  vpc_id              = module.kx-aws-private.vpc_id
  service_name        = "com.amazonaws.${var.region}.sts"
  vpc_endpoint_type   = "Interface"
  subnet_ids          = module.kx-aws-private.private_subnet_ids
  security_group_ids  = [aws_security_group.vpc_endpoints.id]
  private_dns_enabled = true
}

# Elastic Load Balancing Interface Endpoint
resource "aws_vpc_endpoint" "elasticloadbalancing" {
  vpc_id              = module.kx-aws-private.vpc_id
  service_name        = "com.amazonaws.${var.region}.elasticloadbalancing"
  vpc_endpoint_type   = "Interface"
  subnet_ids          = module.kx-aws-private.private_subnet_ids
  security_group_ids  = [aws_security_group.vpc_endpoints.id]
  private_dns_enabled = true
}

# Security Group for VPC Endpoints
resource "aws_security_group" "vpc_endpoints" {
  name        = "vpc-endpoints-sg"
  description = "Security group for VPC endpoints"
  vpc_id      = module.kx-aws-private.vpc_id

  ingress {
    description = "HTTPS from VPC"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]  # Adjust to your VPC CIDR
  }

  egress {
    description = "All traffic"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "vpc-endpoints-sg"
  }
}
```

### 2. Access to the Cluster

Since there's no bastion host, you need to configure alternative access:

#### Option A: AWS Systems Manager Session Manager

```bash
# Install Session Manager plugin
# https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager-working-with-install-plugin.html

# Connect to any EKS node
aws ssm start-session --target <instance-id> --region <region>

# Once connected, configure kubectl
aws eks update-kubeconfig --name my-private-cluster --region <region>
```

#### Option B: AWS Client VPN

Set up an AWS Client VPN endpoint connected to your private subnets.

#### Option C: Site-to-Site VPN or Direct Connect

Configure a VPN connection from your corporate network to the VPC.

## Limitations

When using `private_only = true`:

- ❌ No direct internet access from cluster nodes
- ❌ No public load balancers (only internal load balancers)
- ❌ Cannot use Let's Encrypt HTTP validation (use DNS validation instead)
- ❌ Cannot pull images from public registries (use ECR or private registries via VPC endpoints)
- ✅ Higher security posture
- ✅ Suitable for highly regulated environments

## Accessing External Resources

If your workloads need to access external resources:

1. **AWS Services**: Use VPC Endpoints (configured above)
2. **Internet Resources**:
   - Use a proxy server in a separate VPC with internet access
   - Use AWS PrivateLink for supported services
   - Configure VPN/Direct Connect with on-premises proxy
3. **Container Images**:
   - Mirror images to Amazon ECR
   - Use ECR pull-through cache
   - Set up private registry with VPC endpoint

## Example Terraform Variables File

Create a `terraform.tfvars` file:

```hcl
cluster_name       = "my-private-cluster"
cluster_version    = "1.32"
region             = "us-east-1"
private_only       = true
reduced_azs        = true
default_node_type  = "r5.xlarge"
desired_node_count = 3
min_node_count     = 3
max_node_count     = 10

default_tags = {
  Environment = "production"
  Project     = "my-project"
  ManagedBy   = "terraform"
}
```

## Deployment

```bash
# Initialize Terraform
terraform init

# Plan the deployment
terraform plan

# Apply the configuration
terraform apply

# Configure kubectl (requires VPN/SSM access)
aws eks update-kubeconfig --name my-private-cluster --region us-east-1
```
