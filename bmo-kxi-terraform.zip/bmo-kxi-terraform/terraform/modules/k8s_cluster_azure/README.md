# k8s_cluster_azure

Create a basic AKS cluster on Azure with private API endpoints and optional bastion host.

For information on how to authenticate the azure provider in terraform, see [https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/guides/service_principal_client_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/guides/service_principal_client_secret#configuring-the-service-principal-in-terraform)

The overall architecture created by this module is as per the diagram below;


![Overview](docs/img/PrivateCluster.png)
<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | 1.5.5 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.34.0 |
| <a name="requirement_local"></a> [local](#requirement\_local) | 2.5.3 |
| <a name="requirement_null"></a> [null](#requirement\_null) | 3.2.4 |
| <a name="requirement_random"></a> [random](#requirement\_random) | 3.7.2 |
| <a name="requirement_tls"></a> [tls](#requirement\_tls) | 4.1.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 4.34.0 |
| <a name="provider_local"></a> [local](#provider\_local) | 2.5.3 |
| <a name="provider_null"></a> [null](#provider\_null) | 3.2.4 |
| <a name="provider_random"></a> [random](#provider\_random) | 3.7.2 |
| <a name="provider_tls"></a> [tls](#provider\_tls) | 4.1.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_kubernetes_cluster.cluster](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/kubernetes_cluster) | resource |
| [azurerm_kubernetes_cluster_node_pool.aks_node_pool_rook_ceph](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/kubernetes_cluster_node_pool) | resource |
| [azurerm_linux_virtual_machine.bastion](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/linux_virtual_machine) | resource |
| [azurerm_log_analytics_solution.azure_container_insights](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/log_analytics_solution) | resource |
| [azurerm_log_analytics_workspace.azure_analytics_workspace_container_insights](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/log_analytics_workspace) | resource |
| [azurerm_network_interface.bastion_nic](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_interface) | resource |
| [azurerm_network_interface_security_group_association.sg_association](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_security_group.bastion_sg](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_security_group) | resource |
| [azurerm_network_security_group.subnet_sg](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.allow_http_letsencrypt](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.allow_insights_ports_from_bastion_host](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.allow_insights_ports_from_existing_vnet_host](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.allow_ssh_bastion_host](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.allow_vpn_bastion_host](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_security_rule) | resource |
| [azurerm_public_ip.bastion_ip](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/public_ip) | resource |
| [azurerm_resource_group.resource_group](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/resource_group) | resource |
| [azurerm_subnet.subnet1](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.subnet_security_group_association](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_virtual_network.vnet](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/virtual_network) | resource |
| [local_file.bastion_ssh_private_key](https://registry.terraform.io/providers/hashicorp/local/2.5.3/docs/resources/file) | resource |
| [null_resource.openvpn_config](https://registry.terraform.io/providers/hashicorp/null/3.2.4/docs/resources/resource) | resource |
| [null_resource.openvpn_install](https://registry.terraform.io/providers/hashicorp/null/3.2.4/docs/resources/resource) | resource |
| [random_id.unique_string](https://registry.terraform.io/providers/hashicorp/random/3.7.2/docs/resources/id) | resource |
| [tls_private_key.bastion_ssh_key_pair](https://registry.terraform.io/providers/hashicorp/tls/4.1.0/docs/resources/private_key) | resource |
| [azurerm_subnet.existing_vnet_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/subnet) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bastion_admin_user"></a> [bastion\_admin\_user](#input\_bastion\_admin\_user) | Default admin user to create on the bastion host. | `string` | `"adminuser"` | no |
| <a name="input_bastion_instance_type"></a> [bastion\_instance\_type](#input\_bastion\_instance\_type) | VM Instance size for the bastion host. | `string` | `"Standard_DS1_v2"` | no |
| <a name="input_bastion_ssh_private_key_file"></a> [bastion\_ssh\_private\_key\_file](#input\_bastion\_ssh\_private\_key\_file) | Path to store the ssh private key for bastion host. | `string` | `"bastion_ssh_private_key.pem"` | no |
| <a name="input_bastion_whitelist_ips"></a> [bastion\_whitelist\_ips](#input\_bastion\_whitelist\_ips) | List of IP ranges in CIDR notation to allow SSH access to the bastion host. | `list(string)` | `[]` | no |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | Name of the cluster and prefix for associated resources. | `string` | n/a | yes |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Default version for the AKS cluster | `string` | `null` | no |
| <a name="input_default_disk_size_gb"></a> [default\_disk\_size\_gb](#input\_default\_disk\_size\_gb) | The size of the OS Disk which should be used for each agent in the Node Pool. Changing this forces a new resource to be created. | `number` | `100` | no |
| <a name="input_default_node_pool_zones"></a> [default\_node\_pool\_zones](#input\_default\_node\_pool\_zones) | List of Availability Zones to use for default node pool | `list(any)` | `[]` | no |
| <a name="input_default_node_type"></a> [default\_node\_type](#input\_default\_node\_type) | Type of node to use for the cluster. See https://docs.microsoft.com/en-us/azure/virtual-machines/sizes for more information. | `string` | `"Standard_E4_v3"` | no |
| <a name="input_default_tags"></a> [default\_tags](#input\_default\_tags) | Tags which will be assigned to resources which are created. | `map(string)` | `{}` | no |
| <a name="input_enable_metrics"></a> [enable\_metrics](#input\_enable\_metrics) | Enable Azure Container Insights | `bool` | `false` | no |
| <a name="input_enable_rook_ceph_node_pool"></a> [enable\_rook\_ceph\_node\_pool](#input\_enable\_rook\_ceph\_node\_pool) | Whether to create the rook-ceph node pool or not | `bool` | `false` | no |
| <a name="input_existing_vnet"></a> [existing\_vnet](#input\_existing\_vnet) | Set to true if deploying to existing vnet | `bool` | `false` | no |
| <a name="input_existing_vnet_resource_group"></a> [existing\_vnet\_resource\_group](#input\_existing\_vnet\_resource\_group) | Name of the existing VNET resource group | `string` | `""` | no |
| <a name="input_insights_whitelist_ips"></a> [insights\_whitelist\_ips](#input\_insights\_whitelist\_ips) | List of IP ranges in CIDR notation to allow access to insights | `list(string)` | `[]` | no |
| <a name="input_letsencrypt_enable_http_validation"></a> [letsencrypt\_enable\_http\_validation](#input\_letsencrypt\_enable\_http\_validation) | Whether to enable cluster issuer for http validation or not | `bool` | `false` | no |
| <a name="input_max_node_count"></a> [max\_node\_count](#input\_max\_node\_count) | Maximum number of nodes in the cluster | `number` | `10` | no |
| <a name="input_max_pods"></a> [max\_pods](#input\_max\_pods) | Maximum number of pods per node | `number` | `30` | no |
| <a name="input_min_node_count"></a> [min\_node\_count](#input\_min\_node\_count) | Minimum number of nodes in the cluster | `number` | `3` | no |
| <a name="input_private_subnets_names"></a> [private\_subnets\_names](#input\_private\_subnets\_names) | List of private subnet names in the existing VNET | `list(string)` | `[]` | no |
| <a name="input_reduced_azs"></a> [reduced\_azs](#input\_reduced\_azs) | Set to true to only use 1 AZ | `bool` | `false` | no |
| <a name="input_region"></a> [region](#input\_region) | Azure region for the cluster and associated resources. See https://azure.microsoft.com/en-us/global-infrastructure/geographies/ for available regions. | `string` | `"North Europe"` | no |
| <a name="input_rook_ceph_node_pool_zones"></a> [rook\_ceph\_node\_pool\_zones](#input\_rook\_ceph\_node\_pool\_zones) | List of Availability Zones to use for rook-ceph node pool | `list(any)` | `[]` | no |
| <a name="input_rook_ceph_pool_node_count"></a> [rook\_ceph\_pool\_node\_count](#input\_rook\_ceph\_pool\_node\_count) | n/a | `number` | `3` | no |
| <a name="input_rook_ceph_pool_node_type"></a> [rook\_ceph\_pool\_node\_type](#input\_rook\_ceph\_pool\_node\_type) | n/a | `string` | `"Standard_L8s_v2"` | no |
| <a name="input_rook_ceph_pool_os_disk_size_gb"></a> [rook\_ceph\_pool\_os\_disk\_size\_gb](#input\_rook\_ceph\_pool\_os\_disk\_size\_gb) | n/a | `string` | `"100"` | no |
| <a name="input_vnet_name"></a> [vnet\_name](#input\_vnet\_name) | Name of the existing VNET to use | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_bastion_ip"></a> [bastion\_ip](#output\_bastion\_ip) | Bastion VM IP |
| <a name="output_bastion_ssh_private_key"></a> [bastion\_ssh\_private\_key](#output\_bastion\_ssh\_private\_key) | Bastion Host SSH Private Key |
| <a name="output_bastion_username"></a> [bastion\_username](#output\_bastion\_username) | Bastion VM username |
| <a name="output_openvpn_instructions"></a> [openvpn\_instructions](#output\_openvpn\_instructions) | OpenVPN instructions |
<!-- END_TF_DOCS -->
