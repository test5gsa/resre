For information on how to authenticate the azure provider in terraform, see [https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/guides/service_principal_client_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/guides/service_principal_client_secret#configuring-the-service-principal-in-terraform)
<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | 1.5.5 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.34.0 |

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_kx-azure"></a> [kx-azure](#module\_kx-azure) | ../modules/k8s_cluster_azure | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bastion_whitelist_ips"></a> [bastion\_whitelist\_ips](#input\_bastion\_whitelist\_ips) | List of IP ranges in CIDR notation to allow SSH access to the bastion host. | `list(string)` | `[]` | no |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | Name of the cluster and prefix for associated resources. | `string` | n/a | yes |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Default version for the AKS cluster | `string` | `"1.32"` | no |
| <a name="input_default_node_pool_zones"></a> [default\_node\_pool\_zones](#input\_default\_node\_pool\_zones) | List of Availability Zones to use for default node pool | `list(any)` | `[]` | no |
| <a name="input_default_node_type"></a> [default\_node\_type](#input\_default\_node\_type) | Type of node to use for the cluster. See https://docs.microsoft.com/en-us/azure/virtual-machines/sizes for more information. | `string` | `"Standard_D2_v3"` | no |
| <a name="input_default_tags"></a> [default\_tags](#input\_default\_tags) | Tags which will be assigned to resources which are created. | `map(string)` | `{}` | no |
| <a name="input_enable_metrics"></a> [enable\_metrics](#input\_enable\_metrics) | Enable Azure Container Insights | `bool` | `true` | no |
| <a name="input_enable_rook_ceph_node_pool"></a> [enable\_rook\_ceph\_node\_pool](#input\_enable\_rook\_ceph\_node\_pool) | Whether to create the rook-ceph node pool or not | `bool` | `false` | no |
| <a name="input_existing_vnet"></a> [existing\_vnet](#input\_existing\_vnet) | Set to true if deploying to existing vnet | `bool` | `false` | no |
| <a name="input_existing_vnet_resource_group"></a> [existing\_vnet\_resource\_group](#input\_existing\_vnet\_resource\_group) | Name of the existing VNET's resource group | `string` | `""` | no |
| <a name="input_insights_whitelist_ips"></a> [insights\_whitelist\_ips](#input\_insights\_whitelist\_ips) | List of IP ranges in CIDR notation to allow access to insights | `list(string)` | `[]` | no |
| <a name="input_letsencrypt_enable_http_validation"></a> [letsencrypt\_enable\_http\_validation](#input\_letsencrypt\_enable\_http\_validation) | Whether to enable cluster issuer for http validation or not | `bool` | `false` | no |
| <a name="input_max_node_count"></a> [max\_node\_count](#input\_max\_node\_count) | Maximum number of nodes in the cluster | `number` | `10` | no |
| <a name="input_max_pods"></a> [max\_pods](#input\_max\_pods) | Maximum number of pods per node | `number` | `110` | no |
| <a name="input_min_node_count"></a> [min\_node\_count](#input\_min\_node\_count) | Minimum number of nodes in the cluster | `number` | `3` | no |
| <a name="input_private_subnets_names"></a> [private\_subnets\_names](#input\_private\_subnets\_names) | List of private subnet names in the existing VNET | `list(string)` | `[]` | no |
| <a name="input_reduced_azs"></a> [reduced\_azs](#input\_reduced\_azs) | Set to true to only use 1 AZ | `bool` | `false` | no |
| <a name="input_region"></a> [region](#input\_region) | Azure region for the cluster and associated resources. See https://azure.microsoft.com/en-us/global-infrastructure/geographies/ for available regions. | `string` | `"northeurope"` | no |
| <a name="input_rook_ceph_node_pool_zones"></a> [rook\_ceph\_node\_pool\_zones](#input\_rook\_ceph\_node\_pool\_zones) | List of Availability Zones to use for rook-ceph node pool | `list(any)` | `[]` | no |
| <a name="input_rook_ceph_pool_node_count"></a> [rook\_ceph\_pool\_node\_count](#input\_rook\_ceph\_pool\_node\_count) | n/a | `number` | `3` | no |
| <a name="input_rook_ceph_pool_node_type"></a> [rook\_ceph\_pool\_node\_type](#input\_rook\_ceph\_pool\_node\_type) | n/a | `string` | `"Standard_L8s_v2"` | no |
| <a name="input_vnet_name"></a> [vnet\_name](#input\_vnet\_name) | Name of the existing VNET to use | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_bastion_ip"></a> [bastion\_ip](#output\_bastion\_ip) | Bastion VM IP |
| <a name="output_bastion_ssh_private_key"></a> [bastion\_ssh\_private\_key](#output\_bastion\_ssh\_private\_key) | Bastion SSH Private Key |
| <a name="output_bastion_username"></a> [bastion\_username](#output\_bastion\_username) | Bastion VM username |
| <a name="output_openvpn_instructions"></a> [openvpn\_instructions](#output\_openvpn\_instructions) | OpenVPN instructions |
<!-- END_TF_DOCS -->
