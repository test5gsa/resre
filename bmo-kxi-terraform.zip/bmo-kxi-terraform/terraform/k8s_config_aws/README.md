# k8s_config_aws

This module includes all kubernetes configuration that must be applied once the EKS cluster is created on AWS.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | 1.5.5 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | 5.100.0 |
| <a name="requirement_helm"></a> [helm](#requirement\_helm) | 2.17.0 |
| <a name="requirement_kubectl"></a> [kubectl](#requirement\_kubectl) | 2.1.3 |
| <a name="requirement_kubernetes"></a> [kubernetes](#requirement\_kubernetes) | 2.37.1 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.100.0 |
| <a name="provider_helm"></a> [helm](#provider\_helm) | 2.17.0 |
| <a name="provider_kubectl"></a> [kubectl](#provider\_kubectl) | 2.1.3 |
| <a name="provider_kubernetes"></a> [kubernetes](#provider\_kubernetes) | 2.37.1 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_aws_cloudwatch_metrics_irsa"></a> [aws\_cloudwatch\_metrics\_irsa](#module\_aws\_cloudwatch\_metrics\_irsa) | terraform-aws-modules/iam/aws//modules/iam-assumable-role-with-oidc | 5.58.0 |
| <a name="module_aws_ebs_csi_irsa"></a> [aws\_ebs\_csi\_irsa](#module\_aws\_ebs\_csi\_irsa) | terraform-aws-modules/iam/aws//modules/iam-assumable-role-with-oidc | 5.58.0 |
| <a name="module_aws_efs_csi_irsa"></a> [aws\_efs\_csi\_irsa](#module\_aws\_efs\_csi\_irsa) | terraform-aws-modules/iam/aws//modules/iam-assumable-role-with-oidc | 5.58.0 |
| <a name="module_aws_load_balancer_controller_irsa"></a> [aws\_load\_balancer\_controller\_irsa](#module\_aws\_load\_balancer\_controller\_irsa) | terraform-aws-modules/iam/aws//modules/iam-assumable-role-with-oidc | 5.58.0 |
| <a name="module_cluster_autoscaler_irsa"></a> [cluster\_autoscaler\_irsa](#module\_cluster\_autoscaler\_irsa) | terraform-aws-modules/iam/aws//modules/iam-assumable-role-with-oidc | 5.58.0 |
| <a name="module_fluent_bit_irsa"></a> [fluent\_bit\_irsa](#module\_fluent\_bit\_irsa) | terraform-aws-modules/iam/aws//modules/iam-assumable-role-with-oidc | 5.58.0 |
| <a name="module_rook-ceph-helm"></a> [rook-ceph-helm](#module\_rook-ceph-helm) | ../modules/rook-ceph-helm | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_efs_file_system.aws_efs](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/efs_file_system) | resource |
| [aws_efs_mount_target.aws_efs_mount_targets](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/efs_mount_target) | resource |
| [aws_iam_policy.aws_load_balancer_controller_policy](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/iam_policy) | resource |
| [aws_iam_policy.cluster_autoscaler_policy](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/iam_policy) | resource |
| [aws_iam_policy.efs_csi_driver_policy](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/iam_policy) | resource |
| [aws_security_group.aws_efs_mount_target_sg](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/security_group) | resource |
| [aws_security_group_rule.allow_outbound_access_efs_mount_target_sg](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.nfs_access_from_vpc_sg](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/resources/security_group_rule) | resource |
| [helm_release.aws-cloudwatch-metrics](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.aws-ebs-csi-driver](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.aws-efs-csi-driver](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.aws-load-balancer-controller](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.cert-manager](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.cluster-autoscaler](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.ingress-nginx](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.metrics-server](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [helm_release.prometheus-operator-crds](https://registry.terraform.io/providers/hashicorp/helm/2.17.0/docs/resources/release) | resource |
| [kubectl_manifest.clusterissuer](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_cluster_info_configmap](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_fluent_bit_cluster_role](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_fluent_bit_cluster_role_binding](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_fluent_bit_config_configmap](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_fluent_bit_daemonset](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_fluent_bit_service_account](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.logging_namespace](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubectl_manifest.unset_gp2_as_default_storage_class](https://registry.terraform.io/providers/alekc/kubectl/2.1.3/docs/resources/manifest) | resource |
| [kubernetes_storage_class.aws_storage_class](https://registry.terraform.io/providers/hashicorp/kubernetes/2.37.1/docs/resources/storage_class) | resource |
| [kubernetes_storage_class.aws_storage_class_gp3](https://registry.terraform.io/providers/hashicorp/kubernetes/2.37.1/docs/resources/storage_class) | resource |
| [aws_eip.bastion_host_public_ip](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/data-sources/eip) | data source |
| [aws_eips.nat_gateway_public_ips](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/data-sources/eips) | data source |
| [aws_eks_cluster.default](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/data-sources/eks_cluster) | data source |
| [aws_eks_cluster_auth.default](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/data-sources/eks_cluster_auth) | data source |
| [aws_vpc.vpc](https://registry.terraform.io/providers/hashicorp/aws/5.100.0/docs/data-sources/vpc) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_architecture_profile"></a> [architecture\_profile](#input\_architecture\_profile) | The architecture profile used | `string` | n/a | yes |
| <a name="input_aws_cloudwatch_metrics_helm_version"></a> [aws\_cloudwatch\_metrics\_helm\_version](#input\_aws\_cloudwatch\_metrics\_helm\_version) | aws-cloudwatch-metrics helm chart version to deploy | `string` | `"0.0.11"` | no |
| <a name="input_aws_ebs_csi_driver_helm_version"></a> [aws\_ebs\_csi\_driver\_helm\_version](#input\_aws\_ebs\_csi\_driver\_helm\_version) | aws-ebs-csi-driver helm chart version to deploy | `string` | `"2.45.1"` | no |
| <a name="input_aws_efs_csi_driver_helm_version"></a> [aws\_efs\_csi\_driver\_helm\_version](#input\_aws\_efs\_csi\_driver\_helm\_version) | aws-efs-csi-driver helm chart version to deploy | `string` | `"3.2.0"` | no |
| <a name="input_aws_iops_per_gb"></a> [aws\_iops\_per\_gb](#input\_aws\_iops\_per\_gb) | I/O operations per second per GiB. Used to set the performance of the io1 StorageClass. See https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ebs-volume-types.html for more information | `string` | `"10"` | no |
| <a name="input_aws_load_balancer_controller_helm_version"></a> [aws\_load\_balancer\_controller\_helm\_version](#input\_aws\_load\_balancer\_controller\_helm\_version) | aws-load-balancer-controller helm chart version to deploy | `string` | `"1.13.3"` | no |
| <a name="input_cert_manager_helm_version"></a> [cert\_manager\_helm\_version](#input\_cert\_manager\_helm\_version) | cert-manager Helm chart version to deploy, see https://artifacthub.io/packages/helm/cert-manager/cert-manager for more info | `string` | `"1.18.2"` | no |
| <a name="input_cluster_autoscaler_helm_version"></a> [cluster\_autoscaler\_helm\_version](#input\_cluster\_autoscaler\_helm\_version) | cluster-autoscaler helm chart version to deploy | `string` | `"9.48.0"` | no |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | Name of the cluster | `string` | n/a | yes |
| <a name="input_enable_cert_manager"></a> [enable\_cert\_manager](#input\_enable\_cert\_manager) | Deploy cert-manager Helm chart | `bool` | `true` | no |
| <a name="input_enable_cluster_autoscaler"></a> [enable\_cluster\_autoscaler](#input\_enable\_cluster\_autoscaler) | Whether to deploy the cluster autoscaler or not | `bool` | `true` | no |
| <a name="input_enable_ebs_csi_driver"></a> [enable\_ebs\_csi\_driver](#input\_enable\_ebs\_csi\_driver) | Whether to enable AWS EBS CSI driver or not | `bool` | `true` | no |
| <a name="input_enable_efs_csi_driver"></a> [enable\_efs\_csi\_driver](#input\_enable\_efs\_csi\_driver) | Whether to enable AWS EFS CSI driver or not | `bool` | `true` | no |
| <a name="input_enable_efs_encryption"></a> [enable\_efs\_encryption](#input\_enable\_efs\_encryption) | Whether to enable encryption on AWS EFS or not | `bool` | `true` | no |
| <a name="input_enable_ingress_nginx"></a> [enable\_ingress\_nginx](#input\_enable\_ingress\_nginx) | Deployment of community nginx ingress helm chart | `bool` | `true` | no |
| <a name="input_enable_logging"></a> [enable\_logging](#input\_enable\_logging) | Whether to enable logging or not | `bool` | `false` | no |
| <a name="input_enable_metrics"></a> [enable\_metrics](#input\_enable\_metrics) | Whether to enable metrics or not | `bool` | `false` | no |
| <a name="input_enable_rook_ceph"></a> [enable\_rook\_ceph](#input\_enable\_rook\_ceph) | Whether to enable Rook Ceph or not | `bool` | `true` | no |
| <a name="input_enable_rook_ceph_node_pool"></a> [enable\_rook\_ceph\_node\_pool](#input\_enable\_rook\_ceph\_node\_pool) | Whether to create the rook-ceph node pool or not | `bool` | `false` | no |
| <a name="input_existing_vpc"></a> [existing\_vpc](#input\_existing\_vpc) | Set to true if deploying to existing vpc | `bool` | `false` | no |
| <a name="input_ingress_nginx_helm_version"></a> [ingress\_nginx\_helm\_version](#input\_ingress\_nginx\_helm\_version) | ingress-nginx  Helm chart version to deploy, see https://artifacthub.io/packages/helm/ingress-nginx/ingress-nginx for more info | `string` | `"4.11.5"` | no |
| <a name="input_ingress_nginx_resources_limit_memory"></a> [ingress\_nginx\_resources\_limit\_memory](#input\_ingress\_nginx\_resources\_limit\_memory) | ingress nginx memory limit | `string` | `"512Mi"` | no |
| <a name="input_ingress_nginx_resources_request_cpu"></a> [ingress\_nginx\_resources\_request\_cpu](#input\_ingress\_nginx\_resources\_request\_cpu) | ingress nginx CPU request | `string` | `"100m"` | no |
| <a name="input_ingress_nginx_resources_request_memory"></a> [ingress\_nginx\_resources\_request\_memory](#input\_ingress\_nginx\_resources\_request\_memory) | ingress nginx memory request | `string` | `"256Mi"` | no |
| <a name="input_insights_whitelist_ips"></a> [insights\_whitelist\_ips](#input\_insights\_whitelist\_ips) | List of IP ranges in CIDR notation to allow access to ingress-nginx | `list(string)` | `[]` | no |
| <a name="input_letsencrypt_account"></a> [letsencrypt\_account](#input\_letsencrypt\_account) | Email address to associate with the LetsEncrypt issuer | `string` | n/a | yes |
| <a name="input_letsencrypt_enable_http_validation"></a> [letsencrypt\_enable\_http\_validation](#input\_letsencrypt\_enable\_http\_validation) | Whether to enable cluster issuer for http validation or not | `bool` | `false` | no |
| <a name="input_metrics_server_helm_version"></a> [metrics\_server\_helm\_version](#input\_metrics\_server\_helm\_version) | metrics-server helm chart version to deploy | `string` | `"3.12.2"` | no |
| <a name="input_prometheus_operator_crds_helm_version"></a> [prometheus\_operator\_crds\_helm\_version](#input\_prometheus\_operator\_crds\_helm\_version) | prometheus-operator-crds helm chart version to deploy | `string` | `"5.0.0"` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `string` | `""` | no |
| <a name="input_rook_ceph_mds_resources_memory_limit"></a> [rook\_ceph\_mds\_resources\_memory\_limit](#input\_rook\_ceph\_mds\_resources\_memory\_limit) | Setting resource limit of MDS | `string` | `"8Gi"` | no |
| <a name="input_rook_ceph_storage_size"></a> [rook\_ceph\_storage\_size](#input\_rook\_ceph\_storage\_size) | Cloud storage size to use for Ceph. Only applies when cloud storage is used | `string` | `"100Gi"` | no |
| <a name="input_rook_ceph_storage_type"></a> [rook\_ceph\_storage\_type](#input\_rook\_ceph\_storage\_type) | The storage type used by rook-ceph. Should match existing StorageClass defined in Kubernetes. Set to local for local storage | `string` | `"gp3"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_installing_insights"></a> [installing\_insights](#output\_installing\_insights) | n/a |
<!-- END_TF_DOCS -->
